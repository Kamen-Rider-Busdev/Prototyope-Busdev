let scrollTimeout = null;

function attachHandlers(){
  const root = document.getElementById('root');

  // INPUT SEARCH BINDINGS
  const jdSearchInp = document.getElementById('jd-search-input');
  if(jdSearchInp) jdSearchInp.oninput = e => { S.jdSearchQuery = e.target.value; render(); };
  const obSearchInp = document.getElementById('ob-search-input');
  if(obSearchInp) obSearchInp.oninput = e => { S.obSearchQuery = e.target.value; render(); };

  // LOGIN
  const loginSubmit = document.getElementById('login-submit');
  if(loginSubmit){
    document.getElementById('login-email').oninput = e => S.loginForm.email = e.target.value;
    document.getElementById('login-password').oninput = e => S.loginForm.password = e.target.value;
    document.getElementById('login-toggle-pw').onclick = () => { S.loginForm.showPw = !S.loginForm.showPw; render(); };
    loginSubmit.onclick = () => {
      if(!S.loginForm.email || !S.loginForm.password){ S.loginForm.error = "Masukkan email dan kata sandi untuk melanjutkan."; render(); return; }
      S.loginForm.error = ""; S.loggedIn = true; render();
    };
    return;
  }

  // SIDEBAR NAV
  root.querySelectorAll('[data-nav]').forEach(el=>{
    el.onclick = () => {
      const key = el.dataset.nav;
      S.userMenuOpen=false; S.openKebab=null; S.mobileNavOpen=false;
      if(key==='job-description'){ S.page='job-description'; }
      else if(key==='open-branch'){ S.page='open-branch'; }
      else { S.page='placeholder'; S.placeholderLabel=key; }
      render();
    };
  });
  const collapseBtn = document.getElementById('sidebar-collapse-toggle');
  if(collapseBtn) collapseBtn.onclick = () => { S.sidebarCollapsed = !S.sidebarCollapsed; render(); };
  const mobileToggle = document.getElementById('mobile-nav-toggle');
  if(mobileToggle) mobileToggle.onclick = () => { S.mobileNavOpen = !S.mobileNavOpen; render(); };

  // THEME
  const tl = document.getElementById('theme-light'), td = document.getElementById('theme-dark');
  if(tl) tl.onclick = () => { S.theme='light'; render(); };
  if(td) td.onclick = () => { S.theme='dark'; render(); };

  // USER MENU
  const umBtn = document.getElementById('user-menu-btn');
  if(umBtn) umBtn.onclick = (e) => { e.stopPropagation(); S.userMenuOpen = !S.userMenuOpen; render(); };
  const logoutBtn = document.getElementById('logout-btn');
  if(logoutBtn) logoutBtn.onclick = () => { S.userMenuOpen=false; S.modal={kind:'logoutConfirm'}; render(); };

  // OPEN BRANCH SPECIFIC
  bindClick('[data-add-branch]', () => { S.modal = {kind: 'addBranch'}; render(); });
  bindClick('[data-edit-branch]', el => { S.modal = {kind: 'editBranch', id: el.dataset.editBranch}; S.openKebab = null; render(); });
  bindClick('[data-delete-branch]', el => { 
      const b = S.branches.find(x => x.id === el.dataset.deleteBranch);
      S.modal = {kind: 'deleteBranch', id: b.id, entityName: b.name}; 
      S.openKebab = null; render(); 
  });
  bindClick('[data-toggle-branch]', el => {
      const b = S.branches.find(x => x.id === el.dataset.toggleBranch);
      b.status = b.status === 'Aktif' ? 'Non-aktif' : 'Aktif';
      b.lastUpdated = getCurrentDateTime();
      S.openKebab = null; render();
  });
  bindClick('[data-view-branch]', el => {
      S.activeBranchId = el.dataset.viewBranch;
      S.page = 'open-branch-detail';
      S.openKebab = null; render();
  });
  bindClick('[data-view-monitor]', el => {
      S.activeMonitorId = el.dataset.viewMonitor;
      S.page = 'open-branch-monitor';
      render();
  });
  
  // FASUM CRUD
  bindClick('[data-add-fasum]', () => { S.modal = {kind: 'addFasum'}; render(); });
  bindClick('[data-edit-fasum]', el => { S.modal = {kind: 'editFasum', idx: +el.dataset.editFasum}; S.openKebab = null; render(); });
  bindClick('[data-delete-fasum]', el => { S.modal = {kind: 'deleteFasumConfirm', idx: +el.dataset.deleteFasum}; S.openKebab = null; render(); });
  bindClick('[data-save-fasum]', el => {
    const b = S.branches.find(x => x.id === S.activeBranchId);
    const mon = b.monitors.find(x => x.id === S.activeMonitorId);
    const g = id => document.getElementById(id).value;
    const newF = {
      id: 'fsm-' + uid(),
      no: g('fsm-no'), namaArea: g('fsm-nama'), kelurahan: g('fsm-kel'),
      rw: g('fsm-rw'), rt: g('fsm-rt'), lokasiFasum: g('fsm-lokasi'),
      pemohon: g('fsm-pemohon'), status: g('fsm-status'),
      titikKoordinat: g('fsm-koordinat'), linkDokumentasi: g('fsm-linkdok')
    };
    const idx = el.dataset.saveFasum;
    if (idx === 'new') {
      if (!mon.fasumData) mon.fasumData = [];
      mon.fasumData.push(newF);
    } else {
      newF.id = mon.fasumData[+idx].id;
      mon.fasumData[+idx] = newF;
    }
    S.modal = null; render();
  });
  bindClick('[data-confirm-delete-fasum]', el => {
    const b = S.branches.find(x => x.id === S.activeBranchId);
    const mon = b.monitors.find(x => x.id === S.activeMonitorId);
    mon.fasumData.splice(+el.dataset.confirmDeleteFasum, 1);
    S.modal = null; render();
  });

  // PEMASANGAN TIANG CRUD
  bindClick('[data-add-tiang]', () => { S.modal = {kind: 'addTiang'}; render(); });
  bindClick('[data-edit-tiang]', el => { S.modal = {kind: 'editTiang', idx: +el.dataset.editTiang}; S.openKebab = null; render(); });
  bindClick('[data-delete-tiang]', el => { S.modal = {kind: 'deleteTiangConfirm', idx: +el.dataset.deleteTiang}; S.openKebab = null; render(); });
  bindClick('[data-save-tiang]', el => {
    const b = S.branches.find(x => x.id === S.activeBranchId);
    const mon = b.monitors.find(x => x.id === S.activeMonitorId);
    const g = id => document.getElementById(id).value;
    const newT = {
      id: 'ptg-' + uid(),
      no: g('tg-no'), idTiang: g('tg-id'), lokasi: g('tg-lokasi'),
      linkGmaps: g('tg-gmaps'), jenisTiang: g('tg-jenis'),
      statusPekerjaan: g('tg-status-kerja'), statusQC: g('tg-status-qc'),
      linkDokumentasi: g('tg-linkdok'), catatan: g('tg-catatan'),
      lampiranFormQC: g('tg-formqc'), lampiranFormTanam: g('tg-formtanam')
    };
    const idx = el.dataset.saveTiang;
    if (idx === 'new') {
      if (!mon.pemasanganTiangData) mon.pemasanganTiangData = [];
      mon.pemasanganTiangData.push(newT);
    } else {
      newT.id = mon.pemasanganTiangData[+idx].id;
      mon.pemasanganTiangData[+idx] = newT;
    }
    S.modal = null; render();
  });
  bindClick('[data-confirm-delete-tiang]', el => {
    const b = S.branches.find(x => x.id === S.activeBranchId);
    const mon = b.monitors.find(x => x.id === S.activeMonitorId);
    mon.pemasanganTiangData.splice(+el.dataset.confirmDeleteTiang, 1);
    S.modal = null; render();
  });

  // PEMBANGUNAN POP ODC CRUD
  bindClick('[data-add-ppop]', () => { S.modal = {kind: 'addPpop'}; render(); });
  bindClick('[data-edit-ppop]', el => { S.modal = {kind: 'editPpop', idx: +el.dataset.editPpop}; render(); });
  bindClick('[data-delete-ppop]', el => { S.modal = {kind: 'deletePpopConfirm', idx: +el.dataset.deletePpop}; render(); });
  bindClick('[data-save-ppop]', el => {
    const b = S.branches.find(x => x.id === S.activeBranchId);
    const mon = b.monitors.find(x => x.id === S.activeMonitorId);
    const g = id => document.getElementById(id).value;
    const newOpt = {
      id: 'ppop-' + uid(),
      no: g('ppop-no'), surveyor: g('ppop-surveyor'), date: g('ppop-date'),
      status: g('ppop-status'), recommendation: g('ppop-rec'),
      infoLokasi: { fotoLokasi: g('ppop-foto'), alamatLokasi: g('ppop-alamat'), linkGmaps: g('ppop-gmaps') },
      pembangunanODC: { statusRAB: g('ppop-rab'), statusPengadaan: g('ppop-pengadaan'), statusPembangunan: g('ppop-bangun'), statusInstalasi: g('ppop-instalasi'), statusUjiKelayakan: g('ppop-uji') },
      kelistrikanODC: { statusPengajuanPLN: g('ppop-pln'), statusInstalasiListrik: g('ppop-listrik'), statusListrikODC: g('ppop-listrik-odc') },
      aktivasiPerangkat: { statusPersiapan: g('ppop-persiapan'), statusKonfigurasi: g('ppop-konfigurasi'), statusAktivasiODC: g('ppop-aktivasi') },
      dokumentasi: { targetODCReady: g('ppop-target'), aktualODCReady: g('ppop-aktual'), catatanKendala: g('ppop-catatan'), linkDokumentasi: g('ppop-linkdok') }
    };
    const idx = el.dataset.savePpop;
    if (idx === 'new') {
      if (!mon.pembangunanPopData) mon.pembangunanPopData = [];
      mon.pembangunanPopData.push(newOpt);
    } else {
      newOpt.id = mon.pembangunanPopData[+idx].id;
      mon.pembangunanPopData[+idx] = newOpt;
    }
    S.modal = null; render();
  });
  bindClick('[data-confirm-delete-ppop]', el => {
    const b = S.branches.find(x => x.id === S.activeBranchId);
    const mon = b.monitors.find(x => x.id === S.activeMonitorId);
    mon.pembangunanPopData.splice(+el.dataset.confirmDeletePpop, 1);
    S.modal = null; render();
  });

  // ROUTE AREA CRUD
  bindClick('[data-add-route]', () => { S.modal = {kind: 'addRoute'}; render(); });
  bindClick('[data-edit-route]', el => { S.modal = {kind: 'editRoute', idx: +el.dataset.editRoute}; S.openKebab = null; render(); });
  bindClick('[data-delete-route]', el => { S.modal = {kind: 'deleteRouteConfirm', idx: +el.dataset.deleteRoute}; S.openKebab = null; render(); });
  bindClick('[data-save-route]', el => {
    const b = S.branches.find(x => x.id === S.activeBranchId);
    const mon = b.monitors.find(x => x.id === S.activeMonitorId);
    const getJ = n => ({
      kabel: document.getElementById(`rta-j${n}-kabel`).value,
      tube:  document.getElementById(`rta-j${n}-tube`).value,
      core:  document.getElementById(`rta-j${n}-core`).value,
      panjang: document.getElementById(`rta-j${n}-panjang`).value
    });
    const newR = {
      id: 'rta-' + uid(),
      no: document.getElementById('rta-no').value,
      batch: document.getElementById('rta-batch').value,
      warnaArea: document.getElementById('rta-warna').value,
      warnaHex: document.getElementById('rta-hex').value,
      namaArea: document.getElementById('rta-nama').value,
      otb: document.getElementById('rta-otb').value,
      jalur1: getJ(1), cj1: document.getElementById('rta-cj1').value,
      jalur2: getJ(2), cj2: document.getElementById('rta-cj2').value,
      jalur3: getJ(3), cj3: document.getElementById('rta-cj3').value,
      jalur4: getJ(4), cj4: document.getElementById('rta-cj4').value,
      totalPanjang: document.getElementById('rta-total').value,
      statusRoute: document.getElementById('rta-status').value,
      linkDokumentasi: document.getElementById('rta-link').value,
      catatan: document.getElementById('rta-catatan').value
    };
    const idx = el.dataset.saveRoute;
    if (idx === 'new') {
      if (!mon.routeAreaData) mon.routeAreaData = [];
      mon.routeAreaData.push(newR);
    } else {
      newR.id = mon.routeAreaData[+idx].id;
      mon.routeAreaData[+idx] = newR;
    }
    S.modal = null; render();
  });
  bindClick('[data-confirm-delete-route]', el => {
    const b = S.branches.find(x => x.id === S.activeBranchId);
    const mon = b.monitors.find(x => x.id === S.activeMonitorId);
    mon.routeAreaData.splice(+el.dataset.confirmDeleteRoute, 1);
    S.modal = null; render();
  });

  // BOF SELECTION (keputusan lokasi)
  bindClick('[data-save-bof-sel]', () => {
    const selKey = `${S.activeBranchId}:${S.activeMonitorId}`;
    S.bofSelection[selKey] = {
      opsiId: document.getElementById('bof-sel-opsi').value,
      hargaSewa: document.getElementById('bof-sel-harga').value,
      dokumenPlanning: document.getElementById('bof-sel-dokumen').value
    };
    render();
  });

  // BRANCH OFFICE (Opsi Lokasi Kantor Branch) CRUD
  bindClick('[data-add-bof]', () => { S.modal = {kind: 'addBof'}; render(); });
  bindClick('[data-edit-bof]', el => { S.modal = {kind: 'editBof', idx: +el.dataset.editBof}; render(); });
  bindClick('[data-delete-bof]', el => { S.modal = {kind: 'deleteBofConfirm', idx: +el.dataset.deleteBof}; render(); });
  bindClick('[data-save-bof]', el => {
    const b = S.branches.find(x => x.id === S.activeBranchId);
    const mon = b.monitors.find(x => x.id === S.activeMonitorId);

    const newOpt = {
      id: 'bof-' + uid(),
      no: document.getElementById('bof-no').value,
      surveyor: document.getElementById('bof-surveyor').value,
      date: document.getElementById('bof-date').value,
      status: document.getElementById('bof-status').value,
      recommendation: document.getElementById('bof-rec').value,
      identitas: {
        fotoTampakDepan: document.getElementById('bof-foto').value,
        alamat: document.getElementById('bof-alamat').value,
        gmaps: document.getElementById('bof-gmaps').value,
        namaPemilik: document.getElementById('bof-pemilik').value,
        kontakPemilik: document.getElementById('bof-kontak').value,
        jenisBangunan: document.getElementById('bof-jenis').value,
        jumlahLantai: document.getElementById('bof-id-lantai').value,
        jumlahRuangan: document.getElementById('bof-id-ruangan').value
      },
      operasional: {
        jarakAreaPenjualan: document.getElementById('bof-jarak').value,
        aksesKendaraan: document.getElementById('bof-akses').value,
        areaParkir: document.getElementById('bof-parkir').value,
        kondisiLingkungan: document.getElementById('bof-lingkungan').value,
        keamananLingkungan: document.getElementById('bof-keamanan').value
      },
      standarBranch: {
        areaBrainstorming: document.getElementById('bof-brainstorming').value,
        areaMaterialFTTH: document.getElementById('bof-material').value,
        areaTiang: document.getElementById('bof-tiang').value,
        areaIstirahat: document.getElementById('bof-istirahat').value,
        pantry: document.getElementById('bof-pantry').value,
        kamarMandi: document.getElementById('bof-kamarmandi').value
      },
      infoBangunan: {
        luasTanah: document.getElementById('bof-luasTanah').value,
        luasBangunan: document.getElementById('bof-luasBgn').value,
        jumlahLantai: document.getElementById('bof-info-lantai').value,
        jumlahRuangan: document.getElementById('bof-info-ruangan').value,
        hargaSewa: document.getElementById('bof-harga').value
      },
      kondisiBangunan: {
        kondisiBangunan: document.getElementById('bof-kondisi').value,
        kondisiKelistrikan: document.getElementById('bof-listrik').value,
        dayaListrik: document.getElementById('bof-daya').value,
        kondisiAir: document.getElementById('bof-air').value,
        sumberAir: document.getElementById('bof-sumber-air').value,
        estimasiRenovasi: document.getElementById('bof-renovasi').value
      },
      dokumentasi: {
        linkDokumentasi: document.getElementById('bof-linkdok').value
      }
    };

    const idx = el.dataset.saveBof;
    if (idx === 'new') {
      if(!mon.branchOfficeOptions) mon.branchOfficeOptions = [];
      mon.branchOfficeOptions.push(newOpt);
    } else {
      newOpt.id = mon.branchOfficeOptions[+idx].id;
      mon.branchOfficeOptions[+idx] = newOpt;
    }
    S.modal = null; render();
  });
  bindClick('[data-confirm-delete-bof]', el => {
    const b = S.branches.find(x => x.id === S.activeBranchId);
    const mon = b.monitors.find(x => x.id === S.activeMonitorId);
    mon.branchOfficeOptions.splice(+el.dataset.confirmDeleteBof, 1);
    S.modal = null; render();
  });

  // ODC CRUD
  bindClick('[data-add-odc]', () => { S.modal = {kind: 'addOdc'}; render(); });
  bindClick('[data-edit-odc]', el => { S.modal = {kind: 'editOdc', idx: +el.dataset.editOdc}; render(); });
  bindClick('[data-delete-odc]', el => { S.modal = {kind: 'deleteOdcConfirm', idx: +el.dataset.deleteOdc}; render(); });
  bindClick('[data-save-odc]', el => {
      const b = S.branches.find(x => x.id === S.activeBranchId);
      const mon = b.monitors.find(x => x.id === S.activeMonitorId);
      
      const newOpt = {
          id: 'opt-' + uid(),
          no: document.getElementById('odc-no').value,
          surveyor: document.getElementById('odc-surveyor').value,
          date: document.getElementById('odc-date').value,
          branchOption: document.getElementById('odc-branchOpt').value,
          status: document.getElementById('odc-status').value,
          recommendation: document.getElementById('odc-rec').value,
          location: {
              address: document.getElementById('odc-address').value,
              gmaps: document.getElementById('odc-gmaps').value,
              pic: document.getElementById('odc-pic').value,
              landStatus: document.getElementById('odc-land').value
          },
          environment: {
              pengawasan: document.getElementById('odc-pengawasan').value,
              akses: document.getElementById('odc-akses').value,
              terbuka: document.getElementById('odc-terbuka').value,
              matahari: document.getElementById('odc-matahari').value,
              banjir: document.getElementById('odc-banjir').value
          },
          documentation: {
              fileLink: document.getElementById('odc-file').value,
              notes: document.getElementById('odc-notes').value
          }
      };
      
      const idx = el.dataset.saveOdc;
      if (idx === 'new') {
          if(!mon.popOdcOptions) mon.popOdcOptions = [];
          mon.popOdcOptions.push(newOpt);
      } else {
          newOpt.id = mon.popOdcOptions[+idx].id; // preserve id
          mon.popOdcOptions[+idx] = newOpt;
      }
      S.modal = null; render();
  });
  bindClick('[data-confirm-delete-odc]', el => {
      const b = S.branches.find(x => x.id === S.activeBranchId);
      const mon = b.monitors.find(x => x.id === S.activeMonitorId);
      mon.popOdcOptions.splice(+el.dataset.confirmDeleteOdc, 1);
      S.modal = null; render();
  });
  
  // PERMIT CRUD
  bindClick('[data-add-permit]', () => { S.modal = {kind: 'addPermit'}; render(); });
  bindClick('[data-edit-permit]', el => { S.modal = {kind: 'editPermit', idx: +el.dataset.editPermit}; S.openKebab = null; render(); });
  bindClick('[data-delete-permit]', el => { S.modal = {kind: 'deletePermitConfirm', idx: +el.dataset.deletePermit}; S.openKebab = null; render(); });
  bindClick('[data-save-permit]', el => {
      const b = S.branches.find(x => x.id === S.activeBranchId);
      const mon = b.monitors.find(x => x.id === S.activeMonitorId);
      
      const newOpt = {
          id: 'pmt-' + uid(),
          no: document.getElementById('pmt-no').value,
          kecamatan: document.getElementById('pmt-kec').value,
          kelurahan: document.getElementById('pmt-kel').value,
          kodeArea: document.getElementById('pmt-kode').value,
          rw: document.getElementById('pmt-rw').value,
          rt: document.getElementById('pmt-rt').value,
          jenisPermit: document.getElementById('pmt-jenis').value,
          statusPlanner: document.getElementById('pmt-splanner').value,
          picPlanner: document.getElementById('pmt-picplan').value,
          statusPermit: document.getElementById('pmt-spermit').value,
          picPermit: document.getElementById('pmt-picper').value,
          tglProposal: document.getElementById('pmt-tglprop').value,
          tglBak: document.getElementById('pmt-tglbak').value,
          targetSelesai: document.getElementById('pmt-target').value,
          tglSelesai: document.getElementById('pmt-selesai').value,
          jenisKompensasi: document.getElementById('pmt-jkomp').value,
          nilaiKompensasi: document.getElementById('pmt-nkomp').value,
          overallStatus: document.getElementById('pmt-overall').value,
          linkProposal: document.getElementById('pmt-lprop').value,
          linkBak: document.getElementById('pmt-lbak').value,
          keterangan: document.getElementById('pmt-ket').value
      };
      
      const idx = el.dataset.savePermit;
      if (idx === 'new') {
          if(!mon.permitData) mon.permitData = [];
          mon.permitData.push(newOpt);
      } else {
          newOpt.id = mon.permitData[+idx].id;
          mon.permitData[+idx] = newOpt;
      }
      S.modal = null; render();
  });
  bindClick('[data-confirm-delete-permit]', el => {
      const b = S.branches.find(x => x.id === S.activeBranchId);
      const mon = b.monitors.find(x => x.id === S.activeMonitorId);
      mon.permitData.splice(+el.dataset.confirmDeletePermit, 1);
      S.modal = null; render();
  });
  
  // PLAN AREA CRUD
  bindClick('[data-add-plan]', () => { S.modal = {kind: 'addPlanArea'}; render(); });
  bindClick('[data-edit-plan]', el => { S.modal = {kind: 'editPlanArea', idx: +el.dataset.editPlan}; S.openKebab = null; render(); });
  bindClick('[data-delete-plan]', el => { S.modal = {kind: 'deletePlanConfirm', idx: +el.dataset.deletePlan}; S.openKebab = null; render(); });
  bindClick('[data-save-plan]', el => {
      const b = S.branches.find(x => x.id === S.activeBranchId);
      const mon = b.monitors.find(x => x.id === S.activeMonitorId);
      
      const newOpt = {
          id: 'pln-' + uid(),
          no: document.getElementById('pln-no').value,
          namaArea: document.getElementById('pln-nama').value,
          kodeArea: document.getElementById('pln-kode').value,
          kecamatan: document.getElementById('pln-kec').value,
          kelurahan: document.getElementById('pln-kel').value,
          rw: document.getElementById('pln-rw').value,
          totalLuasArea: document.getElementById('pln-tla').value,
          stdLuasArea: document.getElementById('pln-sla').value,
          statusArea: document.getElementById('pln-status').value,
          planRk: document.getElementById('pln-rk').value,
          planOdp: document.getElementById('pln-odp').value,
          jmlTiang: document.getElementById('pln-tiang').value,
          sumberCj: document.getElementById('pln-cj').value,
          keterangan: document.getElementById('pln-ket').value
      };
      
      const idx = el.dataset.savePlan;
      if (idx === 'new') {
          if(!mon.planAreaData) mon.planAreaData = [];
          mon.planAreaData.push(newOpt);
      } else {
          newOpt.id = mon.planAreaData[+idx].id;
          mon.planAreaData[+idx] = newOpt;
      }
      S.modal = null; render();
  });
  bindClick('[data-confirm-delete-plan]', el => {
      const b = S.branches.find(x => x.id === S.activeBranchId);
      const mon = b.monitors.find(x => x.id === S.activeMonitorId);
      mon.planAreaData.splice(+el.dataset.confirmDeletePlan, 1);
      S.modal = null; render();
  });
  
  bindClick('[data-nav-ob-home]', () => { S.page = 'open-branch'; render(); });
  bindClick('[data-nav-ob-branch]', el => { S.page = 'open-branch-detail'; S.activeBranchId = el.dataset.navObBranch; render(); });

  // DIRECTORATE SELECT
  root.querySelectorAll('[data-select-directorate]').forEach(el=>{
    el.onclick = () => { S.activeDirectorateId = el.dataset.selectDirectorate; S.openKebab=null; render(); };
  });
  const addDirBtn = document.getElementById('add-directorate-btn');
  if(addDirBtn) addDirBtn.onclick = () => { S.modal={kind:'addDirectorate'}; render(); };
  const addDirBtnEmpty = document.getElementById('add-directorate-btn-empty');
  if(addDirBtnEmpty) addDirBtnEmpty.onclick = () => { S.modal={kind:'addDirectorate'}; render(); };

  // TOGGLE DIVISION/DEPT
  root.querySelectorAll('[data-toggle-division]').forEach(el=>{
    el.onclick = () => { const id=el.dataset.toggleDivision; S.expandedDivisions.has(id)?S.expandedDivisions.delete(id):S.expandedDivisions.add(id); render(); };
  });
  root.querySelectorAll('[data-toggle-department]').forEach(el=>{
    el.onclick = () => { const id=el.dataset.toggleDepartment; S.expandedDepartments.has(id)?S.expandedDepartments.delete(id):S.expandedDepartments.add(id); render(); };
  });

  // KEBAB MENUS
  root.querySelectorAll('[data-kebab]').forEach(el=>{
    el.onclick = (e) => { e.stopPropagation(); const [type,id] = el.dataset.kebab.split(':'); S.openKebab = kebabOpen(type,id) ? null : {type,id}; render(); };
  });

  // ADD/EDIT/DELETE buttons (contextual + inline)
  bindClick('[data-edit-directorate]', el => { S.modal={kind:'editDirectorate', id:el.dataset.editDirectorate}; });
  bindClick('[data-delete-directorate]', el => { 
    const d = findDirectorate(el.dataset.deleteDirectorate);
    S.modal={kind:'deleteConfirm', entityLabel:'Directorate', entityName:d.name, target:{type:'directorate',id:d.id}, warning: "Deleting this Directorate will permanently remove all of its Divisions, Departments, and Job Roles."}; 
    render(); 
  });
  
  bindClick('[data-add-division]', el => { S.modal={kind:'addDivision', directorateId:el.dataset.addDivision}; });
  bindClick('[data-add-department]', el => { S.modal={kind:'addDepartment', divisionId:el.dataset.addDepartment}; S.openKebab=null; });
  bindClick('[data-add-jobrole]', el => { S.modal={kind:'addJobRole', departmentId:el.dataset.addJobrole}; S.openKebab=null; });
  bindClick('[data-assign-hod]', el => { S.modal={kind:'assignHod', divisionId:el.dataset.assignHod}; });
  bindClick('[data-assign-hodept]', el => { S.modal={kind:'assignHodept', departmentId:el.dataset.assignHodept}; });

  bindClick('[data-edit-division]', el => { S.modal={kind:'editDivision', id:el.dataset.editDivision}; S.openKebab=null; });
  bindClick('[data-delete-division]', el => {
    const v = findDivision(el.dataset.deleteDivision);
    const childCount = v.departments.reduce((a,d)=>a+d.jobRoles.length,0) + v.departments.length;
    S.modal={kind:'deleteConfirm', entityLabel:'Division', entityName:v.name, target:{type:'division',id:v.id},
      warning: childCount ? `Deleting this Division may affect its associated ${v.departments.length} Department(s) and their Job Roles.` : null};
    S.openKebab=null; render();
  });
  bindClick('[data-edit-department]', el => { S.modal={kind:'editDepartment', id:el.dataset.editDepartment}; S.openKebab=null; });
  bindClick('[data-delete-department]', el => {
    const dep = findDepartment(el.dataset.deleteDepartment);
    S.modal={kind:'deleteConfirm', entityLabel:'Department', entityName:dep.name, target:{type:'department',id:dep.id},
      warning: dep.jobRoles.length ? `This department contains ${dep.jobRoles.length} job role(s). Deleting it may affect its associated job roles.` : null};
    S.openKebab=null; render();
  });
  bindClick('[data-delete-role]', el => {
    const r = findJobRole(el.dataset.deleteRole);
    S.modal={kind:'deleteConfirm', entityLabel:'Job Role', entityName:r.name, target:{type:'jobrole',id:r.id}, warning:null};
    S.openKebab=null; render();
  });
  bindClick('[data-remove-hod]', el => {
    const v = findDivision(el.dataset.removeHod);
    S.modal={kind:'deleteConfirm', entityLabel:'Head of Division', entityName:v.headOfDivisionJobRoleId?findJobRole(v.headOfDivisionJobRoleId).name:'', target:{type:'hod',id:v.id}, warning:null};
    S.openKebab=null; render();
  });

  // VIEW / EDIT job description
  bindClick('[data-view-role]', el => { S.detailRoleId = el.dataset.viewRole; S.page='job-description-detail'; S.detailEditMode=false; S.openKebab=null; S.activeSectionKey='identity'; S.openPillars=new Set([0]); render(); document.getElementById('main-scroll-content')?.scrollTo(0,0); });
  bindClick('[data-edit-role]', el => { S.detailRoleId = el.dataset.editRole; S.page='job-description-detail'; S.openKebab=null; S.activeSectionKey='identity'; startEdit(); render(); document.getElementById('main-scroll-content')?.scrollTo(0,0); });

  // BACK BUTTON
  bindClick('[data-bc-home]', () => { S.page = 'job-description'; render(); });

  // MODAL close
  bindClick('[data-close-modal]', () => { S.modal=null; });
  const overlay = document.getElementById('modal-overlay');
  if(overlay) overlay.addEventListener('click', (e)=>{ if(e.target===overlay){ S.modal=null; render(); } });

  // MODAL saves
  bindClick('[data-save-directorate]', el => {
    const name = document.getElementById('modal-input-name').value.trim();
    if(!name) return; const id = el.dataset.saveDirectorate;
    if(id){ findDirectorate(id).name = name; } else { 
      const newId = 'dir-'+uid();
      S.directorates.push({id:newId, name, divisions:[]});
      if(S.directorates.length === 1) S.activeDirectorateId = newId;
    }
    S.modal=null; render();
  });
  bindClick('[data-save-division]', el => {
    const name = document.getElementById('modal-input-name').value.trim();
    const hodName = document.getElementById('modal-input-hod').value.trim();
    if(!name) return;
    const dirId = el.dataset.directorate; const id = el.dataset.saveDivision;
    if(id){ const v = findDivision(id); v.name = name; applyHodName(v, hodName); } 
    else { const newId = 'div-'+uid(); const v = {id:newId, name, directorateId:dirId, headOfDivisionJobRoleId:null, departments:[]}; findDirectorate(dirId).divisions.push(v); applyHodName(v, hodName); S.expandedDivisions.add(newId); }
    S.modal=null; render();
  });
  bindClick('[data-save-department]', el => {
    const name = document.getElementById('modal-input-name').value.trim();
    const hodeptName = document.getElementById('modal-input-hodept').value.trim();
    if(!name) return;
    const divId = el.dataset.division; const id = el.dataset.saveDepartment;
    if(id){ const dep = findDepartment(id); dep.name = name; applyHodeptName(dep, hodeptName); } 
    else { const newId = 'dept-'+uid(); const dep = {id:newId, name, divisionId:divId, headOfDepartmentJobRoleId:null, jobRoles:[]}; findDivision(divId).departments.push(dep); applyHodeptName(dep, hodeptName); S.expandedDepartments.add(newId); }
    S.modal=null; render();
  });
  bindClick('[data-save-jobrole]', el => {
    const name = document.getElementById('modal-input-name').value.trim();
    const type = document.getElementById('modal-input-type').value;
    const supervisor = document.getElementById('modal-input-supervisor').value.trim();
    if(!name) return;
    const depId = el.dataset.saveJobrole; const dep = findDepartment(depId); const newId = 'role-'+uid();
    dep.jobRoles.push({id:newId, name, type, departmentId:depId, supervisor, jd: emptyJD()});
    if(type==='Head of Department') dep.headOfDepartmentJobRoleId = newId;
    S.modal=null; render();
  });
  bindClick('[data-save-hod]', el => {
    const name = document.getElementById('modal-input-name').value.trim();
    if(!name) return; const v = findDivision(el.dataset.saveHod); applyHodName(v, name); S.modal=null; render();
  });
  bindClick('[data-save-hodept]', el => {
    const name = document.getElementById('modal-input-name').value.trim();
    if(!name) return; const dep = findDepartment(el.dataset.saveHodept); applyHodeptName(dep, name); S.modal=null; render();
  });
  bindClick('[data-confirm-delete]', () => {
    const t = S.modal.target;
    if(t.type==='directorate'){
      S.directorates = S.directorates.filter(d => d.id !== t.id);
      if(S.directorates.length > 0) S.activeDirectorateId = S.directorates[0].id;
      else S.activeDirectorateId = null;
    }
    else if(t.type==='division'){ for(const d of S.directorates){ d.divisions = d.divisions.filter(v=>v.id!==t.id); } }
    else if(t.type==='department'){ const dep = findDepartment(t.id); const v = findDivision(dep.divisionId); v.departments = v.departments.filter(d=>d.id!==t.id); }
    else if(t.type==='jobrole'){ const r = findJobRole(t.id); const dep = findDepartment(r.departmentId); if(dep){ dep.jobRoles = dep.jobRoles.filter(x=>x.id!==t.id); if(dep.headOfDepartmentJobRoleId===t.id) dep.headOfDepartmentJobRoleId=null; } }
    else if(t.type==='hod'){ const v = findDivision(t.id); v.headOfDivisionJobRoleId = null; }
    S.modal=null; render();
  });
  bindClick('[data-confirm-logout]', () => { S.loggedIn=false; S.modal=null; S.userMenuOpen=false; render(); });
  bindClick('[data-confirm-discard]', () => { S.detailEditMode=false; S.editDraft=null; S.modal=null; render(); });

  // DETAIL PAGE Actions
  const editBtn = document.getElementById('jd-edit-btn');
  if(editBtn) editBtn.onclick = () => { startEdit(); render(); };
  const cancelBtn = document.getElementById('jd-cancel-edit');
  if(cancelBtn) cancelBtn.onclick = () => {
    if(JSON.stringify(S.editDraft) !== JSON.stringify(findJobRole(S.detailRoleId).jd)){ S.modal = {kind:'discardConfirm'}; render(); } 
    else { S.detailEditMode=false; S.editDraft=null; render(); }
  };
  const saveBtn = document.getElementById('jd-save-edit');
  if(saveBtn) saveBtn.onclick = () => { persistJD(S.detailRoleId, S.editDraft); S.detailEditMode=false; S.editDraft=null; render(); };

  root.querySelectorAll('[data-section-link]').forEach(el=>{
    el.onclick = (e) => { 
      e.preventDefault(); 
      S.activeSectionKey = el.dataset.sectionLink; 
      // Manually scrolling the internal container
      document.getElementById('sec-'+el.dataset.sectionLink)?.scrollIntoView({behavior:'smooth', block:'start'}); 
      document.querySelectorAll('.section-nav-list a').forEach(a => {
        a.classList.toggle('active', a.dataset.sectionLink === S.activeSectionKey);
      });
    };
  });
  root.querySelectorAll('[data-toggle-pillar]').forEach(el=>{
    el.onclick = () => { const i=+el.dataset.togglePillar; if(!S.openPillars) S.openPillars=new Set(); S.openPillars.has(i)?S.openPillars.delete(i):S.openPillars.add(i); render(); };
  });

  // EDIT MODE field bindings
  root.querySelectorAll('[data-field]').forEach(el=>{
    el.addEventListener('input', () => { setDeep(S.editDraft, el.dataset.field, el.value); });
    el.addEventListener('change', () => { setDeep(S.editDraft, el.dataset.field, el.value); });
  });

  bindClick('[data-add-listitem]', el => { const arr=getDeep(S.editDraft, el.dataset.addListitem); arr.push(''); render(); });
  bindClick('[data-remove-listitem]', el => { const [path,idx]=el.dataset.removeListitem.split(':'); const arr=getDeep(S.editDraft,path); arr.splice(+idx,1); render(); });
  bindClick('[data-add-pillar]', () => { S.editDraft.responsibilities.push({pillar:'Pilar Baru', tasks:[]}); render(); });
  bindClick('[data-remove-pillar]', el => { S.editDraft.responsibilities.splice(+el.dataset.removePillar,1); render(); });
  bindClick('[data-add-task]', el => { const pi=+el.dataset.addTask; S.editDraft.responsibilities[pi].tasks.push({title:'',desc:''}); render(); });
  bindClick('[data-remove-task]', el => { const [pi,ti]=el.dataset.removeTask.split(':').map(Number); S.editDraft.responsibilities[pi].tasks.splice(ti,1); render(); });
  
  // KPI bindings
  bindClick('[data-add-kpi]', () => { S.editDraft.kpi.push({keterangan:'',waktu:'',kualitas:'',akurasi:'',biaya:''}); render(); });
  bindClick('[data-remove-kpi]', el => { S.editDraft.kpi.splice(+el.dataset.removeKpi,1); render(); });
  
  bindClick('[data-add-risk]', () => { S.editDraft.risks.push({cat:'',desc:''}); render(); });
  bindClick('[data-remove-risk]', el => { S.editDraft.risks.splice(+el.dataset.removeRisk,1); render(); });
  bindClick('[data-add-comm]', () => { S.editDraft.communication.push({type:'Internal',party:'',purpose:'',output:''}); render(); });
  bindClick('[data-remove-comm]', el => { S.editDraft.communication.splice(+el.dataset.removeComm,1); render(); });
  bindClick('[data-add-cand]', () => { S.editDraft.candidateCompetencies.push({ksao:'',competency:'',category:'Fungsional', documentName:'', documentUrl:''}); render(); });
  bindClick('[data-remove-cand]', el => { S.editDraft.candidateCompetencies.splice(+el.dataset.removeCand,1); render(); });
  
  // Generic Generic Binding updated to handle specific structure per section
  bindClick('[data-add-generic]', el => {
    const key = el.dataset.addGeneric;
    const template = key==='regulations' ? {name:'',link:''} : {method:'',evidence:''};
    S.editDraft[key].push(template); render();
  });
  bindClick('[data-remove-generic]', el => { const [key,idx]=el.dataset.removeGeneric.split(':'); S.editDraft[key].splice(+idx,1); render(); });

  // click outside closes kebab/user menu
  document.addEventListener('click', closeMenusOnce, {once:true});

  // SCROLL SPY for internal container scrolling
  const mainContent = document.getElementById('main-scroll-content');
  if (mainContent && S.page === 'job-description-detail') {
    mainContent.addEventListener('scroll', () => {
      if (scrollTimeout) cancelAnimationFrame(scrollTimeout);
      scrollTimeout = requestAnimationFrame(() => {
        const sections = document.querySelectorAll('.jd-section');
        let currentActive = S.activeSectionKey;
        for (const sec of sections) {
          const rect = sec.getBoundingClientRect();
          // Checking against sticky header offset height roughly (~240px)
          if (rect.top <= 250) { 
            currentActive = sec.id.replace('sec-', '');
          }
        }
        if (currentActive !== S.activeSectionKey) {
          S.activeSectionKey = currentActive;
          document.querySelectorAll('.section-nav-list a').forEach(a => {
            a.classList.toggle('active', a.dataset.sectionLink === currentActive);
          });
        }
      });
    });
  }

  function bindClick(sel, fn){
    root.querySelectorAll(sel).forEach(el=>{ el.onclick = (e)=>{ e.stopPropagation(); fn(el); if(!S.modal || document.getElementById('modal-overlay')) render(); }; });
  }
}

function closeMenusOnce(){
  if(S.openKebab || S.userMenuOpen){ S.openKebab=null; S.userMenuOpen=false; render(); }
}

function applyHodName(division, name){
  if(!name){ return; }
  division.headOfDivisionJobRoleId = 'hodv-'+division.id;
  HOD_NAMES[division.headOfDivisionJobRoleId] = name;
}
function applyHodeptName(dept, name){
  if(!name) return;
  let existing = dept.jobRoles.find(r=>r.id===dept.headOfDepartmentJobRoleId);
  if(existing){ existing.name = "Head of Department " + name; }
  else {
    const newId = 'role-'+uid();
    dept.jobRoles.unshift({id:newId, name:"Head of Department "+name, type:"Head of Department", departmentId:dept.id, supervisor:"", jd: emptyJD()});
    dept.headOfDepartmentJobRoleId = newId;
  }
}
const HOD_NAMES = {};

function startEdit(){
  const r = findJobRole(S.detailRoleId);
  S.editDraft = JSON.parse(JSON.stringify(r.jd));
  
  // Ensure legacy KPI data is mapped and has the correct properties
  S.editDraft.kpi = S.editDraft.kpi.map(k => {
     return {
        keterangan: k.keterangan !== undefined ? k.keterangan : (k.desc || ''),
        waktu: k.waktu !== undefined ? k.waktu : (k.target || ''),
        kualitas: k.kualitas !== undefined ? k.kualitas : '',
        akurasi: k.akurasi !== undefined ? k.akurasi : '',
        biaya: k.biaya !== undefined ? k.biaya : ''
     };
  });
  
  // Ensure legacy data gets new document structures
  S.editDraft.candidateCompetencies.forEach(c => { 
     if(c.documentName === undefined) c.documentName = ''; 
     if(c.documentUrl === undefined) c.documentUrl = ''; 
  });
  S.detailEditMode = true;
}

window.__hodJD = {};
window.persistJD = function(roleId, draft){
  for(const d of S.directorates) for(const v of d.divisions){
    if(v.headOfDivisionJobRoleId===roleId){ window.__hodJD[roleId] = draft; return; }
    for(const dep of v.departments){
      const r = dep.jobRoles.find(x=>x.id===roleId);
      if(r){ r.jd = draft; return; }
    }
  }
};
function persistJD(roleId, draft) { window.persistJD(roleId, draft); }

