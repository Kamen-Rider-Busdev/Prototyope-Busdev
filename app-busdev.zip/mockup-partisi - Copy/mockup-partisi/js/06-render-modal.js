function renderModal(){
  const m = S.modal;

  if (m.kind === 'editFasum' || m.kind === 'addFasum') {
    const isEdit = m.kind === 'editFasum';
    const b = S.branches.find(x => x.id === S.activeBranchId);
    const mon = b.monitors.find(x => x.id === S.activeMonitorId);
    const f = isEdit ? mon.fasumData[m.idx] : {
      no: (mon.fasumData ? mon.fasumData.length + 1 : 1),
      namaArea: '', kelurahan: '', rw: '', rt: '',
      lokasiFasum: '', pemohon: '', status: 'Pending',
      titikKoordinat: '', linkDokumentasi: ''
    };
    const inp = (id, val, ph='') => `<input class="modal-inp" id="${id}" value="${escAttr(val||'')}" placeholder="${ph}">`;
    const lbl = t => `<label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">${t}</label>`;
    const sec = t => `<div class="edit-label" style="border-bottom:1px solid var(--border); padding-bottom:6px; margin-bottom:12px; color:var(--primary);">${t}</div>`;

    return modalShell(isEdit ? 'Edit Data Fasum' : 'Tambah Data Fasum', `
      <div style="display:flex; flex-direction:column; gap:20px;">
        <div>
          ${sec('Informasi Area')}
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
            <div>${lbl('No')}<input class="modal-inp" id="fsm-no" type="number" value="${f.no}"></div>
            <div style="grid-column:1/-1;">${lbl('Nama Area')}${inp('fsm-nama', f.namaArea)}</div>
            <div>${lbl('Kelurahan')}${inp('fsm-kel', f.kelurahan)}</div>
            <div>${lbl('RW')}${inp('fsm-rw', f.rw, 'mis. 01')}</div>
            <div>${lbl('RT')}${inp('fsm-rt', f.rt, 'mis. 02')}</div>
          </div>
        </div>
        <div>
          ${sec('Permintaan Fasum')}
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
            <div style="grid-column:1/-1;">${lbl('Lokasi Fasum')}${inp('fsm-lokasi', f.lokasiFasum, 'mis. Depan Balai RW 01, Jl. Melati No.5')}</div>
            <div style="grid-column:1/-1;">${lbl('Pemohon')}${inp('fsm-pemohon', f.pemohon, 'mis. Ketua RW / Kelurahan')}</div>
            <div style="grid-column:1/-1;">
              ${lbl('Status')}
              <select id="fsm-status" class="modal-inp" style="width:100%;">
                <option ${f.status==='Pending'?'selected':''}>Pending</option>
                <option ${f.status==='On Progress'?'selected':''}>On Progress</option>
                <option ${f.status==='Approved'?'selected':''}>Approved</option>
                <option ${f.status==='Rejected'?'selected':''}>Rejected</option>
              </select>
            </div>
          </div>
        </div>
        <div>
          ${sec('Dokumentasi')}
          <div style="display:grid; grid-template-columns:1fr; gap:12px;">
            <div>${lbl('Titik Koordinat')}${inp('fsm-koordinat', f.titikKoordinat, 'mis. -7.6342, 112.7821')}</div>
            <div>${lbl('Link Dokumentasi')}${inp('fsm-linkdok', f.linkDokumentasi, 'https://...')}</div>
          </div>
        </div>
      </div>
    `, `
      <button class="btn btn-secondary" data-close-modal>Batal</button>
      <button class="btn btn-primary" data-save-fasum="${isEdit ? m.idx : 'new'}">Simpan</button>
    `, true);
  }

  if (m.kind === 'deleteFasumConfirm') {
    return modalShell('Hapus Data Fasum?', `<p style="font-size:14px;margin:0;">Anda yakin ingin menghapus data fasum ini secara permanen?</p>`, `
      <button class="btn btn-secondary" data-close-modal>Batal</button>
      <button class="btn btn-danger" data-confirm-delete-fasum="${m.idx}">${ICONS.trash} Hapus</button>
    `);
  }

  if (m.kind === 'editTiang' || m.kind === 'addTiang') {
    const isEdit = m.kind === 'editTiang';
    const b = S.branches.find(x => x.id === S.activeBranchId);
    const mon = b.monitors.find(x => x.id === S.activeMonitorId);
    const t = isEdit ? mon.pemasanganTiangData[m.idx] : {
      no: (mon.pemasanganTiangData ? mon.pemasanganTiangData.length + 1 : 1),
      idTiang: '', lokasi: '', linkGmaps: '', jenisTiang: '',
      statusPekerjaan: 'Belum Mulai', statusQC: 'Belum QC',
      linkDokumentasi: '', catatan: '', lampiranFormQC: '', lampiranFormTanam: ''
    };
    const inp = (id, val, ph='') => `<input class="modal-inp" id="${id}" value="${escAttr(val||'')}" placeholder="${ph}">`;
    const lbl = text => `<label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">${text}</label>`;
    const sec = text => `<div class="edit-label" style="border-bottom:1px solid var(--border); padding-bottom:6px; margin-bottom:12px; color:var(--primary);">${text}</div>`;

    return modalShell(isEdit ? 'Edit Data Tiang' : 'Tambah Data Tiang', `
      <div style="display:flex; flex-direction:column; gap:20px;">
        <div>
          ${sec('Informasi Tiang')}
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
            <div>${lbl('No')}<input class="modal-inp" id="tg-no" type="number" value="${t.no}"></div>
            <div>${lbl('ID Tiang')}${inp('tg-id', t.idTiang, 'mis. TG-PDN-001')}</div>
            <div style="grid-column:1/-1;">${lbl('Lokasi / Segmen')}${inp('tg-lokasi', t.lokasi, 'mis. Jl. Raya Pandaan Segmen A - RW 01')}</div>
            <div style="grid-column:1/-1;">${lbl('Link Google Maps')}${inp('tg-gmaps', t.linkGmaps, 'https://...')}</div>
            <div style="grid-column:1/-1;">
              ${lbl('Jenis Tiang')}
              <select id="tg-jenis" class="modal-inp" style="width:100%;">
                <option ${t.jenisTiang==='Tiang Beton 9m'?'selected':''}>Tiang Beton 9m</option>
                <option ${t.jenisTiang==='Tiang Beton 11m'?'selected':''}>Tiang Beton 11m</option>
                <option ${t.jenisTiang==='Tiang Besi 7m'?'selected':''}>Tiang Besi 7m</option>
                <option ${t.jenisTiang==='Tiang Besi 9m'?'selected':''}>Tiang Besi 9m</option>
                <option ${t.jenisTiang==='Tiang Kayu'?'selected':''}>Tiang Kayu</option>
              </select>
            </div>
          </div>
        </div>
        <div>
          ${sec('Monitoring')}
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
            <div>
              ${lbl('Status Pekerjaan')}
              <select id="tg-status-kerja" class="modal-inp" style="width:100%;">
                <option ${t.statusPekerjaan==='Belum Mulai'?'selected':''}>Belum Mulai</option>
                <option ${t.statusPekerjaan==='On Progress'?'selected':''}>On Progress</option>
                <option ${t.statusPekerjaan==='Selesai'?'selected':''}>Selesai</option>
              </select>
            </div>
            <div>
              ${lbl('Status QC')}
              <select id="tg-status-qc" class="modal-inp" style="width:100%;">
                <option ${t.statusQC==='Belum QC'?'selected':''}>Belum QC</option>
                <option ${t.statusQC==='Lolos QC'?'selected':''}>Lolos QC</option>
                <option ${t.statusQC==='Revisi'?'selected':''}>Revisi</option>
              </select>
            </div>
            <div style="grid-column:1/-1;">${lbl('Link Dokumentasi')}${inp('tg-linkdok', t.linkDokumentasi, 'https://...')}</div>
            <div style="grid-column:1/-1;">${lbl('Catatan')}<textarea id="tg-catatan" style="width:100%;padding:10px;border:1px solid var(--border-strong);border-radius:var(--radius);background:var(--surface);min-height:50px;">${escHtml(t.catatan||'')}</textarea></div>
            <div style="grid-column:1/-1;">${lbl('Lampiran Form QC (Link)')}${inp('tg-formqc', t.lampiranFormQC, 'https://...')}</div>
            <div style="grid-column:1/-1;">${lbl('Lampiran Form Hasil Penanaman Tiang (Link)')}${inp('tg-formtanam', t.lampiranFormTanam, 'https://...')}</div>
          </div>
        </div>
      </div>
    `, `
      <button class="btn btn-secondary" data-close-modal>Batal</button>
      <button class="btn btn-primary" data-save-tiang="${isEdit ? m.idx : 'new'}">Simpan</button>
    `, true);
  }

  if (m.kind === 'deleteTiangConfirm') {
    return modalShell('Hapus Data Tiang?', `<p style="font-size:14px;margin:0;">Anda yakin ingin menghapus data tiang ini secara permanen?</p>`, `
      <button class="btn btn-secondary" data-close-modal>Batal</button>
      <button class="btn btn-danger" data-confirm-delete-tiang="${m.idx}">${ICONS.trash} Hapus</button>
    `);
  }

  if (m.kind === 'editPpop' || m.kind === 'addPpop') {
    const isEdit = m.kind === 'editPpop';
    const b = S.branches.find(x => x.id === S.activeBranchId);
    const mon = b.monitors.find(x => x.id === S.activeMonitorId);
    const opt = isEdit ? mon.pembangunanPopData[m.idx] : {
      no: (mon.pembangunanPopData ? mon.pembangunanPopData.length + 1 : 1),
      surveyor: '', date: '', status: 'On Progress', recommendation: '',
      infoLokasi: { fotoLokasi: '', alamatLokasi: '', linkGmaps: '' },
      pembangunanODC: { statusRAB: 'Belum Mulai', statusPengadaan: 'Belum Mulai', statusPembangunan: 'Belum Mulai', statusInstalasi: 'Belum Mulai', statusUjiKelayakan: 'Belum Mulai' },
      kelistrikanODC: { statusPengajuanPLN: 'Belum Mulai', statusInstalasiListrik: 'Belum Mulai', statusListrikODC: 'Belum Mulai' },
      aktivasiPerangkat: { statusPersiapan: 'Belum Mulai', statusKonfigurasi: 'Belum Mulai', statusAktivasiODC: 'Belum Mulai' },
      dokumentasi: { targetODCReady: '', aktualODCReady: '', catatanKendala: '', linkDokumentasi: '' }
    };
    const statusOpts = ['Belum Mulai','On Progress','Submitted','Draft','Approved','Done','Aktif'];
    const selStatus = (id, val) => `<select id="${id}" class="modal-inp" style="width:100%;">${statusOpts.map(o=>`<option ${val===o?'selected':''}>${o}</option>`).join('')}</select>`;
    const inp = (id, val, ph='') => `<input class="modal-inp" id="${id}" value="${escAttr(val||'')}" placeholder="${ph}">`;
    const lbl = t => `<label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">${t}</label>`;
    const sec = t => `<div class="edit-label" style="border-bottom:1px solid var(--border); padding-bottom:6px; margin-bottom:12px; color:var(--primary);">${t}</div>`;

    return modalShell(isEdit ? 'Edit Pembangunan POP ODC' : 'Tambah Pembangunan POP ODC', `
      <div style="display:flex; flex-direction:column; gap:20px;">
        <div>
          ${sec('Informasi Umum')}
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
            <div>${lbl('No')}<input class="modal-inp" id="ppop-no" type="number" value="${opt.no}"></div>
            <div>${lbl('Nama Surveyor')}${inp('ppop-surveyor', opt.surveyor)}</div>
            <div>${lbl('Tanggal')}${inp('ppop-date', opt.date, 'DD/MM/YYYY')}</div>
            <div>
              ${lbl('Status')}
              <select id="ppop-status" class="modal-inp" style="width:100%;">
                <option ${opt.status==='On Progress'?'selected':''}>On Progress</option>
                <option ${opt.status==='Survey Selesai'?'selected':''}>Survey Selesai</option>
                <option ${opt.status==='Done'?'selected':''}>Done</option>
                <option ${opt.status==='Pending'?'selected':''}>Pending</option>
              </select>
            </div>
            <div style="grid-column:1/-1;">${lbl('Rekomendasi')}${inp('ppop-rec', opt.recommendation, 'mis. Lanjutkan, Direkomendasikan')}</div>
          </div>
        </div>
        <div>
          ${sec('Informasi Lokasi')}
          <div style="display:grid; grid-template-columns:1fr; gap:12px;">
            <div>${lbl('Foto Lokasi (Link URL)')}${inp('ppop-foto', opt.infoLokasi.fotoLokasi, 'https://...')}</div>
            <div>${lbl('Alamat Lokasi')}${inp('ppop-alamat', opt.infoLokasi.alamatLokasi)}</div>
            <div>${lbl('Link Google Maps')}${inp('ppop-gmaps', opt.infoLokasi.linkGmaps)}</div>
          </div>
        </div>
        <div>
          ${sec('Pembangunan ODC')}
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
            <div>${lbl('Status RAB Material &amp; Perangkat')}${selStatus('ppop-rab', opt.pembangunanODC.statusRAB)}</div>
            <div>${lbl('Status Pengadaan Material ODC')}${selStatus('ppop-pengadaan', opt.pembangunanODC.statusPengadaan)}</div>
            <div>${lbl('Status Pembangunan ODC')}${selStatus('ppop-bangun', opt.pembangunanODC.statusPembangunan)}</div>
            <div>${lbl('Status Instalasi Perangkat ODC')}${selStatus('ppop-instalasi', opt.pembangunanODC.statusInstalasi)}</div>
            <div style="grid-column:1/-1;">${lbl('Status Uji Kelayakan ODC')}${selStatus('ppop-uji', opt.pembangunanODC.statusUjiKelayakan)}</div>
          </div>
        </div>
        <div>
          ${sec('Kelistrikan ODC')}
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
            <div>${lbl('Status Pengajuan PLN')}${selStatus('ppop-pln', opt.kelistrikanODC.statusPengajuanPLN)}</div>
            <div>${lbl('Status Instalasi Listrik PLN')}${selStatus('ppop-listrik', opt.kelistrikanODC.statusInstalasiListrik)}</div>
            <div style="grid-column:1/-1;">${lbl('Status Listrik ODC')}${selStatus('ppop-listrik-odc', opt.kelistrikanODC.statusListrikODC)}</div>
          </div>
        </div>
        <div>
          ${sec('Aktivasi Perangkat')}
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
            <div>${lbl('Status Persiapan Perangkat Jaringan')}${selStatus('ppop-persiapan', opt.aktivasiPerangkat.statusPersiapan)}</div>
            <div>${lbl('Status Konfigurasi Jaringan')}${selStatus('ppop-konfigurasi', opt.aktivasiPerangkat.statusKonfigurasi)}</div>
            <div style="grid-column:1/-1;">${lbl('Status Aktivasi ODC')}${selStatus('ppop-aktivasi', opt.aktivasiPerangkat.statusAktivasiODC)}</div>
          </div>
        </div>
        <div>
          ${sec('Dokumentasi')}
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
            <div>${lbl('Target ODC Ready')}${inp('ppop-target', opt.dokumentasi.targetODCReady, 'DD/MM/YYYY')}</div>
            <div>${lbl('Aktual ODC Ready')}${inp('ppop-aktual', opt.dokumentasi.aktualODCReady, 'DD/MM/YYYY atau -')}</div>
            <div style="grid-column:1/-1;">${lbl('Catatan Kendala')}<textarea id="ppop-catatan" style="width:100%;padding:10px;border:1px solid var(--border-strong);border-radius:var(--radius);background:var(--surface);min-height:50px;">${escHtml(opt.dokumentasi.catatanKendala||'')}</textarea></div>
            <div style="grid-column:1/-1;">${lbl('Link Dokumentasi Lengkap')}${inp('ppop-linkdok', opt.dokumentasi.linkDokumentasi, 'https://...')}</div>
          </div>
        </div>
      </div>
    `, `
      <button class="btn btn-secondary" data-close-modal>Batal</button>
      <button class="btn btn-primary" data-save-ppop="${isEdit ? m.idx : 'new'}">Simpan</button>
    `, true);
  }

  if (m.kind === 'deletePpopConfirm') {
    return modalShell('Hapus Data Pembangunan POP ODC?', `<p style="font-size:14px;margin:0;">Anda yakin ingin menghapus data pembangunan POP ODC ini secara permanen?</p>`, `
      <button class="btn btn-secondary" data-close-modal>Batal</button>
      <button class="btn btn-danger" data-confirm-delete-ppop="${m.idx}">${ICONS.trash} Hapus</button>
    `);
  }

  if (m.kind === 'editRoute' || m.kind === 'addRoute') {
    const isEdit = m.kind === 'editRoute';
    const b = S.branches.find(x => x.id === S.activeBranchId);
    const mon = b.monitors.find(x => x.id === S.activeMonitorId);
    const r = isEdit ? mon.routeAreaData[m.idx] : {
      no: (mon.routeAreaData ? mon.routeAreaData.length + 1 : 1),
      batch: '', warnaArea: '', warnaHex: '', namaArea: '', otb: '',
      jalur1: { kabel: '', tube: '', core: '', panjang: '' }, cj1: '',
      jalur2: { kabel: '', tube: '', core: '', panjang: '' }, cj2: '',
      jalur3: { kabel: '', tube: '', core: '', panjang: '' }, cj3: '',
      jalur4: { kabel: '', tube: '', core: '', panjang: '' }, cj4: '',
      totalPanjang: '', statusRoute: 'Aktif', linkDokumentasi: '', catatan: ''
    };
    const inp = (id, val, ph='') => `<input class="modal-inp" id="${id}" value="${escAttr(val||'')}" placeholder="${ph}">`;
    const jalurBlock = (n, j, cj) => `
      <div style="grid-column:1/-1;">
        <div class="edit-label" style="border-bottom:1px solid var(--border); padding-bottom:5px; margin-bottom:10px; color:var(--primary); font-size:12.5px;">Jalur ${n}</div>
        <div style="display:grid; grid-template-columns:1fr 1fr 1fr 1fr 1fr; gap:10px;">
          <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:3px;">Kabel</label>${inp(`rta-j${n}-kabel`, j.kabel)}</div>
          <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:3px;">Tube</label>${inp(`rta-j${n}-tube`, j.tube)}</div>
          <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:3px;">Core</label>${inp(`rta-j${n}-core`, j.core)}</div>
          <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:3px;">Panjang (m)</label><input class="modal-inp" id="rta-j${n}-panjang" type="number" value="${escAttr(j.panjang||'')}"></div>
          <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:3px;">CJ</label>${inp(`rta-cj${n}`, cj)}</div>
        </div>
      </div>`;

    return modalShell(isEdit ? 'Edit Data Route Area' : 'Tambah Data Route Area', `
      <div style="display:flex; flex-direction:column; gap:16px;">
        <div>
          <div class="edit-label" style="border-bottom:1px solid var(--border); padding-bottom:6px; margin-bottom:12px; color:var(--primary);">Informasi Area</div>
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">No</label><input class="modal-inp" id="rta-no" type="number" value="${r.no}"></div>
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Batch</label>${inp('rta-batch', r.batch, 'mis. Batch 1')}</div>
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Warna Area</label>${inp('rta-warna', r.warnaArea, 'mis. Merah')}</div>
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Kode Warna (hex)</label><input class="modal-inp" id="rta-hex" type="color" value="${escAttr(r.warnaHex||'#cccccc')}" style="height:38px;padding:2px 4px;cursor:pointer;"></div>
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Nama Area</label>${inp('rta-nama', r.namaArea)}</div>
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">OTB</label>${inp('rta-otb', r.otb, 'mis. OTB-001')}</div>
          </div>
        </div>
        <div style="display:grid; grid-template-columns:1fr; gap:12px;">
          ${jalurBlock(1, r.jalur1, r.cj1)}
          ${jalurBlock(2, r.jalur2, r.cj2)}
          ${jalurBlock(3, r.jalur3, r.cj3)}
          ${jalurBlock(4, r.jalur4, r.cj4)}
        </div>
        <div>
          <div class="edit-label" style="border-bottom:1px solid var(--border); padding-bottom:6px; margin-bottom:12px; color:var(--primary);">Monitoring</div>
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Total Panjang (m)</label><input class="modal-inp" id="rta-total" type="number" value="${escAttr(r.totalPanjang||'')}"></div>
            <div>
              <label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Status Route</label>
              <select id="rta-status" class="modal-inp" style="width:100%;">
                <option ${r.statusRoute==='Aktif'?'selected':''}>Aktif</option>
                <option ${r.statusRoute==='Pending'?'selected':''}>Pending</option>
                <option ${r.statusRoute==='Non-aktif'?'selected':''}>Non-aktif</option>
              </select>
            </div>
            <div style="grid-column:1/-1;"><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Link Dokumentasi</label>${inp('rta-link', r.linkDokumentasi, 'https://...')}</div>
            <div style="grid-column:1/-1;"><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Catatan</label><textarea id="rta-catatan" style="width:100%;padding:10px;border:1px solid var(--border-strong);border-radius:var(--radius);background:var(--surface);min-height:50px;">${escHtml(r.catatan||'')}</textarea></div>
          </div>
        </div>
      </div>
    `, `
      <button class="btn btn-secondary" data-close-modal>Batal</button>
      <button class="btn btn-primary" data-save-route="${isEdit ? m.idx : 'new'}">Simpan</button>
    `, true);
  }

  if (m.kind === 'deleteRouteConfirm') {
    return modalShell('Hapus Data Route Area?', `<p style="font-size:14px;margin:0;">Anda yakin ingin menghapus baris data route area ini secara permanen?</p>`, `
      <button class="btn btn-secondary" data-close-modal>Batal</button>
      <button class="btn btn-danger" data-confirm-delete-route="${m.idx}">${ICONS.trash} Hapus</button>
    `);
  }

  if (m.kind === 'editPlanArea' || m.kind === 'addPlanArea') {
      const isEdit = m.kind === 'editPlanArea';
      const b = S.branches.find(x => x.id === S.activeBranchId);
      const mon = b.monitors.find(x => x.id === S.activeMonitorId);
      const p = isEdit ? mon.planAreaData[m.idx] : {
          no: (mon.planAreaData ? mon.planAreaData.length + 1 : 1),
          namaArea: '', kodeArea: '', kecamatan: '', kelurahan: '', rw: '', totalLuasArea: '', stdLuasArea: '100 M - 150 M',
          statusArea: 'Approved', planRk: '', planOdp: '', jmlTiang: '', sumberCj: '', keterangan: ''
      };

      return modalShell(isEdit ? 'Edit Data Plan Area' : 'Tambah Data Plan Area', `
          <div style="display:flex; flex-direction:column; gap:24px;">
              <!-- Informasi Area -->
              <div>
                  <div class="edit-label" style="border-bottom:1px solid var(--border); padding-bottom:6px; margin-bottom:12px; color:var(--primary);">Informasi Area</div>
                  <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
                      <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">No</label><input class="modal-inp" id="pln-no" type="number" value="${p.no}"></div>
                      <div style="grid-column:1/-1;"><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Nama Area</label><input class="modal-inp" id="pln-nama" value="${escAttr(p.namaArea)}"></div>
                      <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Kode Area</label><input class="modal-inp" id="pln-kode" value="${escAttr(p.kodeArea)}"></div>
                      <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Kecamatan</label><input class="modal-inp" id="pln-kec" value="${escAttr(p.kecamatan)}"></div>
                      <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Kelurahan</label><input class="modal-inp" id="pln-kel" value="${escAttr(p.kelurahan)}"></div>
                      <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">RW</label><input class="modal-inp" id="pln-rw" value="${escAttr(p.rw)}"></div>
                      <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Total Luas Area</label><input class="modal-inp" id="pln-tla" value="${escAttr(p.totalLuasArea)}"></div>
                      <div>
                        <label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Standart Luas Area</label>
                        <select id="pln-sla" class="modal-inp" style="width:100%;">
                          <option ${p.stdLuasArea==='< 100 M'?'selected':''}>&lt; 100 M</option>
                          <option ${p.stdLuasArea==='100 M - 150 M'?'selected':''}>100 M - 150 M</option>
                          <option ${p.stdLuasArea==='> 150 M'?'selected':''}>&gt; 150 M</option>
                        </select>
                      </div>
                  </div>
              </div>
              <!-- Perencanaan Area -->
              <div>
                  <div class="edit-label" style="border-bottom:1px solid var(--border); padding-bottom:6px; margin-bottom:12px; color:var(--primary);">Perencanaan Area</div>
                  <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
                      <div>
                        <label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Status Area</label>
                        <select id="pln-status" class="modal-inp" style="width:100%;">
                          <option ${p.statusArea==='Approved'?'selected':''}>Approved</option>
                          <option ${p.statusArea==='Pending'?'selected':''}>Pending</option>
                          <option ${p.statusArea==='Rejected'?'selected':''}>Rejected</option>
                        </select>
                      </div>
                      <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Plan RK</label><input class="modal-inp" id="pln-rk" value="${escAttr(p.planRk)}"></div>
                      <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Plan ODP</label><input class="modal-inp" id="pln-odp" value="${escAttr(p.planOdp)}"></div>
                      <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Jumlah Tiang</label><input class="modal-inp" id="pln-tiang" type="number" value="${escAttr(p.jmlTiang)}"></div>
                      <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Sumber CJ</label><input class="modal-inp" id="pln-cj" value="${escAttr(p.sumberCj)}"></div>
                      <div style="grid-column:1/-1;"><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Catatan</label><textarea id="pln-ket" style="width:100%;padding:10px;border:1px solid var(--border-strong);border-radius:var(--radius);background:var(--surface);min-height:50px;">${escHtml(p.keterangan)}</textarea></div>
                  </div>
              </div>
          </div>
      `, `
          <button class="btn btn-secondary" data-close-modal>Batal</button>
          <button class="btn btn-primary" data-save-plan="${isEdit ? m.idx : 'new'}">Simpan</button>
      `, true);
  }

  if (m.kind === 'deletePlanConfirm') {
      return modalShell('Hapus Data Plan Area?', `<p style="font-size:14px;margin:0;">Anda yakin ingin menghapus baris data plan area ini secara permanen?</p>`, `
          <button class="btn btn-secondary" data-close-modal>Batal</button>
          <button class="btn btn-danger" data-confirm-delete-plan="${m.idx}">${ICONS.trash} Hapus</button>
      `);
  }

  if (m.kind === 'editOdc' || m.kind === 'addOdc') {
      const isEdit = m.kind === 'editOdc';
      const b = S.branches.find(x => x.id === S.activeBranchId);
      const mon = b.monitors.find(x => x.id === S.activeMonitorId);
      const opt = isEdit ? mon.popOdcOptions[m.idx] : {
          no: (mon.popOdcOptions ? mon.popOdcOptions.length + 1 : 1),
          surveyor: '', date: '', branchOption: '', status: '', recommendation: '',
          location: { address: '', gmaps: '', pic: '', landStatus: '' },
          environment: { pengawasan: '', akses: '', terbuka: '', matahari: '', banjir: '' },
          documentation: { fileLink: '', notes: '' }
      };

      return modalShell(isEdit ? 'Edit Opsi Lokasi' : 'Tambah Opsi Lokasi', `
          <div style="display:flex; flex-direction:column; gap:20px;">
              <div>
                  <div class="edit-label" style="border-bottom:1px solid var(--border); padding-bottom:6px; margin-bottom:12px;">Informasi Umum</div>
                  <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
                      <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">No</label><input class="modal-inp" id="odc-no" type="number" value="${opt.no}"></div>
                      <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Nama Surveyor</label><input class="modal-inp" id="odc-surveyor" value="${escAttr(opt.surveyor)}"></div>
                      <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Tanggal</label><input class="modal-inp" id="odc-date" placeholder="DD/MM/YYYY" value="${escAttr(opt.date)}"></div>
                      <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Opsi untuk Branch</label><input class="modal-inp" id="odc-branchOpt" value="${escAttr(opt.branchOption)}"></div>
                      <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Status</label><input class="modal-inp" id="odc-status" value="${escAttr(opt.status)}"></div>
                      <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Rekomendasi</label><input class="modal-inp" id="odc-rec" value="${escAttr(opt.recommendation)}"></div>
                  </div>
              </div>
              <div>
                  <div class="edit-label" style="border-bottom:1px solid var(--border); padding-bottom:6px; margin-bottom:12px;">Identitas Lokasi</div>
                  <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
                      <div style="grid-column:1/-1;"><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Alamat Lengkap</label><input class="modal-inp" id="odc-address" value="${escAttr(opt.location.address)}"></div>
                      <div style="grid-column:1/-1;"><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Link Google Maps</label><input class="modal-inp" id="odc-gmaps" value="${escAttr(opt.location.gmaps)}"></div>
                      <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">PIC / Penanggung Jawab</label><input class="modal-inp" id="odc-pic" value="${escAttr(opt.location.pic)}"></div>
                      <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Status Lahan</label><input class="modal-inp" id="odc-land" value="${escAttr(opt.location.landStatus)}"></div>
                  </div>
              </div>
              <div>
                  <div class="edit-label" style="border-bottom:1px solid var(--border); padding-bottom:6px; margin-bottom:12px;">Keamanan & Kondisi Lingkungan</div>
                  <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
                      <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Pengawasan</label><input class="modal-inp" id="odc-pengawasan" value="${escAttr(opt.environment.pengawasan)}"></div>
                      <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Akses Kendaraan</label><input class="modal-inp" id="odc-akses" value="${escAttr(opt.environment.akses)}"></div>
                      <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Tidak Terlalu Terbuka</label><input class="modal-inp" id="odc-terbuka" value="${escAttr(opt.environment.terbuka)}"></div>
                      <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Terlindung dari Matahari</label><input class="modal-inp" id="odc-matahari" value="${escAttr(opt.environment.matahari)}"></div>
                      <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Risiko Banjir</label><input class="modal-inp" id="odc-banjir" value="${escAttr(opt.environment.banjir)}"></div>
                  </div>
              </div>
              <div>
                  <div class="edit-label" style="border-bottom:1px solid var(--border); padding-bottom:6px; margin-bottom:12px;">Dokumentasi & Rekomendasi</div>
                  <div style="display:grid; grid-template-columns:1fr; gap:12px;">
                      <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Link / Nama File Dokumentasi</label><input class="modal-inp" id="odc-file" value="${escAttr(opt.documentation.fileLink)}"></div>
                      <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Catatan</label><textarea id="odc-notes" style="width:100%;padding:10px;border:1px solid var(--border-strong);border-radius:var(--radius);background:var(--surface);min-height:50px;">${escHtml(opt.documentation.notes)}</textarea></div>
                  </div>
              </div>
          </div>
      `, `
          <button class="btn btn-secondary" data-close-modal>Batal</button>
          <button class="btn btn-primary" data-save-odc="${isEdit ? m.idx : 'new'}">Simpan</button>
      `, true);
  }
  
  if (m.kind === 'deleteOdcConfirm') {
      return modalShell('Hapus Opsi Lokasi?', `<p style="font-size:14px;margin:0;">Anda yakin ingin menghapus opsi lokasi ini secara permanen?</p>`, `
          <button class="btn btn-secondary" data-close-modal>Batal</button>
          <button class="btn btn-danger" data-confirm-delete-odc="${m.idx}">${ICONS.trash} Hapus</button>
      `);
  }

  // PERMIT MODAL
  if (m.kind === 'editPermit' || m.kind === 'addPermit') {
      const isEdit = m.kind === 'editPermit';
      const b = S.branches.find(x => x.id === S.activeBranchId);
      const mon = b.monitors.find(x => x.id === S.activeMonitorId);
      const opt = isEdit ? mon.permitData[m.idx] : {
          no: (mon.permitData ? mon.permitData.length + 1 : 1),
          kecamatan: '', kelurahan: '', kodeArea: '', rw: '', rt: '',
          jenisPermit: 'Izin ODC', statusPlanner: 'Proposal No', picPlanner: '', statusPermit: 'Submitted', picPermit: '',
          tglProposal: '', tglBak: '', targetSelesai: '', tglSelesai: '', jenisKompensasi: '', nilaiKompensasi: '',
          overallStatus: 'On Progress', linkProposal: '', linkBak: '', keterangan: ''
      };

      return modalShell(isEdit ? 'Edit Permit' : 'Tambah Permit', `
          <div style="display:flex; flex-direction:column; gap:20px;">
              <!-- Area -->
              <div>
                  <div class="edit-label" style="border-bottom:1px solid var(--border); padding-bottom:6px; margin-bottom:12px;">Informasi Area</div>
                  <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
                      <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">No</label><input class="modal-inp" id="pmt-no" type="number" value="${opt.no}"></div>
                      <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Kecamatan</label><input class="modal-inp" id="pmt-kec" value="${escAttr(opt.kecamatan)}"></div>
                      <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Kelurahan</label><input class="modal-inp" id="pmt-kel" value="${escAttr(opt.kelurahan)}"></div>
                      <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Kode Area</label><input class="modal-inp" id="pmt-kode" value="${escAttr(opt.kodeArea)}"></div>
                      <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">RW</label><input class="modal-inp" id="pmt-rw" value="${escAttr(opt.rw)}"></div>
                      <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">RT</label><input class="modal-inp" id="pmt-rt" value="${escAttr(opt.rt)}"></div>
                  </div>
              </div>
              <!-- Permit -->
              <div>
                  <div class="edit-label" style="border-bottom:1px solid var(--border); padding-bottom:6px; margin-bottom:12px;">Informasi Permit</div>
                  <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
                      <div>
                        <label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Jenis Permit</label>
                        <select id="pmt-jenis" class="modal-inp" style="width:100%;">
                          <option ${opt.jenisPermit==='Izin ODC'?'selected':''}>Izin ODC</option>
                          <option ${opt.jenisPermit==='Izin Tiang'?'selected':''}>Izin Tiang</option>
                          <option ${opt.jenisPermit==='Izin Tanam'?'selected':''}>Izin Tanam</option>
                        </select>
                      </div>
                      <div>
                        <label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Status Planner</label>
                        <select id="pmt-splanner" class="modal-inp" style="width:100%;">
                          <option ${opt.statusPlanner==='Proposal No'?'selected':''}>Proposal No</option>
                          <option ${opt.statusPlanner==='Survey'?'selected':''}>Survey</option>
                          <option ${opt.statusPlanner==='Done'?'selected':''}>Done</option>
                        </select>
                      </div>
                      <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">PIC Planner</label><input class="modal-inp" id="pmt-picplan" value="${escAttr(opt.picPlanner)}"></div>
                      <div>
                        <label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Status Permit</label>
                        <select id="pmt-spermit" class="modal-inp" style="width:100%;">
                          <option ${opt.statusPermit==='Submitted'?'selected':''}>Submitted</option>
                          <option ${opt.statusPermit==='Approved'?'selected':''}>Approved</option>
                          <option ${opt.statusPermit==='Rejected'?'selected':''}>Rejected</option>
                        </select>
                      </div>
                      <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">PIC Permit</label><input class="modal-inp" id="pmt-picper" value="${escAttr(opt.picPermit)}"></div>
                      <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Tanggal Naik Proposal</label><input class="modal-inp" id="pmt-tglprop" placeholder="DD/MM/YYYY" value="${escAttr(opt.tglProposal)}"></div>
                      <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Tanggal Naik BAK</label><input class="modal-inp" id="pmt-tglbak" placeholder="DD/MM/YYYY" value="${escAttr(opt.tglBak)}"></div>
                      <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Target Selesai</label><input class="modal-inp" id="pmt-target" placeholder="DD/MM/YYYY" value="${escAttr(opt.targetSelesai)}"></div>
                      <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Tanggal Selesai</label><input class="modal-inp" id="pmt-selesai" placeholder="DD/MM/YYYY" value="${escAttr(opt.tglSelesai)}"></div>
                      <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Jenis Kompensasi</label><input class="modal-inp" id="pmt-jkomp" value="${escAttr(opt.jenisKompensasi)}"></div>
                      <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Nilai Kompensasi</label><input class="modal-inp" id="pmt-nkomp" value="${escAttr(opt.nilaiKompensasi)}"></div>
                  </div>
              </div>
              <!-- Progress -->
              <div>
                  <div class="edit-label" style="border-bottom:1px solid var(--border); padding-bottom:6px; margin-bottom:12px;">Monitoring progress</div>
                  <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
                      <div>
                        <label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Overall Status</label>
                        <select id="pmt-overall" class="modal-inp" style="width:100%;">
                          <option ${opt.overallStatus==='On Progress'?'selected':''}>On Progress</option>
                          <option ${opt.overallStatus==='Pending'?'selected':''}>Pending</option>
                          <option ${opt.overallStatus==='Done'?'selected':''}>Done</option>
                        </select>
                      </div>
                      <div></div>
                      <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Link Proposal</label><input class="modal-inp" id="pmt-lprop" value="${escAttr(opt.linkProposal)}"></div>
                      <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Link BAK</label><input class="modal-inp" id="pmt-lbak" value="${escAttr(opt.linkBak)}"></div>
                      <div style="grid-column:1/-1;"><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Keterangan</label><textarea id="pmt-ket" style="width:100%;padding:10px;border:1px solid var(--border-strong);border-radius:var(--radius);background:var(--surface);min-height:50px;">${escHtml(opt.keterangan)}</textarea></div>
                  </div>
              </div>
          </div>
      `, `
          <button class="btn btn-secondary" data-close-modal>Batal</button>
          <button class="btn btn-primary" data-save-permit="${isEdit ? m.idx : 'new'}">Simpan</button>
      `, true);
  }
  
  if (m.kind === 'deletePermitConfirm') {
      return modalShell('Hapus Data Permit?', `<p style="font-size:14px;margin:0;">Anda yakin ingin menghapus baris data permit ini secara permanen?</p>`, `
          <button class="btn btn-secondary" data-close-modal>Batal</button>
          <button class="btn btn-danger" data-confirm-delete-permit="${m.idx}">${ICONS.trash} Hapus</button>
      `);
  }

  if (m.kind === 'editBof' || m.kind === 'addBof') {
    const isEdit = m.kind === 'editBof';
    const b = S.branches.find(x => x.id === S.activeBranchId);
    const mon = b.monitors.find(x => x.id === S.activeMonitorId);
    const opt = isEdit ? mon.branchOfficeOptions[m.idx] : {
      no: (mon.branchOfficeOptions ? mon.branchOfficeOptions.length + 1 : 1),
      surveyor: '', date: '', status: 'Survey Selesai', recommendation: 'Direkomendasikan',
      identitas: { fotoTampakDepan: '', alamat: '', gmaps: '', namaPemilik: '', kontakPemilik: '', jenisBangunan: '', jumlahLantai: '', jumlahRuangan: '' },
      operasional: { jarakAreaPenjualan: '', aksesKendaraan: '', areaParkir: '', kondisiLingkungan: '', keamananLingkungan: '' },
      standarBranch: { areaBrainstorming: 'Ada', areaMaterialFTTH: 'Ada', areaTiang: 'Ada', areaIstirahat: 'Ada', pantry: 'Ada', kamarMandi: '' },
      infoBangunan: { luasTanah: '', luasBangunan: '', jumlahLantai: '', jumlahRuangan: '', hargaSewa: '' },
      kondisiBangunan: { kondisiBangunan: 'Baik', kondisiKelistrikan: 'Baik', dayaListrik: '', kondisiAir: 'Baik', sumberAir: '', estimasiRenovasi: '' },
      dokumentasi: { linkDokumentasi: '' }
    };
    const adaSel = (val) => ['Ada','Tidak Ada'].map(o => `<option ${val===o?'selected':''}>${o}</option>`).join('');

    return modalShell(isEdit ? 'Edit Opsi Lokasi Kantor Branch' : 'Tambah Opsi Lokasi Kantor Branch', `
      <div style="display:flex; flex-direction:column; gap:20px;">
        <div>
          <div class="edit-label" style="border-bottom:1px solid var(--border); padding-bottom:6px; margin-bottom:12px; color:var(--primary);">Informasi Umum</div>
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">No</label><input class="modal-inp" id="bof-no" type="number" value="${opt.no}"></div>
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Nama Surveyor</label><input class="modal-inp" id="bof-surveyor" value="${escAttr(opt.surveyor)}"></div>
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Tanggal</label><input class="modal-inp" id="bof-date" placeholder="DD/MM/YYYY" value="${escAttr(opt.date)}"></div>
            <div>
              <label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Status</label>
              <select id="bof-status" class="modal-inp" style="width:100%;">
                <option ${opt.status==='Survey Selesai'?'selected':''}>Survey Selesai</option>
                <option ${opt.status==='On Survey'?'selected':''}>On Survey</option>
                <option ${opt.status==='Pending'?'selected':''}>Pending</option>
                <option ${opt.status==='Batal'?'selected':''}>Batal</option>
              </select>
            </div>
            <div>
              <label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Rekomendasi</label>
              <select id="bof-rec" class="modal-inp" style="width:100%;">
                <option ${opt.recommendation==='Direkomendasikan'?'selected':''}>Direkomendasikan</option>
                <option ${opt.recommendation==='Pertimbangkan'?'selected':''}>Pertimbangkan</option>
                <option ${opt.recommendation==='Tidak Direkomendasikan'?'selected':''}>Tidak Direkomendasikan</option>
              </select>
            </div>
          </div>
        </div>
        <div>
          <div class="edit-label" style="border-bottom:1px solid var(--border); padding-bottom:6px; margin-bottom:12px; color:var(--primary);">Identitas Lokasi</div>
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
            <div style="grid-column:1/-1;"><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Foto Tampak Depan (Link URL)</label><input class="modal-inp" id="bof-foto" placeholder="https://..." value="${escAttr(opt.identitas.fotoTampakDepan)}"></div>
            <div style="grid-column:1/-1;"><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Alamat Lengkap</label><input class="modal-inp" id="bof-alamat" value="${escAttr(opt.identitas.alamat)}"></div>
            <div style="grid-column:1/-1;"><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Link Gmaps</label><input class="modal-inp" id="bof-gmaps" value="${escAttr(opt.identitas.gmaps)}"></div>
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Nama Pemilik</label><input class="modal-inp" id="bof-pemilik" value="${escAttr(opt.identitas.namaPemilik)}"></div>
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Nomor Kontak Pemilik</label><input class="modal-inp" id="bof-kontak" value="${escAttr(opt.identitas.kontakPemilik)}"></div>
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Jenis Bangunan</label><input class="modal-inp" id="bof-jenis" placeholder="mis. Ruko, Rumah, Gedung" value="${escAttr(opt.identitas.jenisBangunan)}"></div>
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Jumlah Lantai</label><input class="modal-inp" id="bof-id-lantai" type="number" value="${escAttr(opt.identitas.jumlahLantai)}"></div>
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Jumlah Ruangan</label><input class="modal-inp" id="bof-id-ruangan" type="number" value="${escAttr(opt.identitas.jumlahRuangan)}"></div>
          </div>
        </div>
        <div>
          <div class="edit-label" style="border-bottom:1px solid var(--border); padding-bottom:6px; margin-bottom:12px; color:var(--primary);">Lokasi &amp; Operasional</div>
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Jarak ke Area Penjualan Terjauh (Km)</label><input class="modal-inp" id="bof-jarak" placeholder="mis. 5 km" value="${escAttr(opt.operasional.jarakAreaPenjualan)}"></div>
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Akses Kendaraan Operasional</label><input class="modal-inp" id="bof-akses" value="${escAttr(opt.operasional.aksesKendaraan)}"></div>
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Area Parkir</label><input class="modal-inp" id="bof-parkir" placeholder="mis. Ada (10 mobil)" value="${escAttr(opt.operasional.areaParkir)}"></div>
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Kondisi Lingkungan</label><input class="modal-inp" id="bof-lingkungan" value="${escAttr(opt.operasional.kondisiLingkungan)}"></div>
            <div style="grid-column:1/-1;"><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Tingkat Keamanan Lingkungan</label><input class="modal-inp" id="bof-keamanan" value="${escAttr(opt.operasional.keamananLingkungan)}"></div>
          </div>
        </div>
        <div>
          <div class="edit-label" style="border-bottom:1px solid var(--border); padding-bottom:6px; margin-bottom:12px; color:var(--primary);">Kesesuaian Standar Branch</div>
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Area Brainstorming Tersedia</label><select id="bof-brainstorming" class="modal-inp" style="width:100%;">${adaSel(opt.standarBranch.areaBrainstorming)}</select></div>
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Area Penyimpanan Material FTTH</label><select id="bof-material" class="modal-inp" style="width:100%;">${adaSel(opt.standarBranch.areaMaterialFTTH)}</select></div>
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Area Penyimpanan Tiang</label><select id="bof-tiang" class="modal-inp" style="width:100%;">${adaSel(opt.standarBranch.areaTiang)}</select></div>
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Area Istirahat Tim</label><select id="bof-istirahat" class="modal-inp" style="width:100%;">${adaSel(opt.standarBranch.areaIstirahat)}</select></div>
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Pantry / Dapur</label><select id="bof-pantry" class="modal-inp" style="width:100%;">${adaSel(opt.standarBranch.pantry)}</select></div>
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Kamar Mandi</label><input class="modal-inp" id="bof-kamarmandi" placeholder="mis. Ada (2 unit)" value="${escAttr(opt.standarBranch.kamarMandi)}"></div>
          </div>
        </div>
        <div>
          <div class="edit-label" style="border-bottom:1px solid var(--border); padding-bottom:6px; margin-bottom:12px; color:var(--primary);">Informasi Bangunan</div>
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Luas Tanah (m²)</label><input class="modal-inp" id="bof-luasTanah" type="number" value="${escAttr(opt.infoBangunan.luasTanah)}"></div>
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Luas Bangunan (m²)</label><input class="modal-inp" id="bof-luasBgn" type="number" value="${escAttr(opt.infoBangunan.luasBangunan)}"></div>
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Jumlah Lantai</label><input class="modal-inp" id="bof-info-lantai" type="number" value="${escAttr(opt.infoBangunan.jumlahLantai)}"></div>
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Jumlah Ruangan</label><input class="modal-inp" id="bof-info-ruangan" type="number" value="${escAttr(opt.infoBangunan.jumlahRuangan)}"></div>
            <div style="grid-column:1/-1;"><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Harga Sewa</label><input class="modal-inp" id="bof-harga" placeholder="mis. Rp 45.000.000 / tahun" value="${escAttr(opt.infoBangunan.hargaSewa)}"></div>
          </div>
        </div>
        <div>
          <div class="edit-label" style="border-bottom:1px solid var(--border); padding-bottom:6px; margin-bottom:12px; color:var(--primary);">Kondisi Bangunan</div>
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
            <div>
              <label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Kondisi Bangunan</label>
              <select id="bof-kondisi" class="modal-inp" style="width:100%;">
                <option ${opt.kondisiBangunan.kondisiBangunan==='Sangat Baik'?'selected':''}>Sangat Baik</option>
                <option ${opt.kondisiBangunan.kondisiBangunan==='Baik'?'selected':''}>Baik</option>
                <option ${opt.kondisiBangunan.kondisiBangunan==='Cukup Baik'?'selected':''}>Cukup Baik</option>
                <option ${opt.kondisiBangunan.kondisiBangunan==='Perlu Renovasi'?'selected':''}>Perlu Renovasi</option>
              </select>
            </div>
            <div>
              <label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Kondisi Kelistrikan</label>
              <select id="bof-listrik" class="modal-inp" style="width:100%;">
                <option ${opt.kondisiBangunan.kondisiKelistrikan==='Baik'?'selected':''}>Baik</option>
                <option ${opt.kondisiBangunan.kondisiKelistrikan==='Cukup'?'selected':''}>Cukup</option>
                <option ${opt.kondisiBangunan.kondisiKelistrikan==='Perlu Perbaikan'?'selected':''}>Perlu Perbaikan</option>
              </select>
            </div>
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Daya Listrik (VA)</label><input class="modal-inp" id="bof-daya" type="number" placeholder="mis. 3500" value="${escAttr(opt.kondisiBangunan.dayaListrik)}"></div>
            <div>
              <label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Kondisi Air Bersih</label>
              <select id="bof-air" class="modal-inp" style="width:100%;">
                <option ${opt.kondisiBangunan.kondisiAir==='Baik'?'selected':''}>Baik</option>
                <option ${opt.kondisiBangunan.kondisiAir==='Cukup'?'selected':''}>Cukup</option>
                <option ${opt.kondisiBangunan.kondisiAir==='Perlu Perbaikan'?'selected':''}>Perlu Perbaikan</option>
              </select>
            </div>
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Sumber Air</label><input class="modal-inp" id="bof-sumber-air" placeholder="mis. PDAM, Sumur" value="${escAttr(opt.kondisiBangunan.sumberAir)}"></div>
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Estimasi Biaya Renovasi (isi jika perlu)</label><input class="modal-inp" id="bof-renovasi" placeholder="mis. Rp 20.000.000" value="${escAttr(opt.kondisiBangunan.estimasiRenovasi)}"></div>
          </div>
        </div>
        <div>
          <div class="edit-label" style="border-bottom:1px solid var(--border); padding-bottom:6px; margin-bottom:12px; color:var(--primary);">Dokumentasi</div>
          <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Link Dokumentasi Lengkap</label><input class="modal-inp" id="bof-linkdok" placeholder="https://..." value="${escAttr(opt.dokumentasi.linkDokumentasi)}"></div>
        </div>
      </div>
    `, `
      <button class="btn btn-secondary" data-close-modal>Batal</button>
      <button class="btn btn-primary" data-save-bof="${isEdit ? m.idx : 'new'}">Simpan</button>
    `, true);
  }

  if (m.kind === 'deleteBofConfirm') {
    return modalShell('Hapus Opsi Lokasi Kantor Branch?', `<p style="font-size:14px;margin:0;">Anda yakin ingin menghapus opsi lokasi kantor branch ini secara permanen?</p>`, `
      <button class="btn btn-secondary" data-close-modal>Batal</button>
      <button class="btn btn-danger" data-confirm-delete-bof="${m.idx}">${ICONS.trash} Hapus</button>
    `);
  }

  if(m.kind === 'addBranch' || m.kind === 'editBranch') {

    return modalShell(isEdit ? 'Edit Opsi Lokasi Kantor Branch' : 'Tambah Opsi Lokasi Kantor Branch', `
      <div style="display:flex; flex-direction:column; gap:20px;">
        <div>
          <div class="edit-label" style="border-bottom:1px solid var(--border); padding-bottom:6px; margin-bottom:12px;">Informasi Umum</div>
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">No</label><input class="modal-inp" id="bof-no" type="number" value="${opt.no}"></div>
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Nama Surveyor</label><input class="modal-inp" id="bof-surveyor" value="${escAttr(opt.surveyor)}"></div>
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Tanggal</label><input class="modal-inp" id="bof-date" placeholder="DD/MM/YYYY" value="${escAttr(opt.date)}"></div>
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Opsi untuk Branch</label><input class="modal-inp" id="bof-branchOpt" value="${escAttr(opt.branchOption)}"></div>
            <div>
              <label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Status</label>
              <select id="bof-status" class="modal-inp" style="width:100%;">
                <option ${opt.status==='Survey Selesai'?'selected':''}>Survey Selesai</option>
                <option ${opt.status==='On Survey'?'selected':''}>On Survey</option>
                <option ${opt.status==='Pending'?'selected':''}>Pending</option>
                <option ${opt.status==='Batal'?'selected':''}>Batal</option>
              </select>
            </div>
            <div>
              <label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Rekomendasi</label>
              <select id="bof-rec" class="modal-inp" style="width:100%;">
                <option ${opt.recommendation==='Direkomendasikan'?'selected':''}>Direkomendasikan</option>
                <option ${opt.recommendation==='Pertimbangkan'?'selected':''}>Pertimbangkan</option>
                <option ${opt.recommendation==='Tidak Direkomendasikan'?'selected':''}>Tidak Direkomendasikan</option>
              </select>
            </div>
          </div>
        </div>
        <div>
          <div class="edit-label" style="border-bottom:1px solid var(--border); padding-bottom:6px; margin-bottom:12px;">Identitas Lokasi</div>
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
            <div style="grid-column:1/-1;"><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Alamat Lengkap</label><input class="modal-inp" id="bof-address" value="${escAttr(opt.location.address)}"></div>
            <div style="grid-column:1/-1;"><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Link Google Maps</label><input class="modal-inp" id="bof-gmaps" value="${escAttr(opt.location.gmaps)}"></div>
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">PIC / Penanggung Jawab</label><input class="modal-inp" id="bof-pic" value="${escAttr(opt.location.pic)}"></div>
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Status Lahan</label><input class="modal-inp" id="bof-land" placeholder="mis. Sewa / Milik Sendiri" value="${escAttr(opt.location.landStatus)}"></div>
          </div>
        </div>
        <div>
          <div class="edit-label" style="border-bottom:1px solid var(--border); padding-bottom:6px; margin-bottom:12px;">Kondisi Bangunan</div>
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Luas Bangunan</label><input class="modal-inp" id="bof-luasBgn" placeholder="mis. 120 m²" value="${escAttr(opt.building.luasBangunan)}"></div>
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Luas Tanah</label><input class="modal-inp" id="bof-luasTnh" placeholder="mis. 200 m²" value="${escAttr(opt.building.luasTanah)}"></div>
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Jumlah Lantai</label><input class="modal-inp" id="bof-lantai" type="number" value="${escAttr(opt.building.jumlahLantai)}"></div>
            <div>
              <label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Kondisi Bangunan</label>
              <select id="bof-kondisi" class="modal-inp" style="width:100%;">
                <option ${opt.building.kondisi==='Sangat Baik'?'selected':''}>Sangat Baik</option>
                <option ${opt.building.kondisi==='Baik'?'selected':''}>Baik</option>
                <option ${opt.building.kondisi==='Cukup Baik'?'selected':''}>Cukup Baik</option>
                <option ${opt.building.kondisi==='Perlu Renovasi'?'selected':''}>Perlu Renovasi</option>
              </select>
            </div>
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Fasilitas Parkir</label><input class="modal-inp" id="bof-parking" placeholder="mis. Ada (10 mobil)" value="${escAttr(opt.building.fasilitasParking)}"></div>
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Akses Jalan</label><input class="modal-inp" id="bof-akses" placeholder="mis. Jalan utama 2 jalur" value="${escAttr(opt.building.aksesJalan)}"></div>
          </div>
        </div>
        <div>
          <div class="edit-label" style="border-bottom:1px solid var(--border); padding-bottom:6px; margin-bottom:12px;">Informasi Finansial</div>
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Harga Sewa</label><input class="modal-inp" id="bof-harga" placeholder="mis. Rp 45.000.000 / tahun" value="${escAttr(opt.financial.hargaSewa)}"></div>
            <div>
              <label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Status Negosiasi</label>
              <select id="bof-nego" class="modal-inp" style="width:100%;">
                <option ${opt.financial.statusNegotiasi==='Negosiasi'?'selected':''}>Negosiasi</option>
                <option ${opt.financial.statusNegotiasi==='Deal'?'selected':''}>Deal</option>
                <option ${opt.financial.statusNegotiasi==='Batal'?'selected':''}>Batal</option>
              </select>
            </div>
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Uang Muka</label><input class="modal-inp" id="bof-dp" placeholder="mis. Rp 5.000.000" value="${escAttr(opt.financial.uangMuka)}"></div>
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Kontrak Minimal</label><input class="modal-inp" id="bof-kontrak" placeholder="mis. 2 tahun" value="${escAttr(opt.financial.kontrakMin)}"></div>
          </div>
        </div>
        <div>
          <div class="edit-label" style="border-bottom:1px solid var(--border); padding-bottom:6px; margin-bottom:12px;">Dokumentasi & Rekomendasi</div>
          <div style="display:grid; grid-template-columns:1fr; gap:12px;">
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Link / Nama File Dokumentasi</label><input class="modal-inp" id="bof-file" value="${escAttr(opt.documentation.fileLink)}"></div>
            <div><label style="font-size:12px;color:var(--ink-faint);display:block;margin-bottom:4px;">Catatan</label><textarea id="bof-notes" style="width:100%;padding:10px;border:1px solid var(--border-strong);border-radius:var(--radius);background:var(--surface);min-height:60px;">${escHtml(opt.documentation.notes)}</textarea></div>
          </div>
        </div>
      </div>
    `, `
      <button class="btn btn-secondary" data-close-modal>Batal</button>
      <button class="btn btn-primary" data-save-bof="${isEdit ? m.idx : 'new'}">Simpan</button>
    `, true);
  }

  if (m.kind === 'deleteBofConfirm') {
    return modalShell('Hapus Opsi Lokasi Kantor Branch?', `<p style="font-size:14px;margin:0;">Anda yakin ingin menghapus opsi lokasi kantor branch ini secara permanen?</p>`, `
      <button class="btn btn-secondary" data-close-modal>Batal</button>
      <button class="btn btn-danger" data-confirm-delete-bof="${m.idx}">${ICONS.trash} Hapus</button>
    `);
  }

  if(m.kind === 'addBranch' || m.kind === 'editBranch') {
    const editing = m.kind === 'editBranch';
    const b = editing ? S.branches.find(x=>x.id===m.id) : null;
    return modalShell(editing ? 'Edit Branch' : 'Tambah Branch', `
      <div class="field"><label>Nama Branch</label><input id="modal-branch-name" value="${escAttr(b?b.name:'')}" placeholder="mis. Branch Malang"></div>
      <div class="field"><label>Lokasi</label><input id="modal-branch-loc" value="${escAttr(b?b.location:'')}" placeholder="mis. Malang, Jawa Timur"></div>
      <div class="field"><label>Status</label>
        <select id="modal-branch-status">
          <option ${b&&b.status==='Aktif'?'selected':''}>Aktif</option>
          <option ${b&&b.status==='Non-aktif'?'selected':''}>Non-aktif</option>
        </select>
      </div>
    `, `
      <button class="btn btn-secondary" data-close-modal>Batal</button>
      <button class="btn btn-primary" data-save-branch="${editing?b.id:''}">${editing?'Simpan Perubahan':'Simpan'}</button>
    `);
  }
  if(m.kind === 'deleteBranch') {
    return modalShell(`Hapus Branch?`, `
      <p style="font-size:14px;margin:0 0 4px;">Menghapus branch <b>${escHtml(m.entityName)}</b> akan menghapusnya dari daftar Open Branch.</p>
    `, `
      <button class="btn btn-secondary" data-close-modal>Batal</button>
      <button class="btn btn-danger" data-confirm-delete-branch="${m.id}">${ICONS.trash} Hapus</button>
    `);
  }
  if(m.kind==='addDirectorate' || m.kind==='editDirectorate'){
    const editing = m.kind==='editDirectorate';
    const dir = editing ? findDirectorate(m.id) : null;
    return modalShell(editing?'Edit Directorate':'Add Directorate', `<div class="field"><label>Directorate Name</label><input id="modal-input-name" value="${escAttr(dir?dir.name:'')}" placeholder="mis. Business Development"></div>`, `<button class="btn btn-secondary" data-close-modal>Cancel</button><button class="btn btn-primary" data-save-directorate="${editing?dir.id:''}">${editing?'Save Changes':'Add Directorate'}</button>`);
  }
  if(m.kind==='addDivision' || m.kind==='editDivision'){
    const editing = m.kind==='editDivision';
    const div = editing ? findDivision(m.id) : null;
    const dir = findDirectorate(editing?div.directorateId:m.directorateId);
    return modalShell(editing?'Edit Division':'Add Division', `<div class="modal-context">Parent Directorate: <b>${escHtml(dir.name)}</b></div><div class="field"><label>Division Name</label><input id="modal-input-name" value="${escAttr(div?div.name:'')}" placeholder="mis. Human Capital"></div><div class="field"><label>Head of Division (nama, opsional)</label><input id="modal-input-hod" value="${escAttr(div&&div.headOfDivisionJobRoleId?findJobRole(div.headOfDivisionJobRoleId).name.replace('Head of Division ',''):'')}" placeholder="mis. Jane Doe"></div>`, `<button class="btn btn-secondary" data-close-modal>Cancel</button><button class="btn btn-primary" data-save-division="${editing?div.id:''}" data-directorate="${dir.id}">${editing?'Save Changes':'Add Division'}</button>`);
  }
  if(m.kind==='addDepartment' || m.kind==='editDepartment'){
    const editing = m.kind==='editDepartment';
    const dep = editing ? findDepartment(m.id) : null;
    const div = findDivision(editing?dep.divisionId:m.divisionId);
    const dir = findDirectorate(div.directorateId);
    return modalShell(editing?'Edit Department':'Add Department', `<div class="modal-context">Directorate: <b>${escHtml(dir.name)}</b><br>Parent Division: <b>${escHtml(div.name)}</b></div><div class="field"><label>Department Name</label><input id="modal-input-name" value="${escAttr(dep?dep.name:'')}" placeholder="mis. Talent Acquisition"></div><div class="field"><label>Head of Department (nama, opsional)</label><input id="modal-input-hodept" value="${escAttr(dep&&dep.headOfDepartmentJobRoleId?(dep.jobRoles.find(r=>r.id===dep.headOfDepartmentJobRoleId)||{name:''}).name.replace('Head of Department ',''):'')}" placeholder="mis. John Smith"></div>`, `<button class="btn btn-secondary" data-close-modal>Cancel</button><button class="btn btn-primary" data-save-department="${editing?dep.id:''}" data-division="${div.id}">${editing?'Save Changes':'Add Department'}</button>`);
  }
  if(m.kind==='addJobRole'){
    const dep = findDepartment(m.departmentId);
    const div = findDivision(dep.divisionId);
    const dir = findDirectorate(div.directorateId);
    return modalShell('Add Job Role', `<div class="modal-context">Directorate: <b>${escHtml(dir.name)}</b><br>Division / Department: <b>${escHtml(div.name)} / ${escHtml(dep.name)}</b></div><div class="field"><label>Job Role Name</label><input id="modal-input-name" placeholder="mis. Field Talent Recruiter"></div><div class="field"><label>Job Role Type</label><select id="modal-input-type"><option>Staff</option><option>Head of Department</option></select></div><div class="field"><label>Direct Supervisor</label><input id="modal-input-supervisor" placeholder="mis. Head of Department Talent Acquisition"></div><p style="font-size:12.5px;color:var(--ink-faint);margin-top:4px;">14 bagian uraian jabatan dapat dilengkapi setelah Job Role dibuat.</p>`, `<button class="btn btn-secondary" data-close-modal>Cancel</button><button class="btn btn-primary" data-save-jobrole="${dep.id}">Add Job Role</button>`);
  }
  if(m.kind==='assignHod'){
    const div = findDivision(m.divisionId);
    return modalShell('Assign Head of Division', `<div class="modal-context">Division: <b>${escHtml(div.name)}</b></div><div class="field"><label>Nama Head of Division</label><input id="modal-input-name" placeholder="mis. Jane Doe"></div>`, `<button class="btn btn-secondary" data-close-modal>Cancel</button><button class="btn btn-primary" data-save-hod="${div.id}">Assign</button>`);
  }
  if(m.kind==='assignHodept'){
    const dep = findDepartment(m.departmentId);
    return modalShell('Assign Head of Department', `<div class="modal-context">Department: <b>${escHtml(dep.name)}</b></div><div class="field"><label>Nama Head of Department</label><input id="modal-input-name" placeholder="mis. John Smith"></div>`, `<button class="btn btn-secondary" data-close-modal>Cancel</button><button class="btn btn-primary" data-save-hodept="${dep.id}">Assign</button>`);
  }
  if(m.kind==='deleteConfirm'){
    return modalShell(`Delete ${m.entityLabel}?`, `<p style="font-size:14px;margin:0 0 4px;">Are you sure you want to delete <b>${escHtml(m.entityName)}</b>?</p>${m.warning?`<div class="delete-warning">${m.warning}</div>`:''}`, `<button class="btn btn-secondary" data-close-modal>Cancel</button><button class="btn btn-danger" data-confirm-delete="1">${ICONS.trash} Delete ${m.entityLabel}</button>`);
  }
  if(m.kind==='discardConfirm'){
    return modalShell('Discard changes?', `<p style="font-size:14px;margin:0;">Perubahan yang belum disimpan akan hilang.</p>`, `<button class="btn btn-secondary" data-close-modal>Continue Editing</button><button class="btn btn-danger" data-confirm-discard="1">Discard</button>`);
  }
  if(m.kind==='logoutConfirm'){
    return modalShell('Keluar dari akun?', `<p style="font-size:14px;margin:0;">Anda akan keluar dari sesi ini dan kembali ke halaman login.</p>`, `<button class="btn btn-secondary" data-close-modal>Cancel</button><button class="btn btn-danger" data-confirm-logout="1">Keluar</button>`);
  }
  return '';
}

function modalShell(title, body, foot, isWide = false){
  return `
  <div class="modal-overlay" id="modal-overlay">
    <div class="modal ${isWide ? 'modal-wide' : ''}">
      <div class="modal-head"><h3>${title}</h3><button class="modal-close" data-close-modal>${ICONS.close}</button></div>
      <div class="modal-body">${body}</div>
      <div class="modal-foot">${foot}</div>
    </div>
  </div>`;
}

/* ======================= HELPERS ======================= */
