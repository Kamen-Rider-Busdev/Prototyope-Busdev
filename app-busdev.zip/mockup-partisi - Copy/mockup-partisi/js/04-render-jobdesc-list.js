function renderJobDescriptionPage(){
  if(S.directorates.length === 0) {
     return `
     <div class="empty-state" style="margin-top: 40px;">
       <p>Belum ada direktorat.</p>
       <button class="btn btn-primary" id="add-directorate-btn-empty">${ICONS.plus} Add Directorate</button>
     </div>`;
  }

  const dirSource = findDirectorate(S.activeDirectorateId) || S.directorates[0];
  const dir = getFilteredDir(dirSource, S.jdSearchQuery);
  const isSearching = !!S.jdSearchQuery;
  
  return `
  <div class="directorate-selector">
    ${S.directorates.map(d=>`
      <button class="directorate-tab ${d.id===dir.id?'active':''}" data-select-directorate="${d.id}">
        ${d.name} <span class="count">${countJobRoles(d)}</span>
      </button>`).join('')}
    <button class="dir-add-btn" id="add-directorate-btn">${ICONS.plus} Directorate</button>
  </div>
  <div class="toolbar-row" style="margin-bottom: 20px;">
    <div style="position:relative; width: 280px; flex-shrink: 0;">
      <span style="position:absolute; left:10px; top:50%; transform:translateY(-50%); color:var(--ink-faint); display:flex;">${ICONS.search}</span>
      <input type="text" id="jd-search-input" placeholder="Search Job Role, Dept, Div..." value="${escAttr(S.jdSearchQuery)}" style="width:100%; padding: 8px 12px 8px 32px; border:1px solid var(--border-strong); border-radius:var(--radius); font-size:13px; background:var(--surface); color:var(--ink);">
    </div>
    <div style="display:flex; gap:8px;">
      <button class="btn btn-ghost btn-sm" style="color:var(--ink-soft);" data-edit-directorate="${dir.id}">${ICONS.edit} Edit Directorate</button>
      <button class="btn btn-ghost btn-sm" style="color:var(--danger);" data-delete-directorate="${dir.id}">${ICONS.trash} Delete Directorate</button>
      <button class="btn btn-secondary btn-sm" data-add-division="${dir.id}">${ICONS.plus} Add Division</button>
    </div>
  </div>
  <div class="hierarchy-panel">
    <table class="hierarchy-table">
      <thead><tr>
        <th>Organizational Structure</th>
        <th class="col-type">Role Type</th>
        <th class="col-action"></th>
      </tr></thead>
      <tbody>
        ${dir.divisions.length ? dir.divisions.map(v=>renderDivisionRows(dir, v, isSearching)).join('') : `<tr class="empty-row"><td colspan="3">${isSearching ? 'Tidak ada hasil pencarian.' : 'Belum ada divisi pada direktorat ini.'}</td></tr>`}
      </tbody>
    </table>
  </div>`;
}

function countJobRoles(dir){
  let n=0;
  for(const v of dir.divisions){ if(v.headOfDivisionJobRoleId) n++; for(const dep of v.departments){ n += dep.jobRoles.length; } }
  return n;
}

function kebabOpen(type,id){ return S.openKebab && S.openKebab.type===type && S.openKebab.id===id; }

function renderDivisionRows(dir, v, forceExpand = false){
  const expanded = forceExpand || S.expandedDivisions.has(v.id);
  const hod = headOfDivisionRole(v);
  let rows = `
  <tr class="row-division">
    <td>
      <div class="row-inner">
        <button class="toggle-btn" data-toggle-division="${v.id}">${expanded?ICONS.chevronDown:ICONS.chevron}</button>
        <span class="row-icon division-icon">${ICONS.division}</span>
        <span>${escHtml(v.name)}</span>
      </div>
    </td>
    <td class="row-type-cell">Division</td>
    <td class="row-action-cell">
      <button class="kebab-btn" data-kebab="division:${v.id}">${ICONS.kebab}</button>
      ${kebabOpen('division',v.id)?`
      <div class="kebab-menu">
        <button data-edit-division="${v.id}">${ICONS.edit} Edit Division</button>
        <button class="danger" data-delete-division="${v.id}">${ICONS.trash} Delete Division</button>
      </div>`:''}
    </td>
  </tr>`;
  if(!expanded) return rows;

  if(hod){
    rows += `
    <tr class="row-head">
      <td><div class="row-inner" style="padding-left:40px;">
        <span class="connector">↳</span>
        <span class="row-icon">${ICONS.person}</span>
        <div class="role-col">
          <button class="role-name clickable" data-view-role="${hod.id}">${escHtml(hod.name)}</button>
          <span class="role-sub">Head of Division</span>
        </div>
      </div></td>
      <td class="row-type-cell"><span class="badge badge-head">HEAD OF DIVISION</span></td>
      <td class="row-action-cell">
        <button class="kebab-btn" data-kebab="hod:${v.id}">${ICONS.kebab}</button>
        ${kebabOpen('hod',v.id)?`
        <div class="kebab-menu">
          <button data-view-role="${hod.id}">${ICONS.eye} View Job Description</button>
          <button data-edit-role="${hod.id}">${ICONS.edit} Edit Job Description</button>
          <button class="danger" data-remove-hod="${v.id}">${ICONS.trash} Remove Head of Division</button>
        </div>`:''}
      </td>
    </tr>`;
  } else {
    rows += `
    <tr class="row-head">
      <td colspan="3"><div class="add-row-btn-wrap" style="padding-left:40px;">
        <button class="add-inline-btn" data-assign-hod="${v.id}">${ICONS.plus} Assign Head of Division</button>
      </div></td>
    </tr>`;
  }

  rows += v.departments.map(dep=>renderDepartmentRows(dir, v, dep, forceExpand)).join('');
  rows += `
    <tr><td colspan="3"><div class="add-row-btn-wrap" style="padding-left:40px;">
      <button class="add-inline-btn" data-add-department="${v.id}">${ICONS.plus} Add Department</button>
    </div></td></tr>`;
  return rows;
}

function renderDepartmentRows(dir, v, dep, forceExpand = false){
  const expanded = forceExpand || S.expandedDepartments.has(dep.id);
  const hodept = dep.jobRoles.find(r=>r.id===dep.headOfDepartmentJobRoleId);
  const staff = dep.jobRoles.filter(r=>r.id!==dep.headOfDepartmentJobRoleId);
  let rows = `
  <tr class="row-department">
    <td><div class="row-inner" style="padding-left:24px;">
      <button class="toggle-btn" data-toggle-department="${dep.id}">${expanded?ICONS.chevronDown:ICONS.chevron}</button>
      <span class="row-icon dept-icon">${ICONS.dept}</span>
      <span>${escHtml(dep.name)}</span>
    </div></td>
    <td class="row-type-cell">Department · ${dep.jobRoles.length} role</td>
    <td class="row-action-cell">
      <button class="kebab-btn" data-kebab="department:${dep.id}">${ICONS.kebab}</button>
      ${kebabOpen('department',dep.id)?`
      <div class="kebab-menu">
        <button data-edit-department="${dep.id}">${ICONS.edit} Edit Department</button>
        <button class="danger" data-delete-department="${dep.id}">${ICONS.trash} Delete Department</button>
      </div>`:''}
    </td>
  </tr>`;
  if(!expanded) return rows;

  if(hodept){
    rows += roleRow(hodept, "HEAD OF DEPARTMENT", "badge-head", 56);
  } else {
    rows += `<tr class="row-head"><td colspan="3"><div class="add-row-btn-wrap" style="padding-left:56px;">
      <button class="add-inline-btn" data-assign-hodept="${dep.id}">${ICONS.plus} Assign Head of Department</button>
    </div></td></tr>`;
  }
  if(staff.length){
    rows += staff.map(r=>roleRow(r,"STAFF","badge-staff",56)).join('');
  } else {
    rows += `<tr class="empty-row"><td colspan="3"><span style="padding-left:56px;display:block;">Belum ada staff job role.</span></td></tr>`;
  }
  rows += `<tr><td colspan="3"><div class="add-row-btn-wrap" style="padding-left:56px;">
    <button class="add-inline-btn" data-add-jobrole="${dep.id}">${ICONS.plus} Add Job Role</button>
  </div></td></tr>`;
  return rows;
}

function roleRow(role, badgeText, badgeClass, indent){
  return `
  <tr class="row-staff">
    <td><div class="row-inner" style="padding-left:${indent}px;">
      <span class="connector">↳</span>
      <span class="row-icon">${ICONS.person}</span>
      <div class="role-col">
        <button class="role-name clickable" data-view-role="${role.id}">${escHtml(role.name)}</button>
        <span class="role-sub">${role.jd && hasAnyContent(role.jd) ? 'Job description tersedia' : 'Belum lengkap'}</span>
      </div>
    </div></td>
    <td class="row-type-cell"><span class="badge ${badgeClass}">${badgeText}</span></td>
    <td class="row-action-cell">
      <button class="kebab-btn" data-kebab="role:${role.id}">${ICONS.kebab}</button>
      ${kebabOpen('role',role.id)?`
      <div class="kebab-menu">
        <button data-view-role="${role.id}">${ICONS.eye} View Job Description</button>
        <button data-edit-role="${role.id}">${ICONS.edit} Edit Job Description</button>
        <button class="danger" data-delete-role="${role.id}">${ICONS.trash} Delete Job Role</button>
      </div>`:''}
    </td>
  </tr>`;
}

function hasAnyContent(jd){
  return !!(jd.description || jd.objectives.length || jd.responsibilities.length || jd.kpi.length);
}

/* ======================= DETAIL PAGE ======================= */

