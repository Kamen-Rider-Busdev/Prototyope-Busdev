function renderDetailPage(){
  const role = findJobRole(S.detailRoleId);
  if(!role) return `<div class="empty-state"><p>Job role tidak ditemukan.</p></div>`;
  const ctx = jobRoleContext(role.id);
  const jd = S.detailEditMode ? S.editDraft : role.jd;
  
  const statusBadgeClass = S.detailEditMode ? 'badge-draft' : '';
  const statusBadgeText = S.detailEditMode ? 'DRAFT EDIT' : '';

  return `
  <div class="jd-sticky-top-area">
    <button class="btn btn-ghost btn-sm" data-bc-home="1" style="padding-left: 0; margin-bottom: 12px;">${ICONS.back} Kembali</button>

    <div class="jd-overview-card">
      <div class="jd-overview-main">
        <h1>${escHtml(role.name)} ${S.detailEditMode ? `<span class="badge ${statusBadgeClass}">${statusBadgeText}</span>` : ''}</h1>
        <div class="jd-overview-org">
          ${escHtml(ctx.directorate?ctx.directorate.name:'—')} • ${escHtml(ctx.division?ctx.division.name:'—')}${ctx.department?' • '+escHtml(ctx.department.name):''}
        </div>
        <div class="jd-overview-meta">
          <div class="jd-meta-item"><b>Job Type:</b> ${escHtml(role.type)}</div>
          <div class="jd-meta-item"><b>Supervisor:</b> ${escHtml(role.supervisor||'—')}</div>
        </div>
      </div>
      <div class="jd-overview-actions">
        ${S.detailEditMode ? `
          <button class="btn btn-secondary" id="jd-cancel-edit">Cancel</button>
          <button class="btn btn-primary" id="jd-save-edit">Save Changes</button>
        ` : `
          <button class="btn btn-secondary" id="jd-edit-btn">${ICONS.edit} Edit Job Description</button>
        `}
      </div>
    </div>
  </div>

  ${S.detailEditMode?`<div class="edit-banner">${ICONS.edit} Anda sedang dalam mode edit. Perubahan belum tersimpan hingga Anda menekan "Save Changes".</div>`:''}

  <div class="detail-layout">
    <div class="jd-toc-wrapper">
      <div class="jd-toc-card">
        <div class="toc-title">ON THIS PAGE</div>
        <div class="section-nav-list">
          ${SECTION_DEFS.map(s=>`<a href="#sec-${s.key}" class="${S.activeSectionKey===s.key?'active':''}" data-section-link="${s.key}"><span class="n">${s.n}</span> <span class="t">${s.title}</span></a>`).join('')}
        </div>
      </div>
    </div>
    
    <div class="detail-main">
      ${renderSection01Identity(role, ctx)}
      ${renderSection02Description(jd)}
      ${renderSection03Objectives(jd)}
      ${renderSection04Authorities(jd)}
      ${renderSection05Responsibilities(jd)}
      ${renderSection06KPI(jd)}
      ${renderSection07KSAO(jd)}
      ${renderSection08Requirements(jd)}
      ${renderSection09Risks(jd)}
      ${renderSection10Regulations(jd)}
      ${renderSection11Leadership(jd)}
      ${renderSection12Assessments(jd)}
      ${renderSection13Communication(jd)}
      ${renderSection14Candidate(jd)}
    </div>
  </div>`;
}

function sectionHead(n,title){
  return `<div class="jd-section-head"><span class="num">${n}</span><h2>${title}</h2></div>`;
}

function renderSection01Identity(role, ctx){
  return `
  <div class="jd-section jd-section-card" id="sec-identity">
    ${sectionHead("01","Identitas Pekerjaan")}
    <div class="identity-grid">
      <div class="identity-row"><div class="k">Direktorat</div><div class="v">${escHtml(ctx.directorate?ctx.directorate.name:'—')}</div></div>
      <div class="identity-row"><div class="k">Divisi / Departemen</div><div class="v">${escHtml(ctx.division?ctx.division.name:'—')}${ctx.department?' / '+escHtml(ctx.department.name):''}</div></div>
      <div class="identity-row"><div class="k">Nama Jabatan</div><div class="v">${escHtml(role.name)}</div></div>
      <div class="identity-row"><div class="k">Tipe Jabatan</div><div class="v">${escHtml(role.type)}</div></div>
      <div class="identity-row"><div class="k">Atasan Langsung</div><div class="v">${escHtml(role.supervisor||'—')}</div></div>
    </div>
  </div>`;
}

function renderSection02Description(jd){
  const body = S.detailEditMode ? `
    <div class="edit-block">
      <p class="edit-label">Deskripsi Jabatan</p>
      <textarea data-field="description" style="min-height:140px;">${escHtml(jd.description)}</textarea>
    </div>` : (jd.description ? `<div class="narrative"><p>${escHtml(jd.description)}</p></div>` : emptyState("Belum ada deskripsi jabatan untuk Job Role ini."));
  return `<div class="jd-section jd-section-card" id="sec-description">${sectionHead("02","Deskripsi Jabatan")}${body}</div>`;
}

function renderSection03Objectives(jd){
  let body;
  if(S.detailEditMode){
    body = repeatableListEditor('objectives', jd.objectives, "Tambah output utama");
  } else if(jd.objectives.length){
    body = `<div class="outcome-list">${jd.objectives.map((o,i)=>`<div class="outcome-item"><div class="outcome-num">${String(i+1).padStart(2,'0')}</div><div class="outcome-text">${escHtml(o)}</div></div>`).join('')}</div>`;
  } else body = emptyState("Belum ada tujuan jabatan / output utama yang tercatat.");
  return `<div class="jd-section jd-section-card" id="sec-objectives">${sectionHead("03","Tujuan Jabatan / Output Utama")}${body}</div>`;
}

function renderSection04Authorities(jd){
  let body;
  if(S.detailEditMode){
    body = `
    <div class="edit-block"><p class="edit-label">Authority</p>${repeatableListEditor('authorities.granted', jd.authorities.granted, "Tambah wewenang")}</div>
    <div class="edit-block"><p class="edit-label">Limitation</p>${repeatableListEditor('authorities.limitations', jd.authorities.limitations, "Tambah batasan")}</div>
    `;
  } else if(jd.authorities.granted.length || jd.authorities.limitations.length){
    const allAuth = [...jd.authorities.granted, ...jd.authorities.limitations];
    body = `
    <ul class="wewenang-list">
      ${allAuth.map(a => `<li><span class="bullet">•</span> <span>${escHtml(a)}</span></li>`).join('')}
    </ul>`;
  } else body = emptyState("Belum ada data wewenang untuk Job Role ini.");
  return `<div class="jd-section jd-section-card" id="sec-authorities">${sectionHead("04","Wewenang")}${body}</div>`;
}

function renderSection05Responsibilities(jd){
  let body;
  if(S.detailEditMode){
    body = jd.responsibilities.map((p,pi)=>`
      <div class="edit-block" style="border:1px solid var(--border);border-radius:8px;padding:14px 16px;">
        <input data-field="responsibilities.${pi}.pillar" value="${escAttr(p.pillar)}" style="width:100%;border:1px solid var(--border-strong);border-radius:6px;padding:8px 10px;font-weight:600;font-size:13.5px;margin-bottom:10px;">
        ${p.tasks.map((t,ti)=>`
          <div class="repeat-item">
            <div style="flex:1;display:flex;flex-direction:column;gap:6px;">
              <input data-field="responsibilities.${pi}.tasks.${ti}.title" value="${escAttr(t.title)}" placeholder="Judul tugas" style="border:1px solid var(--border-strong);border-radius:6px;padding:7px 9px;font-size:13px;font-weight:600;">
              <textarea data-field="responsibilities.${pi}.tasks.${ti}.desc" placeholder="Deskripsi tugas" style="min-height:44px;">${escHtml(t.desc)}</textarea>
            </div>
            <button class="rm-btn" data-remove-task="${pi}:${ti}">${ICONS.close}</button>
          </div>`).join('')}
        <button class="add-item-btn" data-add-task="${pi}">${ICONS.plus} Tambah tugas</button>
        <button class="btn btn-ghost btn-sm" style="margin-top:8px;color:var(--danger);" data-remove-pillar="${pi}">Hapus pilar ini</button>
      </div>`).join('') + `<button class="add-item-btn" data-add-pillar="1">${ICONS.plus} Tambah pilar tanggung jawab</button>`;
  } else if(jd.responsibilities.length){
    body = `<div class="pillar-accordion">${jd.responsibilities.map((p,i)=>{
      const open = S.openPillars && S.openPillars.has(i);
      return `
      <div class="pillar">
        <button class="pillar-head" data-toggle-pillar="${i}"><span class="t">${escHtml(p.pillar)}</span><span class="n">${open?ICONS.chevronDown:ICONS.chevron} ${p.tasks.length} tugas</span></button>
        ${open?`<div class="pillar-body">${p.tasks.map(t=>`<div class="task-item"><div class="task-title">${escHtml(t.title)}</div><div class="task-desc">${escHtml(t.desc)}</div></div>`).join('')}</div>`:''}
      </div>`;
    }).join('')}</div>`;
  } else body = emptyState("Belum ada tugas dan tanggung jawab yang tercatat.");
  return `<div class="jd-section jd-section-card" id="sec-responsibilities">${sectionHead("05","Tugas dan Tanggung Jawab")}${body}</div>`;
}

function renderSection06KPI(jd){
  let body;
  if(S.detailEditMode){
    body = jd.kpi.map((k,i)=>`
      <div class="repeat-item" style="align-items:flex-start;flex-wrap:wrap;border:1px solid var(--border);border-radius:8px;padding:12px;">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;flex:1;">
          <textarea data-field="kpi.${i}.keterangan" placeholder="Keterangan" style="grid-column:1/-1;min-height:52px;">${escHtml(k.keterangan)}</textarea>
          <input data-field="kpi.${i}.waktu" value="${escAttr(k.waktu)}" placeholder="Waktu" style="border:1px solid var(--border-strong);border-radius:6px;padding:7px 9px;font-size:13px;">
          <input data-field="kpi.${i}.kualitas" value="${escAttr(k.kualitas)}" placeholder="Kualitas" style="border:1px solid var(--border-strong);border-radius:6px;padding:7px 9px;font-size:13px;">
          <input data-field="kpi.${i}.akurasi" value="${escAttr(k.akurasi)}" placeholder="Akurasi" style="border:1px solid var(--border-strong);border-radius:6px;padding:7px 9px;font-size:13px;">
          <input data-field="kpi.${i}.biaya" value="${escAttr(k.biaya)}" placeholder="Biaya" style="border:1px solid var(--border-strong);border-radius:6px;padding:7px 9px;font-size:13px;">
        </div>
        <button class="rm-btn" data-remove-kpi="${i}">${ICONS.close}</button>
      </div>`).join('') + `<button class="add-item-btn" data-add-kpi="1">${ICONS.plus} Tambah KPI</button>`;
  } else if(jd.kpi && jd.kpi.length){
    const cell = val => {
        let s = (val || "").toString().trim();
        return s ? escHtml(s) : "-";
    };
    body = `
    <div style="overflow-x: auto;">
      <table class="comm-table">
        <thead>
          <tr>
            <th>Keterangan</th>
            <th>Waktu</th>
            <th>Kualitas</th>
            <th>Akurasi</th>
            <th>Biaya</th>
          </tr>
        </thead>
        <tbody>
          ${jd.kpi.map(k=>`
          <tr>
            <td>${cell(k.keterangan)}</td>
            <td>${cell(k.waktu)}</td>
            <td>${cell(k.kualitas)}</td>
            <td>${cell(k.akurasi)}</td>
            <td>${cell(k.biaya)}</td>
          </tr>`).join('')}
        </tbody>
      </table>
    </div>`;
  } else body = emptyState("Belum ada standar kinerja / KPI / SLA yang tercatat.");
  return `<div class="jd-section jd-section-card" id="sec-kpi">${sectionHead("06","Standar Kinerja / KPI / SLA")}${body}</div>`;
}

function renderSection07KSAO(jd){
  const cats = [
    ["knowledge","K","KNOWLEDGE","Pengetahuan yang Dipersyaratkan"],
    ["skill","S","SKILL","Aktivitas / Metode Kerja"],
    ["ability","A","ABILITY","Masalah yang Harus Diselesaikan"],
    ["other","O","OTHER CHARACTERISTICS","Orientasi / Karakteristik"]
  ];
  const hasAny = cats.some(([k])=>jd.ksao[k].length);
  let body;
  if(S.detailEditMode){
    body = `<div class="ksao-grid">${cats.map(([key,letter,mainLbl,subLbl])=>`
      <div class="ksao-card"><div class="ksao-head"><div class="ksao-letter">${letter}</div><div class="label">${mainLbl}</div><div class="sub-label">${subLbl}</div></div>
      ${repeatableListEditor('ksao.'+key, jd.ksao[key], "Tambah item")}
      </div>`).join('')}</div>`;
  } else if(hasAny){
    body = `<div class="ksao-grid">${cats.map(([key,letter,mainLbl,subLbl])=>`
      <div class="ksao-card ksao-${letter}"><div class="ksao-head"><div class="ksao-letter">${letter}</div><div class="label">${mainLbl}</div><div class="sub-label">${subLbl}</div></div>
      <ul>${jd.ksao[key].map(x=>`<li>${escHtml(x)}</li>`).join('') || `<li style="color:var(--ink-faint); list-style:none; padding-left:0;">Belum ada data.</li>`}</ul>
      </div>`).join('')}</div>`;
  } else body = emptyState("Belum ada pemetaan kompetensi (KSAO) untuk Job Role ini.");
  return `<div class="jd-section jd-section-card" id="sec-ksao">${sectionHead("07","Pemetaan Kompetensi (KSAO)")}${body}</div>`;
}

function renderSection08Requirements(jd){
  const r = jd.requirements;
  let body;
  if(S.detailEditMode){
    body = `
    <div class="edit-block"><p class="edit-label">Pendidikan</p><textarea data-field="requirements.pendidikan" style="min-height:60px;">${escHtml(r.pendidikan)}</textarea></div>
    <div class="edit-block"><p class="edit-label">Pengalaman</p>${repeatableListEditor('requirements.pengalaman', r.pengalaman, "Tambah butir pengalaman")}</div>
    <div class="edit-block"><p class="edit-label">Keterampilan Teknis</p>${repeatableListEditor('requirements.teknis', r.teknis, "Tambah keterampilan teknis")}</div>
    <div class="edit-block"><p class="edit-label">Keterampilan Non Teknis</p>${repeatableListEditor('requirements.nonTeknis', r.nonTeknis, "Tambah keterampilan non teknis")}</div>`;
  } else if(r.pendidikan || r.pengalaman.length || r.teknis.length || r.nonTeknis.length){
    body = `<div class="req-grid">
      ${r.pendidikan?`<div class="req-card"><div class="req-card-head">PENDIDIKAN</div><div class="req-card-body">${escHtml(r.pendidikan)}</div></div>`:''}
      ${r.pengalaman.length?`<div class="req-card"><div class="req-card-head">PENGALAMAN</div><div class="req-card-body"><ul>${r.pengalaman.map(x=>`<li>${escHtml(x)}</li>`).join('')}</ul></div></div>`:''}
      ${r.teknis.length?`<div class="req-card"><div class="req-card-head">KETERAMPILAN TEKNIS</div><div class="req-card-body"><ul>${r.teknis.map(x=>`<li>${escHtml(x)}</li>`).join('')}</ul></div></div>`:''}
      ${r.nonTeknis.length?`<div class="req-card"><div class="req-card-head">KETERAMPILAN NON TEKNIS</div><div class="req-card-body"><ul>${r.nonTeknis.map(x=>`<li>${escHtml(x)}</li>`).join('')}</ul></div></div>`:''}
    </div>`;
  } else body = emptyState("Belum ada persyaratan jabatan yang tercatat.");
  return `<div class="jd-section jd-section-card" id="sec-requirements">${sectionHead("08","Persyaratan Jabatan")}${body}</div>`;
}

function renderSection09Risks(jd){
  let body;
  if(S.detailEditMode){
    body = jd.risks.map((r,i)=>`
      <div class="repeat-item" style="border:1px solid var(--border);border-radius:8px;padding:12px;">
        <div style="flex:1;display:flex;flex-direction:column;gap:6px;">
          <input data-field="risks.${i}.cat" value="${escAttr(r.cat)}" placeholder="Kategori risiko" style="border:1px solid var(--border-strong);border-radius:6px;padding:7px 9px;font-size:13px;font-weight:600;">
          <textarea data-field="risks.${i}.desc" placeholder="Deskripsi risiko" style="min-height:50px;">${escHtml(r.desc)}</textarea>
        </div>
        <button class="rm-btn" data-remove-risk="${i}">${ICONS.close}</button>
      </div>`).join('') + `<button class="add-item-btn" data-add-risk="1">${ICONS.plus} Tambah risiko</button>`;
  } else if(jd.risks.length){
    body = `<div class="risk-grid">${jd.risks.map(r=>`<div class="risk-card"><div class="risk-cat">${escHtml(r.cat.toUpperCase())}</div><div class="risk-desc">${escHtml(r.desc)}</div></div>`).join('')}</div>`;
  } else body = emptyState("Belum ada risiko jabatan yang tercatat.");
  return `<div class="jd-section jd-section-card" id="sec-risks">${sectionHead("09","Risiko Jabatan")}${body}</div>`;
}

function genericEmptyListSection(n,title,key,jd,addLabel,fields){
  const items = jd[key] || [];
  let body;
  if(S.detailEditMode){
    body = items.map((it,i)=>`
      <div class="repeat-item" style="border:1px solid var(--border);border-radius:8px;padding:12px;">
        <div style="flex:1;display:flex;flex-direction:column;gap:6px;">
          ${fields.map(f=>`<input data-field="${key}.${i}.${f.key}" value="${escAttr(it[f.key]||'')}" placeholder="${f.label}" style="border:1px solid var(--border-strong);border-radius:6px;padding:7px 9px;font-size:13px;">`).join('')}
        </div>
        <button class="rm-btn" data-remove-generic="${key}:${i}">${ICONS.close}</button>
      </div>`).join('') + `<button class="add-item-btn" data-add-generic="${key}">${ICONS.plus} ${addLabel}</button>`;
  } else if(items.length){
    body = `<div class="req-grid">${items.map(it=>`<div class="req-card"><div class="req-card-body" style="display:flex; flex-direction:column; gap:6px;">${fields.map(f=>{
        let val = (it[f.key]||'').trim();
        if(!val) val = '—';
        let displayVal = escHtml(val);
        if(f.key === 'link' && val.startsWith('http')) {
            displayVal = `<a href="${escAttr(val)}" class="doc-link" target="_blank" onclick="event.stopPropagation()">${ICONS.link} Buka Tautan</a>`;
        }
        return `<div><b>${f.label}:</b> ${displayVal}</div>`;
    }).join('')}</div></div>`).join('')}</div>`;
  } else {
    body = emptyState(`Belum ada ${title.toLowerCase()} yang terhubung dengan Job Description ini.`, S.detailEditMode?null:`data-add-generic="${key}"`, addLabel);
  }
  return `<div class="jd-section jd-section-card" id="sec-${key}">${sectionHead(n,title)}${body}</div>`;
}

function renderSection10Regulations(jd){
  return genericEmptyListSection("10","Regulasi / Standar yang Berlaku","regulations",jd,"Tambahkan Regulasi",[{key:"name",label:"Nama Dokumen"},{key:"link",label:"Link Dokumen"}]);
}
function renderSection11Leadership(jd){
  let body;
  if(S.detailEditMode){
    body = repeatableListEditor('leadership', jd.leadership, "Tambah tanggung jawab kepemimpinan");
  } else if(jd.leadership.length){
    body = `<div class="outcome-list">${jd.leadership.map((o,i)=>`<div class="outcome-item"><div class="outcome-num">${i+1}</div><div class="outcome-text">${escHtml(o)}</div></div>`).join('')}</div>`;
  } else body = emptyState("Belum ada data tanggung jawab kepemimpinan untuk Job Role ini.");
  return `<div class="jd-section jd-section-card" id="sec-leadership">${sectionHead("11","Tanggung Jawab Kepemimpinan")}${body}</div>`;
}
function renderSection12Assessments(jd){
  return genericEmptyListSection("12","Bukti / Metode Asesmen","assessments",jd,"Tambahkan Metode Asesmen",[{key:"method",label:"Assessment Method"},{key:"evidence",label:"Evidence"}]);
}

function renderSection13Communication(jd){
  let body;
  if(S.detailEditMode){
    body = jd.communication.map((c,i)=>`
      <div class="repeat-item" style="border:1px solid var(--border);border-radius:8px;padding:12px;flex-wrap:wrap;">
        <div style="flex:1;display:grid;grid-template-columns:1fr 1fr;gap:8px;min-width:260px;">
          <select data-field="communication.${i}.type"><option ${c.type==='Internal'?'selected':''}>Internal</option><option ${c.type==='External'?'selected':''}>External</option></select>
          <input data-field="communication.${i}.party" value="${escAttr(c.party)}" placeholder="Pihak" style="border:1px solid var(--border-strong);border-radius:6px;padding:7px 9px;font-size:13px;">
          <textarea data-field="communication.${i}.purpose" placeholder="Tujuan komunikasi & koordinasi" style="grid-column:1/-1;min-height:44px;">${escHtml(c.purpose)}</textarea>
          <textarea data-field="communication.${i}.output" placeholder="Output yang diharapkan" style="grid-column:1/-1;min-height:44px;">${escHtml(c.output)}</textarea>
        </div>
        <button class="rm-btn" data-remove-comm="${i}">${ICONS.close}</button>
      </div>`).join('') + `<button class="add-item-btn" data-add-comm="1">${ICONS.plus} Tambah relasi komunikasi</button>`;
  } else if(jd.communication.length){
    const internal = jd.communication.filter(c=>c.type==='Internal');
    const external = jd.communication.filter(c=>c.type==='External');
    body = `
    ${internal.length? `<p class="comm-sub">INTERNAL</p>` + commTable(internal) : emptyState("Belum ada relasi komunikasi internal.")}
    <div style="margin-top:24px;">
    ${external.length? `<p class="comm-sub">EXTERNAL</p>` + commTable(external) : emptyState("Belum ada relasi komunikasi eksternal.")}
    </div>
    `;
  } else body = emptyState("Belum ada data hubungan kerja / komunikasi untuk Job Role ini.");
  return `<div class="jd-section jd-section-card" id="sec-communication">${sectionHead("13","Hubungan Kerja / Komunikasi")}${body}</div>`;
}
function commTable(rows){
  return `<table class="comm-table"><thead><tr><th>Pihak</th><th>Tujuan Komunikasi &amp; Koordinasi</th><th>Output yang Diharapkan</th></tr></thead>
  <tbody>${rows.map(c=>`<tr><td>${escHtml(c.party)}</td><td>${escHtml(c.purpose)}</td><td>${escHtml(c.output)}</td></tr>`).join('')}</tbody></table>`;
}

function renderSection14Candidate(jd){
  let body;
  if(S.detailEditMode){
    body = jd.candidateCompetencies.map((c,i)=>`
      <div class="repeat-item" style="border:1px solid var(--border);border-radius:8px;padding:12px;">
        <div style="flex:1;display:flex;flex-direction:column;gap:6px;">
          <input data-field="candidateCompetencies.${i}.ksao" value="${escAttr(c.ksao)}" placeholder="KSAO (mis. K, S, A)" style="border:1px solid var(--border-strong);border-radius:6px;padding:7px 9px;font-size:13px;">
          <input data-field="candidateCompetencies.${i}.competency" value="${escAttr(c.competency)}" placeholder="Kandidat kompetensi" style="border:1px solid var(--border-strong);border-radius:6px;padding:7px 9px;font-size:13px;">
          <select data-field="candidateCompetencies.${i}.category"><option ${c.category==='Fungsional'?'selected':''}>Fungsional</option><option ${c.category==='Managerial'?'selected':''}>Managerial</option></select>
          <div style="display:flex;gap:6px; margin-top: 4px;">
             <input data-field="candidateCompetencies.${i}.documentName" value="${escAttr(c.documentName || '')}" placeholder="Nama Dokumen (opsional)" style="flex:1;border:1px solid var(--border-strong);border-radius:6px;padding:7px 9px;font-size:13px;">
             <input data-field="candidateCompetencies.${i}.documentUrl" value="${escAttr(c.documentUrl || '')}" placeholder="URL Dokumen" style="flex:1;border:1px solid var(--border-strong);border-radius:6px;padding:7px 9px;font-size:13px;">
          </div>
        </div>
        <button class="rm-btn" data-remove-cand="${i}">${ICONS.close}</button>
      </div>`).join('') + `<button class="add-item-btn" data-add-cand="1">${ICONS.plus} Tambah kandidat kompetensi</button>`;
  } else if(jd.candidateCompetencies.length){
    body = `<div style="overflow-x:auto;"><table class="comm-table"><thead><tr><th>KSAO</th><th>Kandidat Kompetensi</th><th>Kategori</th><th>Dokumen</th></tr></thead>
    <tbody>${jd.candidateCompetencies.map(c=>`
      <tr>
        <td><div class="matrix-badges">${['K','S','A','O'].map(l=>`<span class="mini-badge ${(c.ksao||'').includes(l)?'on':''}">${l}</span>`).join('')}</div></td>
        <td>${escHtml(c.competency)}</td>
        <td>${escHtml(c.category)}</td>
        <td>${c.documentUrl ? `<a href="${escAttr(c.documentUrl)}" class="doc-link" target="_blank" onclick="event.stopPropagation()">${ICONS.link} ${escHtml(c.documentName || 'Lihat Dokumen')}</a>` : '<span class="doc-empty">Belum tersedia</span>'}</td>
      </tr>
    `).join('')}</tbody></table></div>`;
  } else body = emptyState("Belum ada kandidat kompetensi & kategorisasi untuk Job Role ini.");
  return `<div class="jd-section jd-section-card" id="sec-candidateCompetencies">${sectionHead("14","Kandidat Kompetensi & Kategorisasi")}${body}</div>`;
}

function emptyState(text, addAttr, addLabel){
  return `<div class="empty-state"><p>${text}</p>${addAttr?`<button class="btn btn-secondary btn-sm" ${addAttr}>${ICONS.plus} ${addLabel}</button>`:''}</div>`;
}

function repeatableListEditor(pathBase, items, addLabel){
  return items.map((v,i)=>`
    <div class="repeat-item">
      <textarea data-field="${pathBase}.${i}">${escHtml(v)}</textarea>
      <button class="rm-btn" data-remove-listitem="${pathBase}:${i}">${ICONS.close}</button>
    </div>`).join('') + `<button class="add-item-btn" data-add-listitem="${pathBase}">${ICONS.plus} ${addLabel}</button>`;
}

/* ======================= MODALS ======================= */
