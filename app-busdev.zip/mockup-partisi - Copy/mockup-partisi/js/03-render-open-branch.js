function renderPlaceholderPage(){
  const names = {"dwp-sop":"DWP/SOP","open-branch":"Open Branch","kuartal":"Kuartal","project-management-bqg":"Project Management","project-management-sgp":"Project Management"};
  const name = names[S.placeholderLabel] || "Modul ini";
  return `
  <div class="page-head"><h1>${name}</h1></div>
  <div class="placeholder-panel">
    <div class="icon">${ICONS.inbox}</div>
    <h3>Coming in a future phase</h3>
    <p>Modul ${name} akan tersedia pada tahap pengembangan berikutnya.</p>
  </div>`;
}

/* ======================= OPEN BRANCH PAGE ======================= */

function renderOpenBranchPage(){
  const q = S.obSearchQuery.toLowerCase();
  const filteredBranches = S.branches.filter(b => b.name.toLowerCase().includes(q) || b.location.toLowerCase().includes(q));
    
  let rows = filteredBranches.length ? filteredBranches.map((b, i) => {
    const badgeCls = b.status === 'Aktif' ? 'badge-status' : 'badge-nonaktif';
    return `<tr>
      <td>${String(i+1).padStart(2,'0')}</td>
      <td style="font-weight:600;">${escHtml(b.name)}</td>
      <td>${escHtml(b.location)}</td>
      <td><span class="badge ${badgeCls}">${escHtml(b.status)}</span></td>
      <td>
        <div class="progress-cell">
          <span>${b.progress}%</span>
          <div class="progress-track"><div class="progress-fill" style="width:${b.progress}%"></div></div>
        </div>
      </td>
      <td style="color:var(--ink-faint);">${escHtml(b.lastUpdated)}</td>
      <td style="text-align: right; position: relative;">
        <button class="kebab-btn" data-kebab="branch:${b.id}">${ICONS.kebab}</button>
        ${kebabOpen('branch', b.id) ? `
        <div class="kebab-menu">
          <button data-view-branch="${b.id}">${ICONS.eye} Lihat Dashboard</button>
          <button data-edit-branch="${b.id}">${ICONS.edit} Edit Branch</button>
          <button data-toggle-branch="${b.id}">${b.status === 'Aktif' ? 'Non-aktifkan' : 'Aktifkan'}</button>
          <button class="danger" data-delete-branch="${b.id}">${ICONS.trash} Hapus Branch</button>
        </div>` : ''}
      </td>
    </tr>`;
  }).join('') : `<tr><td colspan="7" style="text-align:center; padding: 32px; color:var(--ink-faint);">Tidak ada hasil.</td></tr>`;

  return `
  <div class="page-head" style="margin-bottom: 24px;">
    <h1 style="margin-bottom:16px;">Open Branch</h1>
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 16px;">
      <div style="position:relative; width: 300px;">
         <span style="position:absolute; left:10px; top:50%; transform:translateY(-50%); color:var(--ink-faint); display:flex;">${ICONS.search}</span>
         <input type="text" id="ob-search-input" placeholder="Search Branch, Lokasi..." value="${escAttr(S.obSearchQuery)}" style="width:100%; padding: 8px 12px 8px 32px; border:1px solid var(--border-strong); border-radius:var(--radius); font-size:13px; background:var(--surface); color:var(--ink);">
      </div>
    </div>
    <button class="btn btn-primary" data-add-branch="1" style="width:100%; padding: 12px; font-weight: 600; display:flex; justify-content:center;">${ICONS.plus} Tambah Branch</button>
  </div>
  <div style="overflow-x: auto;">
    <table class="data-table">
      <thead><tr><th style="width:50px;">No</th><th>Branch</th><th>Lokasi</th><th>Status</th><th>Progress</th><th>Last Update</th><th style="width:60px; text-align:right;">Action</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>
  </div>
  `;
}

function renderBranchDetailPage() {
  const b = S.branches.find(x => x.id === S.activeBranchId);
  if (!b) return '';
  const badgeCls = b.status === 'Aktif' ? 'badge-status' : 'badge-nonaktif';
  
  let rows = b.monitors.map((m, i) => {
    const mBadgeCls = m.status === 'Aktif' ? 'badge-status' : 'badge-nonaktif';
    return `<tr>
      <td>${String(i+1).padStart(2,'0')}</td>
      <td style="font-weight:500;">${escHtml(m.name)}</td>
      <td><span class="badge ${mBadgeCls}">${escHtml(m.status)}</span></td>
      <td>
        <div class="progress-cell">
          <span>${m.progress}%</span>
          <div class="progress-track"><div class="progress-fill" style="width:${m.progress}%"></div></div>
        </div>
      </td>
      <td style="color:var(--ink-faint);">${escHtml(m.lastUpdated)}</td>
      <td style="text-align: right;">
        <button class="btn btn-ghost btn-sm" data-view-monitor="${m.id}">Lihat</button>
      </td>
    </tr>`;
  }).join('');

  return `
  <button class="btn btn-ghost btn-sm" data-nav-ob-home="1" style="padding-left: 0; margin-bottom: 12px;">${ICONS.back} Kembali</button>
  <div class="ob-header-context">
    <div style="display:flex; justify-content:space-between; align-items:flex-start; flex-wrap: wrap; gap: 16px;">
      <div>
        <h2 style="margin:0 0 4px; font-size: 20px;">${escHtml(b.name)}</h2>
        <div style="font-size:13.5px; color:var(--ink-soft); margin-bottom:8px;">${escHtml(b.location)}</div>
        <div style="display:flex; gap:16px; font-size:13px; flex-wrap: wrap;">
          <div><span style="color:var(--ink-faint);">Status:</span> <span class="badge ${badgeCls}">${escHtml(b.status)}</span></div>
          <div><span style="color:var(--ink-faint);">Last Update:</span> ${escHtml(b.lastUpdated)}</div>
        </div>
      </div>
      <button class="btn btn-secondary btn-sm" data-edit-branch="${b.id}">${ICONS.edit} Edit Branch</button>
    </div>
  </div>
  <h3 style="font-size:16px; margin: 24px 0 12px;">Dashboard Monitoring</h3>
  <div style="overflow-x: auto;">
    <table class="data-table">
      <thead><tr><th style="width:50px;">No</th><th>Dashboard Monitoring</th><th>Status</th><th>Progress</th><th>Last Update</th><th style="width:80px; text-align:right;">Action</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>
  </div>
  `;
}

function renderMonitorDetailPage() {
  const b = S.branches.find(x => x.id === S.activeBranchId);
  if (!b) return '';
  const m = b.monitors.find(x => x.id === S.activeMonitorId);
  if (!m) return '';
  
  let content = '';
  
  if (m.name === 'Opsi Lokasi POP ODC' && m.popOdcOptions) {
     content = `
       <div class="pop-odc-container" style="margin-top: 24px;">
          ${m.popOdcOptions.map((opt, i) => `
             <div class="pop-odc-card">
                <div class="pop-odc-card-header">
                   <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:12px;">
                       <h3 style="margin:0; font-size:16px; font-weight:600; color:var(--primary);">Opsi Lokasi POP ODC #${i+1}</h3>
                       <div style="display:flex; gap:8px;">
                           <button class="btn btn-ghost btn-sm" style="padding:4px 8px; color:var(--ink-soft);" data-edit-odc="${i}">${ICONS.edit} Edit</button>
                           <button class="btn btn-ghost btn-sm" style="padding:4px 8px; color:var(--danger);" data-delete-odc="${i}">${ICONS.trash} Hapus</button>
                       </div>
                   </div>
                   <div class="pop-odc-header-grid">
                      <div class="grid-item"><span class="lbl">No</span><span class="val">: ${opt.no}</span></div>
                      <div class="grid-item"><span class="lbl">Nama Surveyor</span><span class="val">: ${escHtml(opt.surveyor)}</span></div>
                      <div class="grid-item"><span class="lbl">Tanggal</span><span class="val">: ${escHtml(opt.date)}</span></div>
                      <div class="grid-item"><span class="lbl">Opsi untuk Branch</span><span class="val">: ${escHtml(opt.branchOption)}</span></div>
                      <div class="grid-item"><span class="lbl">Status</span><span class="val">: ${escHtml(opt.status)}</span></div>
                      <div class="grid-item"><span class="lbl">Rekomendasi</span><span class="val">: ${escHtml(opt.recommendation)}</span></div>
                   </div>
                </div>
                <div class="pop-odc-table-wrapper" style="overflow-x:auto;">
                   <table class="data-table pop-odc-table" style="border:none; border-radius:0;">
                      <thead>
                         <tr><th style="border-top:none;">Kategori</th><th style="border-top:none;">Indikator</th><th style="border-top:none;">Keterangan</th></tr>
                      </thead>
                      <tbody>
                         <!-- Identitas Lokasi -->
                         <tr><td rowspan="4">Identitas Lokasi</td><td>Alamat Lengkap</td><td>${escHtml(opt.location.address)}</td></tr>
                         <tr><td>Link Google Maps</td><td>${opt.location.gmaps ? `<a href="${escAttr(opt.location.gmaps)}" class="doc-link" target="_blank">${ICONS.link} Buka Maps</a>` : '-'}</td></tr>
                         <tr><td>PIC / Penanggung Jawab Lokasi</td><td>${escHtml(opt.location.pic)}</td></tr>
                         <tr><td>Status Lahan</td><td>${escHtml(opt.location.landStatus)}</td></tr>
                         
                         <!-- Keamanan & Kondisi Lingkungan -->
                         <tr><td rowspan="5">Keamanan & Kondisi Lingkungan</td><td>Ada Pihak yang Melakukan Pengawasan</td><td>${escHtml(opt.environment.pengawasan)}</td></tr>
                         <tr><td>Akses Kendaraan Operasional</td><td>${escHtml(opt.environment.akses)}</td></tr>
                         <tr><td>Lokasi Tidak Terlalu Terbuka</td><td>${escHtml(opt.environment.terbuka)}</td></tr>
                         <tr><td>Terlindung dari Matahari Langsung</td><td>${escHtml(opt.environment.matahari)}</td></tr>
                         <tr><td>Risiko Banjir</td><td>${escHtml(opt.environment.banjir)}</td></tr>
                         
                         <!-- Dokumentasi & Rekomendasi -->
                         <tr><td rowspan="2">Dokumentasi & Rekomendasi</td><td>Link Dokumentasi</td><td>${opt.documentation.fileLink ? `<a href="${opt.documentation.fileLink.startsWith('http') ? escAttr(opt.documentation.fileLink) : '#'}" class="doc-link" target="${opt.documentation.fileLink.startsWith('http')?'_blank':'_self'}">${ICONS.link} ${escHtml(opt.documentation.fileLink)}</a>` : '-'}</td></tr>
                         <tr><td>Catatan</td><td>${escHtml(opt.documentation.notes)}</td></tr>
                      </tbody>
                   </table>
                </div>
             </div>
          `).join('')}
          <button class="btn btn-secondary" data-add-odc="1" style="margin-top:8px;">${ICONS.plus} Tambah Opsi Lokasi</button>
       </div>
     `;
  } else if (m.name === 'Permit' && m.permitData) {
      const cell = val => {
          let s = (val || "").toString().trim();
          if(!s) return "-";
          if(s.startsWith('http')) return `<a href="${escAttr(s)}" class="doc-link" target="_blank">${ICONS.link} Buka Tautan</a>`;
          return escHtml(s);
      };
      
      content = `
          <div style="display:flex; justify-content:space-between; align-items:flex-end; margin-bottom:12px; margin-top:24px;">
              <h3 style="margin:0; font-size:16px;">Data Permit</h3>
              <button class="btn btn-primary btn-sm" data-add-permit="1">${ICONS.plus} Tambah Data Permit</button>
          </div>
          <div style="overflow-x:auto; padding-bottom:16px;">
             <table class="data-table" style="min-width:1800px;">
                <thead>
                   <tr>
                      <th colspan="6" class="th-group-1">Informasi Area</th>
                      <th colspan="11" class="th-group-2">Informasi Permit</th>
                      <th colspan="5" class="th-group-3">Monitoring progress</th>
                   </tr>
                   <tr>
                      <!-- Area -->
                      <th>No</th><th>Kecamatan</th><th>Kelurahan</th><th>Kode Area</th><th>RW</th><th>RT</th>
                      <!-- Permit -->
                      <th>Jenis Permit</th><th>Status Planner</th><th>PIC Planner</th><th>Status Permit</th><th>PIC Permit</th><th>Tanggal Naik Proposal</th><th>Tanggal Naik BAK</th><th>Target Selesai</th><th>Tanggal Selesai</th><th>Jenis Kompensasi</th><th>Nilai Kompensasi</th>
                      <!-- Monitoring -->
                      <th>Overall Status</th><th>Link Proposal</th><th>Link BAK</th><th>Keterangan</th><th style="text-align:center;">Action</th>
                   </tr>
                </thead>
                <tbody>
                   ${m.permitData.length ? m.permitData.map((p, i) => `
                     <tr>
                        <td>${cell(p.no)}</td>
                        <td>${cell(p.kecamatan)}</td>
                        <td>${cell(p.kelurahan)}</td>
                        <td>${cell(p.kodeArea)}</td>
                        <td>${cell(p.rw)}</td>
                        <td>${cell(p.rt)}</td>
                        
                        <td>${cell(p.jenisPermit)}</td>
                        <td>${cell(p.statusPlanner)}</td>
                        <td>${cell(p.picPlanner)}</td>
                        <td>${cell(p.statusPermit)}</td>
                        <td>${cell(p.picPermit)}</td>
                        <td>${cell(p.tglProposal)}</td>
                        <td>${cell(p.tglBak)}</td>
                        <td>${cell(p.targetSelesai)}</td>
                        <td>${cell(p.tglSelesai)}</td>
                        <td>${cell(p.jenisKompensasi)}</td>
                        <td>${cell(p.nilaiKompensasi)}</td>
                        
                        <td><span class="badge ${p.overallStatus==='Done'?'badge-status':(p.overallStatus==='Pending'?'badge-nonaktif':'badge-draft')}">${cell(p.overallStatus)}</span></td>
                        <td>${cell(p.linkProposal)}</td>
                        <td>${cell(p.linkBak)}</td>
                        <td>${cell(p.keterangan)}</td>
                        
                        <td style="text-align:center; position:relative;">
                          <button class="kebab-btn" data-kebab="permit:${p.id}">${ICONS.kebab}</button>
                          ${kebabOpen('permit', p.id) ? `
                          <div class="kebab-menu" style="right:14px;">
                            <button data-edit-permit="${i}">${ICONS.edit} Edit</button>
                            <button class="danger" data-delete-permit="${i}">${ICONS.trash} Hapus</button>
                          </div>` : ''}
                        </td>
                     </tr>
                   `).join('') : `<tr><td colspan="22" style="text-align:center; padding:32px; color:var(--ink-faint);">Belum ada Data Permit.</td></tr>`}
                </tbody>
             </table>
          </div>
      `;
  } else if (m.name === 'Plan Area' && m.planAreaData) {
      const cell = val => {
          let s = (val || "").toString().trim();
          return s ? escHtml(s) : "-";
      };
      
      content = `
          <div style="display:flex; flex-wrap: wrap; gap: 24px; margin-top:24px; padding: 16px; border:1px dashed var(--border-strong); border-radius: 8px; background:var(--dept-bg);">
              <div><span style="color:var(--ink-faint); font-size:12.5px;">PIC Task:</span> <span style="font-weight:500; font-size:13.5px;">BL (saat selesai training)</span></div>
              <div><span style="color:var(--ink-faint); font-size:12.5px;">Link Planning RK/ODP (Google Earth):</span> <a href="#" class="doc-link">Link GE Pandaan 1, 2 Gempol</a></div>
          </div>
          
          <div style="display:flex; justify-content:space-between; align-items:flex-end; margin-bottom:12px; margin-top:24px;">
              <h3 style="margin:0; font-size:16px;">Data Plan Area</h3>
              <button class="btn btn-primary btn-sm" data-add-plan="1">${ICONS.plus} Tambah Data Plan Area</button>
          </div>
          
          <div style="overflow-x:auto; padding-bottom:16px;">
             <table class="data-table" style="min-width:1400px;">
                <thead>
                   <tr>
                      <th colspan="8" style="background-color: var(--accent-soft) !important; color: var(--accent) !important; text-align: center !important; border-bottom: none !important; padding: 12px 16px !important;">Informasi Area</th>
                      <th colspan="7" style="background-color: #EFE4F5 !important; color: #531D70 !important; text-align: center !important; border-bottom: none !important; padding: 12px 16px !important;">Perencanaan Area</th>
                   </tr>
                   <tr>
                      <!-- Area -->
                      <th>No</th><th>Nama Area</th><th>Kode Area</th><th>Kecamatan</th><th>Kelurahan</th><th>RW</th><th>Total Luas Area</th><th>Standart Luas Area<br>(100 M - 150 M)</th>
                      <!-- Perencanaan -->
                      <th>Status Area</th><th>Plan RK</th><th>Plan ODP</th><th>Jumlah Tiang</th><th>Sumber CJ</th><th>Catatan</th><th style="text-align:center;">Action</th>
                   </tr>
                </thead>
                <tbody>
                   ${m.planAreaData.length ? m.planAreaData.map((p, i) => `
                     <tr>
                        <td>${cell(p.no)}</td>
                        <td>${cell(p.namaArea)}</td>
                        <td>${cell(p.kodeArea)}</td>
                        <td>${cell(p.kecamatan)}</td>
                        <td>${cell(p.kelurahan)}</td>
                        <td>${cell(p.rw)}</td>
                        <td>${cell(p.totalLuasArea)}</td>
                        <td>${cell(p.stdLuasArea)}</td>
                        
                        <td><span class="badge ${p.statusArea==='Approved'?'badge-status':(p.statusArea==='Pending'?'badge-draft':'badge-nonaktif')}">${cell(p.statusArea)}</span></td>
                        <td>${cell(p.planRk)}</td>
                        <td>${cell(p.planOdp)}</td>
                        <td>${cell(p.jmlTiang)}</td>
                        <td>${cell(p.sumberCj)}</td>
                        <td style="max-width:200px; white-space:normal;">${cell(p.keterangan)}</td>
                        
                        <td style="text-align:center; position:relative;">
                          <button class="kebab-btn" data-kebab="plan:${p.id}">${ICONS.kebab}</button>
                          ${kebabOpen('plan', p.id) ? `
                          <div class="kebab-menu" style="right:14px;">
                            <button data-edit-plan="${i}">${ICONS.edit} Edit</button>
                            <button class="danger" data-delete-plan="${i}">${ICONS.trash} Hapus</button>
                          </div>` : ''}
                        </td>
                     </tr>
                   `).join('') : `<tr><td colspan="15" style="text-align:center; padding:32px; color:var(--ink-faint);">Belum ada Data Plan Area.</td></tr>`}
                </tbody>
             </table>
          </div>
      `;
  } else if (m.name === 'Opsi Lokasi Kantor Branch' && m.branchOfficeOptions) {
    const selKey = `${S.activeBranchId}:${S.activeMonitorId}`;
    const sel = S.bofSelection[selKey] || {};

    content = `
      <div style="background:var(--surface); border:1px solid var(--border); border-radius:var(--radius-lg); padding:20px; margin-top:24px; margin-bottom:8px;">
        <div style="font-size:13px; font-weight:600; color:var(--primary); margin-bottom:14px; padding-bottom:8px; border-bottom:1px solid var(--border);">Keputusan Lokasi Kantor Branch</div>
        <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:16px;">
          <div>
            <div style="font-size:12px; color:var(--ink-faint); margin-bottom:4px;">Opsi yang Dipilih</div>
            <select id="bof-sel-opsi" style="width:100%; padding:8px 10px; border:1px solid var(--border-strong); border-radius:var(--radius); font-size:13px; background:var(--surface); color:var(--ink);" data-bof-sel-opsi="1">
              <option value="">-- Belum Dipilih --</option>
              ${m.branchOfficeOptions.map((opt, i) => `<option value="${opt.id}" ${sel.opsiId===opt.id?'selected':''}>Opsi #${opt.no} – ${escAttr(opt.identitas.alamat.substring(0,40))}...</option>`).join('')}
            </select>
          </div>
          <div>
            <div style="font-size:12px; color:var(--ink-faint); margin-bottom:4px;">Harga Sewa</div>
            <input id="bof-sel-harga" type="text" placeholder="mis. Rp 45.000.000 / tahun" value="${escAttr(sel.hargaSewa||'')}" style="width:100%; padding:8px 10px; border:1px solid var(--border-strong); border-radius:var(--radius); font-size:13px; background:var(--surface); color:var(--ink);" data-bof-sel-harga="1">
          </div>
          <div>
            <div style="font-size:12px; color:var(--ink-faint); margin-bottom:4px;">Dokumen Planning Kantor</div>
            <input id="bof-sel-dokumen" type="text" placeholder="Link dokumen / nama file" value="${escAttr(sel.dokumenPlanning||'')}" style="width:100%; padding:8px 10px; border:1px solid var(--border-strong); border-radius:var(--radius); font-size:13px; background:var(--surface); color:var(--ink);" data-bof-sel-dokumen="1">
          </div>
        </div>
        <div style="margin-top:12px; display:flex; justify-content:flex-end;">
          <button class="btn btn-primary btn-sm" data-save-bof-sel="1">Simpan Keputusan</button>
        </div>
      </div>

      <div class="pop-odc-container" style="margin-top:16px;">
        ${m.branchOfficeOptions.map((opt, i) => `
          <div class="pop-odc-card">
            <div class="pop-odc-card-header">
              <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:12px;">
                <h3 style="margin:0; font-size:16px; font-weight:600; color:var(--primary);">Opsi Lokasi Kantor Branch #${opt.no}</h3>
                <div style="display:flex; gap:8px;">
                  <button class="btn btn-ghost btn-sm" style="padding:4px 8px; color:var(--ink-soft);" data-edit-bof="${i}">${ICONS.edit} Edit</button>
                  <button class="btn btn-ghost btn-sm" style="padding:4px 8px; color:var(--danger);" data-delete-bof="${i}">${ICONS.trash} Hapus</button>
                </div>
              </div>
              <div class="pop-odc-header-grid">
                <div class="grid-item"><span class="lbl">No</span><span class="val">: ${opt.no}</span></div>
                <div class="grid-item"><span class="lbl">Nama Surveyor</span><span class="val">: ${escHtml(opt.surveyor)}</span></div>
                <div class="grid-item"><span class="lbl">Tanggal</span><span class="val">: ${escHtml(opt.date)}</span></div>
                <div class="grid-item"><span class="lbl">Status</span><span class="val">: ${escHtml(opt.status)}</span></div>
                <div class="grid-item"><span class="lbl">Rekomendasi</span><span class="val">: <span class="badge ${opt.recommendation==='Direkomendasikan'?'badge-status':opt.recommendation==='Pertimbangkan'?'badge-draft':'badge-nonaktif'}">${escHtml(opt.recommendation)}</span></span></div>
              </div>
            </div>
            <div class="pop-odc-table-wrapper" style="overflow-x:auto;">
              <table class="data-table pop-odc-table" style="border:none; border-radius:0;">
                <thead>
                  <tr><th style="border-top:none; width:180px;">Kategori</th><th style="border-top:none; width:260px;">Indikator</th><th style="border-top:none;">Keterangan</th></tr>
                </thead>
                <tbody>
                  <!-- Identitas Lokasi -->
                  <tr><td rowspan="8" style="font-weight:600; vertical-align:top; padding-top:12px;">Identitas Lokasi</td><td>Foto Tampak Depan</td><td>${opt.identitas.fotoTampakDepan ? `<a href="${escAttr(opt.identitas.fotoTampakDepan)}" class="doc-link" target="_blank">${ICONS.link} Lihat Foto</a>` : '-'}</td></tr>
                  <tr><td>Alamat Lengkap</td><td>${escHtml(opt.identitas.alamat)}</td></tr>
                  <tr><td>Link Gmaps</td><td>${opt.identitas.gmaps ? `<a href="${escAttr(opt.identitas.gmaps)}" class="doc-link" target="_blank">${ICONS.link} Buka Maps</a>` : '-'}</td></tr>
                  <tr><td>Nama Pemilik</td><td>${escHtml(opt.identitas.namaPemilik)}</td></tr>
                  <tr><td>Nomor Kontak Pemilik</td><td>${escHtml(opt.identitas.kontakPemilik)}</td></tr>
                  <tr><td>Jenis Bangunan</td><td>${escHtml(opt.identitas.jenisBangunan)}</td></tr>
                  <tr><td>Jumlah Lantai</td><td>${escHtml(opt.identitas.jumlahLantai)}</td></tr>
                  <tr><td>Jumlah Ruangan</td><td>${escHtml(opt.identitas.jumlahRuangan)}</td></tr>

                  <!-- Lokasi & Operasional -->
                  <tr><td rowspan="5" style="font-weight:600; vertical-align:top; padding-top:12px;">Lokasi &amp; Operasional</td><td>Jarak ke Area Penjualan Terjauh (Km)</td><td>${escHtml(opt.operasional.jarakAreaPenjualan)}</td></tr>
                  <tr><td>Akses Kendaraan Operasional</td><td>${escHtml(opt.operasional.aksesKendaraan)}</td></tr>
                  <tr><td>Area Parkir</td><td>${escHtml(opt.operasional.areaParkir)}</td></tr>
                  <tr><td>Kondisi Lingkungan</td><td>${escHtml(opt.operasional.kondisiLingkungan)}</td></tr>
                  <tr><td>Tingkat Keamanan Lingkungan</td><td>${escHtml(opt.operasional.keamananLingkungan)}</td></tr>

                  <!-- Kesesuaian Standar Branch -->
                  <tr><td rowspan="6" style="font-weight:600; vertical-align:top; padding-top:12px;">Kesesuaian Standar Branch</td><td>Area Brainstorming Tersedia</td><td>${escHtml(opt.standarBranch.areaBrainstorming)}</td></tr>
                  <tr><td>Area Penyimpanan Material FTTH</td><td>${escHtml(opt.standarBranch.areaMaterialFTTH)}</td></tr>
                  <tr><td>Area Penyimpanan Tiang</td><td>${escHtml(opt.standarBranch.areaTiang)}</td></tr>
                  <tr><td>Area Istirahat Tim</td><td>${escHtml(opt.standarBranch.areaIstirahat)}</td></tr>
                  <tr><td>Pantry / Dapur</td><td>${escHtml(opt.standarBranch.pantry)}</td></tr>
                  <tr><td>Kamar Mandi</td><td>${escHtml(opt.standarBranch.kamarMandi)}</td></tr>

                  <!-- Informasi Bangunan -->
                  <tr><td rowspan="5" style="font-weight:600; vertical-align:top; padding-top:12px;">Informasi Bangunan</td><td>Luas Tanah (m²)</td><td>${escHtml(opt.infoBangunan.luasTanah)}</td></tr>
                  <tr><td>Luas Bangunan (m²)</td><td>${escHtml(opt.infoBangunan.luasBangunan)}</td></tr>
                  <tr><td>Jumlah Lantai</td><td>${escHtml(opt.infoBangunan.jumlahLantai)}</td></tr>
                  <tr><td>Jumlah Ruangan</td><td>${escHtml(opt.infoBangunan.jumlahRuangan)}</td></tr>
                  <tr><td>Harga Sewa</td><td>${escHtml(opt.infoBangunan.hargaSewa)}</td></tr>

                  <!-- Kondisi Bangunan -->
                  <tr><td rowspan="6" style="font-weight:600; vertical-align:top; padding-top:12px;">Kondisi Bangunan</td><td>Kondisi Bangunan</td><td>${escHtml(opt.kondisiBangunan.kondisiBangunan)}</td></tr>
                  <tr><td>Kondisi Kelistrikan</td><td>${escHtml(opt.kondisiBangunan.kondisiKelistrikan)}</td></tr>
                  <tr><td>Daya Listrik (VA)</td><td>${escHtml(opt.kondisiBangunan.dayaListrik)}</td></tr>
                  <tr><td>Kondisi Air Bersih</td><td>${escHtml(opt.kondisiBangunan.kondisiAir)}</td></tr>
                  <tr><td>Sumber Air</td><td>${escHtml(opt.kondisiBangunan.sumberAir)}</td></tr>
                  <tr><td>Estimasi Biaya Renovasi (Isi jika membutuhkan renovasi)</td><td>${escHtml(opt.kondisiBangunan.estimasiRenovasi) || '-'}</td></tr>

                  <!-- Dokumentasi -->
                  <tr><td rowspan="1" style="font-weight:600; vertical-align:top; padding-top:12px;">Dokumentasi</td><td>Link Dokumentasi Lengkap</td><td>${opt.dokumentasi.linkDokumentasi ? `<a href="${escAttr(opt.dokumentasi.linkDokumentasi)}" class="doc-link" target="_blank">${ICONS.link} Buka Dokumentasi</a>` : '-'}</td></tr>
                </tbody>
              </table>
            </div>
          </div>
        `).join('')}
        <button class="btn btn-secondary" data-add-bof="1" style="margin-top:8px;">${ICONS.plus} Tambah Opsi Lokasi</button>
      </div>
    `;
  } else if (m.name === 'Fasum (Free WiFi)' && m.fasumData) {
    const cell = val => { const s=(val||'').toString().trim(); return s?escHtml(s):'-'; };
    const statusBadgeFsm = s => {
      const map = {'Approved':'badge-status','On Progress':'badge-draft','Pending':'badge-draft','Rejected':'badge-nonaktif'};
      return `<span class="badge ${map[s]||'badge-draft'}">${escHtml(s||'-')}</span>`;
    };
    content = `
      <div style="display:flex; justify-content:space-between; align-items:flex-end; margin-bottom:12px; margin-top:24px;">
        <h3 style="margin:0; font-size:16px;">Data Fasum (Free WiFi)</h3>
        <button class="btn btn-primary btn-sm" data-add-fasum="1">${ICONS.plus} Tambah Data Fasum</button>
      </div>
      <div style="overflow-x:auto; padding-bottom:16px;">
        <table class="data-table" style="min-width:1100px;">
          <thead>
            <tr>
              <th colspan="5" class="th-group-1" style="text-align:center;">Informasi Area</th>
              <th colspan="3" class="th-group-2" style="text-align:center;">Permintaan Fasum</th>
              <th colspan="2" class="th-group-3" style="text-align:center;">Dokumentasi</th>
              <th rowspan="2" style="text-align:center; vertical-align:middle; background:var(--surface); border-bottom:2px solid var(--border-strong);">Action</th>
            </tr>
            <tr>
              <th>No</th>
              <th>Nama Area</th>
              <th>Kelurahan</th>
              <th>RW</th>
              <th>RT</th>
              <th>Lokasi Fasum</th>
              <th>Pemohon</th>
              <th>Status</th>
              <th>Titik Koordinat</th>
              <th>Link Dokumentasi</th>
            </tr>
          </thead>
          <tbody>
            ${m.fasumData.length ? m.fasumData.map((f, i) => `
              <tr>
                <td>${cell(f.no)}</td>
                <td style="font-weight:500;">${cell(f.namaArea)}</td>
                <td>${cell(f.kelurahan)}</td>
                <td>${cell(f.rw)}</td>
                <td>${cell(f.rt)}</td>
                <td>${cell(f.lokasiFasum)}</td>
                <td>${cell(f.pemohon)}</td>
                <td>${statusBadgeFsm(f.status)}</td>
                <td>${cell(f.titikKoordinat)}</td>
                <td>${f.linkDokumentasi ? `<a href="${escAttr(f.linkDokumentasi)}" class="doc-link" target="_blank">${ICONS.link} Buka</a>` : '-'}</td>
                <td style="text-align:center; position:relative;">
                  <button class="kebab-btn" data-kebab="fasum:${f.id}">${ICONS.kebab}</button>
                  ${kebabOpen('fasum', f.id) ? `
                  <div class="kebab-menu" style="right:14px;">
                    <button data-edit-fasum="${i}">${ICONS.edit} Edit</button>
                    <button class="danger" data-delete-fasum="${i}">${ICONS.trash} Hapus</button>
                  </div>` : ''}
                </td>
              </tr>
            `).join('') : `<tr><td colspan="11" style="text-align:center;padding:32px;color:var(--ink-faint);">Belum ada Data Fasum.</td></tr>`}
          </tbody>
        </table>
      </div>
    `;
  } else if (m.name === 'Pemasangan Tiang' && m.pemasanganTiangData) {
    const cell = val => { const s=(val||'').toString().trim(); return s?escHtml(s):'-'; };
    const linkCell = (url, label) => url ? `<a href="${escAttr(url)}" class="doc-link" target="_blank">${ICONS.link} ${label}</a>` : '-';
    const statusBadgeTg = s => {
      const map = { 'Selesai':'badge-status','Lolos QC':'badge-status','On Progress':'badge-draft','Belum Mulai':'badge-nonaktif','Belum QC':'badge-nonaktif','Revisi':'badge-nonaktif' };
      return `<span class="badge ${map[s]||'badge-draft'}">${escHtml(s||'-')}</span>`;
    };
    content = `
      <div style="display:flex; justify-content:space-between; align-items:flex-end; margin-bottom:12px; margin-top:24px;">
        <h3 style="margin:0; font-size:16px;">Data Pemasangan Tiang</h3>
        <button class="btn btn-primary btn-sm" data-add-tiang="1">${ICONS.plus} Tambah Data Tiang</button>
      </div>
      <div style="overflow-x:auto; padding-bottom:16px;">
        <table class="data-table" style="min-width:1400px;">
          <thead>
            <tr>
              <th colspan="5" class="th-group-1" style="text-align:center;">Informasi Tiang</th>
              <th colspan="6" class="th-group-2" style="text-align:center;">Monitoring</th>
            </tr>
            <tr>
              <th>No</th>
              <th>ID Tiang</th>
              <th>Lokasi / Segmen</th>
              <th>Link Google Maps</th>
              <th>Jenis Tiang</th>
              <th>Status Pekerjaan</th>
              <th>Status QC</th>
              <th>Link Dokumentasi</th>
              <th>Catatan</th>
              <th>Lampiran Form QC</th>
              <th>Lampiran Form Hasil Penanaman Tiang</th>
              <th style="text-align:center;">Action</th>
            </tr>
          </thead>
          <tbody>
            ${m.pemasanganTiangData.length ? m.pemasanganTiangData.map((t, i) => `
              <tr>
                <td>${cell(t.no)}</td>
                <td style="font-weight:600;">${cell(t.idTiang)}</td>
                <td>${cell(t.lokasi)}</td>
                <td>${linkCell(t.linkGmaps, 'Buka Maps')}</td>
                <td>${cell(t.jenisTiang)}</td>
                <td>${statusBadgeTg(t.statusPekerjaan)}</td>
                <td>${statusBadgeTg(t.statusQC)}</td>
                <td>${linkCell(t.linkDokumentasi, 'Buka')}</td>
                <td style="max-width:160px;white-space:normal;">${cell(t.catatan)}</td>
                <td>${linkCell(t.lampiranFormQC, 'Form QC')}</td>
                <td>${linkCell(t.lampiranFormTanam, 'Form Tanam')}</td>
                <td style="text-align:center; position:relative;">
                  <button class="kebab-btn" data-kebab="tiang:${t.id}">${ICONS.kebab}</button>
                  ${kebabOpen('tiang', t.id) ? `
                  <div class="kebab-menu" style="right:14px;">
                    <button data-edit-tiang="${i}">${ICONS.edit} Edit</button>
                    <button class="danger" data-delete-tiang="${i}">${ICONS.trash} Hapus</button>
                  </div>` : ''}
                </td>
              </tr>
            `).join('') : `<tr><td colspan="12" style="text-align:center;padding:32px;color:var(--ink-faint);">Belum ada Data Pemasangan Tiang.</td></tr>`}
          </tbody>
        </table>
      </div>
    `;
  } else if (m.name === 'Pembangunan POP ODC' && m.pembangunanPopData) {
    const statusBadgePop = s => {
      const map = { 'Done':'badge-status','Approved':'badge-status','Aktif':'badge-status','On Progress':'badge-draft','Submitted':'badge-draft','Draft':'badge-draft','Belum Mulai':'badge-nonaktif' };
      const cls = map[s] || 'badge-draft';
      return `<span class="badge ${cls}">${escHtml(s||'-')}</span>`;
    };
    content = `
      <div class="pop-odc-container" style="margin-top:24px;">
        ${m.pembangunanPopData.map((opt, i) => `
          <div class="pop-odc-card">
            <div class="pop-odc-card-header">
              <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:12px;">
                <h3 style="margin:0; font-size:16px; font-weight:600; color:var(--primary);">Pembangunan POP ODC #${opt.no}</h3>
                <div style="display:flex; gap:8px;">
                  <button class="btn btn-ghost btn-sm" style="padding:4px 8px; color:var(--ink-soft);" data-edit-ppop="${i}">${ICONS.edit} Edit</button>
                  <button class="btn btn-ghost btn-sm" style="padding:4px 8px; color:var(--danger);" data-delete-ppop="${i}">${ICONS.trash} Hapus</button>
                </div>
              </div>
              <div class="pop-odc-header-grid">
                <div class="grid-item"><span class="lbl">No</span><span class="val">: ${opt.no}</span></div>
                <div class="grid-item"><span class="lbl">Nama Surveyor</span><span class="val">: ${escHtml(opt.surveyor)}</span></div>
                <div class="grid-item"><span class="lbl">Tanggal</span><span class="val">: ${escHtml(opt.date)}</span></div>
                <div class="grid-item"><span class="lbl">Status</span><span class="val">: ${statusBadgePop(opt.status)}</span></div>
                <div class="grid-item"><span class="lbl">Rekomendasi</span><span class="val">: ${escHtml(opt.recommendation)}</span></div>
              </div>
            </div>
            <div class="pop-odc-table-wrapper" style="overflow-x:auto;">
              <table class="data-table pop-odc-table" style="border:none; border-radius:0;">
                <thead>
                  <tr><th style="border-top:none; width:200px;">Kategori</th><th style="border-top:none; width:280px;">Indikator</th><th style="border-top:none;">Keterangan</th></tr>
                </thead>
                <tbody>
                  <!-- Informasi Lokasi -->
                  <tr><td rowspan="3" style="font-weight:600; vertical-align:top; padding-top:12px;">Informasi Lokasi</td><td>Foto Lokasi</td><td>${opt.infoLokasi.fotoLokasi ? `<a href="${escAttr(opt.infoLokasi.fotoLokasi)}" class="doc-link" target="_blank">${ICONS.link} Lihat Foto</a>` : '-'}</td></tr>
                  <tr><td>Alamat Lokasi</td><td>${escHtml(opt.infoLokasi.alamatLokasi)}</td></tr>
                  <tr><td>Link Google Maps</td><td>${opt.infoLokasi.linkGmaps ? `<a href="${escAttr(opt.infoLokasi.linkGmaps)}" class="doc-link" target="_blank">${ICONS.link} Buka Maps</a>` : '-'}</td></tr>

                  <!-- Pembangunan ODC -->
                  <tr><td rowspan="5" style="font-weight:600; vertical-align:top; padding-top:12px;">Pembangunan ODC</td><td>Status RAB Material &amp; Perangkat</td><td>${statusBadgePop(opt.pembangunanODC.statusRAB)}</td></tr>
                  <tr><td>Status Pengadaan Material ODC</td><td>${statusBadgePop(opt.pembangunanODC.statusPengadaan)}</td></tr>
                  <tr><td>Status Pembangunan ODC</td><td>${statusBadgePop(opt.pembangunanODC.statusPembangunan)}</td></tr>
                  <tr><td>Status Instalasi Perangkat ODC</td><td>${statusBadgePop(opt.pembangunanODC.statusInstalasi)}</td></tr>
                  <tr><td>Status Uji Kelayakan ODC</td><td>${statusBadgePop(opt.pembangunanODC.statusUjiKelayakan)}</td></tr>

                  <!-- Kelistrikan ODC -->
                  <tr><td rowspan="3" style="font-weight:600; vertical-align:top; padding-top:12px;">Kelistrikan ODC</td><td>Status Pengajuan PLN</td><td>${statusBadgePop(opt.kelistrikanODC.statusPengajuanPLN)}</td></tr>
                  <tr><td>Status Instalasi Listrik PLN</td><td>${statusBadgePop(opt.kelistrikanODC.statusInstalasiListrik)}</td></tr>
                  <tr><td>Status Listrik ODC</td><td>${statusBadgePop(opt.kelistrikanODC.statusListrikODC)}</td></tr>

                  <!-- Aktivasi Perangkat -->
                  <tr><td rowspan="3" style="font-weight:600; vertical-align:top; padding-top:12px;">Aktivasi Perangkat</td><td>Status Persiapan Perangkat Jaringan</td><td>${statusBadgePop(opt.aktivasiPerangkat.statusPersiapan)}</td></tr>
                  <tr><td>Status Konfigurasi Jaringan</td><td>${statusBadgePop(opt.aktivasiPerangkat.statusKonfigurasi)}</td></tr>
                  <tr><td>Status Aktivasi ODC</td><td>${statusBadgePop(opt.aktivasiPerangkat.statusAktivasiODC)}</td></tr>

                  <!-- Dokumentasi -->
                  <tr><td rowspan="4" style="font-weight:600; vertical-align:top; padding-top:12px;">Dokumentasi</td><td>Target ODC Ready</td><td>${escHtml(opt.dokumentasi.targetODCReady)}</td></tr>
                  <tr><td>Aktual ODC Ready</td><td>${escHtml(opt.dokumentasi.aktualODCReady)}</td></tr>
                  <tr><td>Catatan Kendala</td><td>${escHtml(opt.dokumentasi.catatanKendala)}</td></tr>
                  <tr><td>Link Dokumentasi Lengkap</td><td>${opt.dokumentasi.linkDokumentasi ? `<a href="${escAttr(opt.dokumentasi.linkDokumentasi)}" class="doc-link" target="_blank">${ICONS.link} Buka Dokumentasi</a>` : '-'}</td></tr>
                </tbody>
              </table>
            </div>
          </div>
        `).join('')}
        <button class="btn btn-secondary" data-add-ppop="1" style="margin-top:8px;">${ICONS.plus} Tambah Data Pembangunan POP ODC</button>
      </div>
    `;
  } else if (m.name === 'Route Area' && m.routeAreaData) {
    const cell = val => { const s = (val||'').toString().trim(); return s ? escHtml(s) : '-'; };
    const statusBadge = s => {
      const cls = s==='Aktif'?'badge-status': s==='Pending'?'badge-draft':'badge-nonaktif';
      return `<span class="badge ${cls}">${escHtml(s)}</span>`;
    };

    content = `
      <div style="display:flex; justify-content:space-between; align-items:flex-end; margin-bottom:12px; margin-top:24px;">
        <h3 style="margin:0; font-size:16px;">Data Route Area</h3>
        <button class="btn btn-primary btn-sm" data-add-route="1">${ICONS.plus} Tambah Data Route Area</button>
      </div>
      <div style="overflow-x:auto; padding-bottom:16px;">
        <table class="data-table" style="min-width:1600px;">
          <thead>
            <tr>
              <th colspan="5" class="th-group-1" style="text-align:center;">Informasi Area</th>
              <th colspan="5" class="th-group-2" style="text-align:center;">Jalur 1</th>
              <th colspan="1" style="background:var(--accent-soft);color:var(--accent);text-align:center;border-bottom:none;padding:12px 8px;">CJ</th>
              <th colspan="5" class="th-group-3" style="text-align:center;">Jalur 2</th>
              <th colspan="1" style="background:#EFE4F5;color:#531D70;text-align:center;border-bottom:none;padding:12px 8px;">CJ</th>
              <th colspan="5" class="th-group-1" style="text-align:center;">Jalur 3</th>
              <th colspan="1" style="background:var(--accent-soft);color:var(--accent);text-align:center;border-bottom:none;padding:12px 8px;">CJ</th>
              <th colspan="5" class="th-group-2" style="text-align:center;">Jalur 4</th>
              <th colspan="1" style="background:#EFE4F5;color:#531D70;text-align:center;border-bottom:none;padding:12px 8px;">CJ</th>
              <th colspan="4" class="th-group-3" style="text-align:center;">Monitoring</th>
            </tr>
            <tr>
              <!-- Informasi Area -->
              <th>No</th><th>Batch</th><th>Warna Area</th><th>Nama Area</th><th>OTB</th>
              <!-- Jalur 1 -->
              <th>Kabel</th><th>Tube</th><th>Core</th><th>Panjang (m)</th><th style="width:40px;"></th>
              <th>CJ</th>
              <!-- Jalur 2 -->
              <th>Kabel</th><th>Tube</th><th>Core</th><th>Panjang (m)</th><th style="width:40px;"></th>
              <th>CJ</th>
              <!-- Jalur 3 -->
              <th>Kabel</th><th>Tube</th><th>Core</th><th>Panjang (m)</th><th style="width:40px;"></th>
              <th>CJ</th>
              <!-- Jalur 4 -->
              <th>Kabel</th><th>Tube</th><th>Core</th><th>Panjang (m)</th><th style="width:40px;"></th>
              <th>CJ</th>
              <!-- Monitoring -->
              <th>Total Panjang (m)</th><th>Status Route</th><th>Link Dokumentasi</th><th>Catatan</th><th style="text-align:center;">Action</th>
            </tr>
          </thead>
          <tbody>
            ${m.routeAreaData.length ? m.routeAreaData.map((r, i) => `
              <tr>
                <td>${cell(r.no)}</td>
                <td>${cell(r.batch)}</td>
                <td>
                  <div style="display:flex;align-items:center;gap:6px;">
                    ${r.warnaArea ? `<span style="display:inline-block;width:12px;height:12px;border-radius:50%;background:${r.warnaHex||'#ccc'};flex-shrink:0;"></span>` : ''}
                    ${cell(r.warnaArea)}
                  </div>
                </td>
                <td style="font-weight:500;">${cell(r.namaArea)}</td>
                <td>${cell(r.otb)}</td>
                <!-- Jalur 1 -->
                <td>${cell(r.jalur1.kabel)}</td><td>${cell(r.jalur1.tube)}</td><td>${cell(r.jalur1.core)}</td><td>${cell(r.jalur1.panjang)}</td><td></td>
                <td>${cell(r.cj1)}</td>
                <!-- Jalur 2 -->
                <td>${cell(r.jalur2.kabel)}</td><td>${cell(r.jalur2.tube)}</td><td>${cell(r.jalur2.core)}</td><td>${cell(r.jalur2.panjang)}</td><td></td>
                <td>${cell(r.cj2)}</td>
                <!-- Jalur 3 -->
                <td>${cell(r.jalur3.kabel)}</td><td>${cell(r.jalur3.tube)}</td><td>${cell(r.jalur3.core)}</td><td>${cell(r.jalur3.panjang)}</td><td></td>
                <td>${cell(r.cj3)}</td>
                <!-- Jalur 4 -->
                <td>${cell(r.jalur4.kabel)}</td><td>${cell(r.jalur4.tube)}</td><td>${cell(r.jalur4.core)}</td><td>${cell(r.jalur4.panjang)}</td><td></td>
                <td>${cell(r.cj4)}</td>
                <!-- Monitoring -->
                <td style="font-weight:600;">${cell(r.totalPanjang)}</td>
                <td>${statusBadge(r.statusRoute)}</td>
                <td>${r.linkDokumentasi ? `<a href="${escAttr(r.linkDokumentasi)}" class="doc-link" target="_blank">${ICONS.link} Buka</a>` : '-'}</td>
                <td style="max-width:160px;white-space:normal;">${cell(r.catatan)}</td>
                <td style="text-align:center; position:relative;">
                  <button class="kebab-btn" data-kebab="route:${r.id}">${ICONS.kebab}</button>
                  ${kebabOpen('route', r.id) ? `
                  <div class="kebab-menu" style="right:14px;">
                    <button data-edit-route="${i}">${ICONS.edit} Edit</button>
                    <button class="danger" data-delete-route="${i}">${ICONS.trash} Hapus</button>
                  </div>` : ''}
                </td>
              </tr>
            `).join('') : `<tr><td colspan="34" style="text-align:center;padding:32px;color:var(--ink-faint);">Belum ada Data Route Area.</td></tr>`}
          </tbody>
        </table>
      </div>
    `;
  } else {
      content = `
        <div class="placeholder-panel" style="margin-top:24px;">
           <div class="icon">${ICONS.inbox}</div>
           <h3>Detailed Monitoring UI</h3>
           <p>Konten detail untuk <b>${escHtml(m.name)}</b> akan diimplementasikan pada tahap pengembangan berikutnya.</p>
        </div>`;
  }

  return `
  <button class="btn btn-ghost btn-sm" data-nav-ob-branch="${b.id}" style="padding-left: 0; margin-bottom: 12px;">${ICONS.back} Kembali</button>
  <div class="ob-header-context">
    <h2 style="margin:0 0 4px; font-size: 20px;">${escHtml(m.name)}</h2>
    <div style="font-size:13.5px; color:var(--ink-soft); margin-bottom:8px;">${escHtml(b.name)}</div>
    <div style="display:flex; gap:16px; font-size:13px; flex-wrap: wrap;">
      <div><span style="color:var(--ink-faint);">Status:</span> <span class="badge ${m.status==='Aktif'?'badge-status':'badge-nonaktif'}">${escHtml(m.status)}</span></div>
      <div>
        <div class="progress-cell" style="display:inline-flex;">
          <span style="color:var(--ink-faint);">Progress:</span> 
          <span>${m.progress}%</span>
          <div class="progress-track" style="width:60px;"><div class="progress-fill" style="width:${m.progress}%"></div></div>
        </div>
      </div>
      <div><span style="color:var(--ink-faint);">Last Update:</span> ${escHtml(m.lastUpdated)}</div>
    </div>
  </div>
  ${content}
  `;
}

/* ======================= JOB DESCRIPTION PAGE ======================= */

