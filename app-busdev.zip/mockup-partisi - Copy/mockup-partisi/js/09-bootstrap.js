const _origHOD = headOfDivisionRole;
headOfDivisionRole = function(division){
  if(!division.headOfDivisionJobRoleId) return null;
  const custom = HOD_NAMES[division.headOfDivisionJobRoleId];
  return { id:division.headOfDivisionJobRoleId, name: custom ? "Head of Division "+custom : "Head of Division "+division.name, type:"Head of Division", departmentId:null, divisionId:division.id, supervisor:"Directorate Head", jd: (window.__hodJD && window.__hodJD[division.headOfDivisionJobRoleId]) || emptyJD() };
};

const _origFindJobRole = findJobRole;
findJobRole = function(id){
  for(const d of S.directorates) for(const v of d.divisions){
    if(v.headOfDivisionJobRoleId===id) return headOfDivisionRole(v);
    for(const dep of v.departments){ const r=dep.jobRoles.find(x=>x.id===id); if(r) return r; }
  }
  return null;
};

render();
