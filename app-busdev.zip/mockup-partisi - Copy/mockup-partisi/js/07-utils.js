function escHtml(s){ return (s??'').toString().replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function escAttr(s){ return escHtml(s); }
function getDeep(obj, path){ return path.split('.').reduce((o,k)=>o==null?undefined:o[k], obj); }
function setDeep(obj, path, val){
  const parts = path.split('.'); let o = obj;
  for(let i=0;i<parts.length-1;i++){ o = o[parts[i]]; }
  o[parts[parts.length-1]] = val;
}

/* ======================= EVENT HANDLING ======================= */
