/* ======================= DATA ======================= */

const ICONS = {
  chevron: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><polyline points="9 6 15 12 9 18"/></svg>`,
  chevronDown: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><polyline points="6 9 12 15 18 9"/></svg>`,
  kebab: `<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="5" r="1.8"/><circle cx="12" cy="12" r="1.8"/><circle cx="12" cy="19" r="1.8"/></svg>`,
  division: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>`,
  dept: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 21V7l9-4 9 4v14"/><path d="M9 21v-6h6v6"/></svg>`,
  person: `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-7 8-7s8 2.6 8 7"/></svg>`,
  sun: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>`,
  moon: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M21 12.8A9 9 0 1111.2 3 7 7 0 0021 12.8z"/></svg>`,
  plus: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M12 5v14M5 12h14"/></svg>`,
  back: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3"><polyline points="15 18 9 12 15 6"/></svg>`,
  close: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M6 6l12 12M18 6L6 18"/></svg>`,
  eye: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7z"/><circle cx="12" cy="12" r="3"/></svg>`,
  edit: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 013 3L7 19l-4 1 1-4z"/></svg>`,
  trash: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/><path d="M10 11v6M14 11v6"/><path d="M9 6V4a1 1 0 011-1h4a1 1 0 011 1v2"/></svg>`,
  inbox: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M22 12h-6l-2 3h-4l-2-3H2"/><path d="M5.45 5.11L2 12v6a2 2 0 002 2h16a2 2 0 002-2v-6l-3.45-6.89A2 2 0 0016.76 4H7.24a2 2 0 00-1.79 1.11z"/></svg>`,
  building: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="4" y="2" width="16" height="20" rx="1"/><path d="M9 22v-4h6v4M9 8h.01M15 8h.01M9 12h.01M15 12h.01"/></svg>`,
  link: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10 13a5 5 0 007.54.54l3-3a5 5 0 00-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 00-7.54-.54l-3 3a5 5 0 007.07 7.07l1.71-1.71"/></svg>`,
  search: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>`,
  location: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>`
};
const uid = (() => { let n = 1000; return () => (++n).toString(36); })();

function emptyJD(){
  return {
    description:"",
    objectives:[],
    authorities:{granted:[], limitations:[]},
    responsibilities:[],
    kpi:[],
    ksao:{knowledge:[],skill:[],ability:[],other:[]},
    requirements:{pendidikan:"",pengalaman:[],teknis:[],nonTeknis:[]},
    risks:[],
    regulations:[],
    leadership:[],
    assessments:[],
    communication:[],
    candidateCompetencies:[]
  };
}

function fieldTalentRecruiterJD(){
  return {
    description: "Posisi Field Talent Acquisition adalah eksekutor lini depan dalam pemenuhan talenta operasional untuk seluruh unit kerja di wilayah cabang dan lapangan. Peran ini bertanggung jawab menjalankan proses sourcing, screening administratif, koordinasi tes praktik/fisik, serta validasi data pelamar agar kebutuhan tenaga kerja di cabang terpenuhi tepat waktu sesuai SLA yang berlaku, sekaligus menjaga kepatuhan terhadap SOP rekrutmen yang ditetapkan perusahaan.",
    objectives: [
      "Terpenuhinya kuota pemenuhan kandidat operasional/lapangan di cabang tepat waktu sesuai SLA.",
      "Dokumentasi hasil screening, work endurance assessment, dan validasi data pelamar yang terstruktur.",
      "Pemutakhiran status tracker kandidat secara real-time."
    ],
    authorities: {
      granted: [
        "Menentukan kandidat yang lolos atau gugur pada tahap awal administrative screening.",
        "Memilih local sourcing channel yang efektif.",
        "Mengatur jadwal dan memfasilitasi tes praktik/tes fisik.",
        "Memperbarui status kualifikasi kandidat."
      ],
      limitations: [
        "Memutuskan kelolosan final tanpa persetujuan User Cabang.",
        "Mengubah struktur kompensasi tanpa persetujuan CRC.",
        "Memproses kandidat di luar FPTK resmi."
      ]
    },
    responsibilities: [
      { pillar:"Analisis & Perencanaan Teknis", tasks:[
        {title:"Analisis Kebutuhan Rekrutmen Wilayah", desc:"Memahami kebutuhan tenaga kerja berdasarkan FPTK dan kondisi operasional cabang di wilayah kerja."},
        {title:"Analisis Ketersediaan Talent Lokal", desc:"Mengidentifikasi kondisi dan ketersediaan kandidat pada pasar tenaga kerja lokal/regional."},
        {title:"Analisis Sourcing Channel", desc:"Mengevaluasi efektivitas channel lokal yang digunakan untuk menjangkau kandidat potensial."}
      ]},
      { pillar:"Persiapan & Pengembangan Teknis", tasks:[
        {title:"Penyusunan Materi Sourcing Lokal", desc:"Menyiapkan materi dan pesan sourcing yang relevan dengan konteks budaya dan kebutuhan wilayah."},
        {title:"Koordinasi dengan User Cabang", desc:"Menyelaraskan kriteria dan ekspektasi kandidat bersama User Cabang sebelum proses rekrutmen dimulai."}
      ]},
      { pillar:"Monitoring & Pengawasan Teknis", tasks:[
        {title:"Pemantauan Progres Rekrutmen", desc:"Memantau tahapan rekrutmen agar tetap berjalan sesuai timeline SLA yang ditetapkan."},
        {title:"Pelaporan Status Tracker", desc:"Memperbarui status kandidat secara berkala pada sistem tracker rekrutmen."}
      ]},
      { pillar:"Validasi & Kontrol Kualitas", tasks:[
        {title:"Validasi Dokumen Administratif", desc:"Memastikan kelengkapan dan keabsahan dokumen pelamar sebelum diteruskan ke tahap berikutnya."},
        {title:"Work Endurance Assessment", desc:"Melaksanakan asesmen ketahanan kerja untuk memastikan kesesuaian kandidat dengan tuntutan pekerjaan lapangan."}
      ]},
      { pillar:"Pelaksanaan Teknis (Kondisional)", tasks:[
        {title:"Fasilitasi Tes Praktik/Fisik", desc:"Mengatur dan mendampingi pelaksanaan tes praktik atau tes fisik sesuai kebutuhan posisi."}
      ]}
    ],
    kpi: [
      {keterangan: "Penyelesaian proses rekrutmen dari FPTK diterima hingga kandidat onboard", waktu: "< 30 Hari Kalender", kualitas: "Sesuai kriteria FPTK", akurasi: "-", biaya: "Sesuai budget"},
      {keterangan: "Akurasi data dan dokumentasi kandidat pada sistem tracker", waktu: "-", kualitas: "-", akurasi: "Minimal 95%", biaya: "-"}
    ],
    ksao: {
      knowledge:["Recruitment Governance","SOP Dasaria","FPTK","Local/regional labor market","Administrative/legal documentation","Work endurance"],
      skill:["Local active sourcing","Google Workspace","HR Interview"],
      ability:["Talent scarcity","Alignment technical criteria","Mass-hiring"],
      other:["Agile & Resilience","Detail-Oriented & Systematic","Communicative & Collaborative"]
    },
    requirements: {
      pendidikan: "S1 Psikologi, Manajemen SDM, atau jurusan sejenis.",
      pengalaman: ["Fresh graduate diperbolehkan.","Termasuk pengalaman magang.","Usia maksimal 28 tahun."],
      teknis: ["Google Workspace","Job portal","Social media sourcing","Psikotes","ATS (opsional)"],
      nonTeknis: ["Komunikasi interpersonal","Attention to detail","Organization","Time management","Adaptability","Resilience"]
    },
    risks: [
      {cat:"Risiko Kualitas", desc:"Terlolosnya kandidat lapangan yang kurang memiliki ketahanan kerja sehingga dapat menyebabkan turnover awal."},
      {cat:"Risiko Operasional", desc:"Terjadinya kekosongan posisi teknis di cabang akibat pemenuhan melebihi SLA 30 hari."},
      {cat:"Risiko Kepatuhan", desc:"Pelanggaran SOP akibat dokumen tidak lengkap atau proses tanpa FPTK."},
      {cat:"Risiko Finansial", desc:"Pemborosan biaya akibat kandidat melakukan ghosting."}
    ],
    regulations: [
      {name: "SOP Rekrutmen Cabang & Lapangan", link: "https://docs.google.com/document/..."},
      {name: "Kebijakan Standar Upah Minimum Regional", link: "-"}
    ],
    leadership: [],
    assessments: [
      {method: "Interview HR & Observasi Fisik", evidence: "Form Hasil Wawancara & Checklist Ketahanan Fisik"},
      {method: "Pemeriksaan Berkas Kelengkapan Administratif", evidence: "Checklist Dokumen Pelamar"}
    ],
    communication: [
      {type:"Internal", party:"Talent Acquisition Supervisor", purpose:"Koordinasi progres rekrutmen dan eskalasi kendala di lapangan.", output:"Update status rekrutmen mingguan."},
      {type:"Internal", party:"Rekan Corporate & Field Recruiter", purpose:"Menyelaraskan sourcing channel dan berbagi kandidat lintas wilayah.", output:"Kolaborasi database kandidat."},
      {type:"Internal", party:"User Cabang", purpose:"Konfirmasi kriteria kandidat dan persetujuan kelolosan final.", output:"Keputusan kelolosan kandidat."}
    ],
    candidateCompetencies: [
      {ksao:"K, S, A", competency:"Local Active Sourcing & Community Engagement", category:"Fungsional", documentName:"Panduan Sourcing Lokal", documentUrl:"#"},
      {ksao:"K, S", competency:"Operational Work Endurance & Culture Fit Assessment", category:"Fungsional", documentName:"", documentUrl:""},
      {ksao:"S, A, O", competency:"Candidate Communication & Field Engagement", category:"Fungsional", documentName:"", documentUrl:""}
    ]
  };
}

function seedData(){
  return [
    {
      id:"dir-pcc", name:"People Corporate Compliance",
      divisions:[
        {
          id:"div-hc", name:"Human Capital", directorateId:"dir-pcc", headOfDivisionJobRoleId:"role-hod-hc",
          departments:[
            {
              id:"dept-ta", name:"Talent Acquisition", divisionId:"div-hc", headOfDepartmentJobRoleId:"role-hodept-ta",
              jobRoles:[
                {id:"role-hodept-ta", name:"Head of Department Talent Acquisition", type:"Head of Department", departmentId:"dept-ta", supervisor:"Head of Division Human Capital", jd: emptyJD()},
                {id:"role-ftr", name:"Field Talent Recruiter", type:"Staff", departmentId:"dept-ta", supervisor:"Head of Department Talent Acquisition", jd: fieldTalentRecruiterJD()},
                {id:"role-cr", name:"Corporate Recruiter", type:"Staff", departmentId:"dept-ta", supervisor:"Head of Department Talent Acquisition", jd: emptyJD()}
              ]
            },
            {
              id:"dept-pd", name:"People Development", divisionId:"div-hc", headOfDepartmentJobRoleId:null,
              jobRoles:[]
            }
          ]
        },
        {
          id:"div-cl", name:"Compliance & Legal", directorateId:"dir-pcc", headOfDivisionJobRoleId:null,
          departments:[
            {
              id:"dept-rc", name:"Regulatory Compliance", divisionId:"div-cl", headOfDepartmentJobRoleId:"role-hodept-rc",
              jobRoles:[
                {id:"role-hodept-rc", name:"Head of Department Regulatory Compliance", type:"Head of Department", departmentId:"dept-rc", supervisor:"Head of Division Compliance & Legal", jd: emptyJD()},
                {id:"role-ca", name:"Compliance Analyst", type:"Staff", departmentId:"dept-rc", supervisor:"Head of Department Regulatory Compliance", jd: emptyJD()}
              ]
            }
          ]
        }
      ]
    },
    {
      id:"dir-bd", name:"Business Development",
      divisions:[
        {
          id:"div-sp", name:"Strategic Partnerships", directorateId:"dir-bd", headOfDivisionJobRoleId:"role-hod-sp",
          departments:[
            {
              id:"dept-pdv", name:"Partnership Development", divisionId:"div-sp", headOfDepartmentJobRoleId:null,
              jobRoles:[
                {id:"role-po", name:"Partnership Officer", type:"Staff", departmentId:"dept-pdv", supervisor:"Head of Department Partnership Development", jd: emptyJD()}
              ]
            }
          ]
        }
      ]
    },
    {
      id:"dir-td", name:"Technology & Digital",
      divisions:[
        {
          id:"div-dp", name:"Digital Product", directorateId:"dir-td", headOfDivisionJobRoleId:null,
          departments:[
            {
              id:"dept-pe", name:"Product Engineering", divisionId:"div-dp", headOfDepartmentJobRoleId:null,
              jobRoles:[
                {id:"role-se", name:"Software Engineer", type:"Staff", departmentId:"dept-pe", supervisor:"Head of Department Product Engineering", jd: emptyJD()}
              ]
            }
          ]
        }
      ]
    }
  ];
}

// standalone head-of-division virtual roles (not nested in a department)
function headOfDivisionRole(division){
  if(!division.headOfDivisionJobRoleId) return null;
  return { id:division.headOfDivisionJobRoleId, name:"Head of Division "+division.name, type:"Head of Division", departmentId:null, divisionId:division.id, supervisor:"Directorate Head", jd: emptyJD() };
}

const SECTION_DEFS = [
  {n:"01", key:"identity", title:"Identitas Pekerjaan"},
  {n:"02", key:"description", title:"Deskripsi Jabatan"},
  {n:"03", key:"objectives", title:"Tujuan Jabatan / Output Utama"},
  {n:"04", key:"authorities", title:"Wewenang"},
  {n:"05", key:"responsibilities", title:"Tugas dan Tanggung Jawab"},
  {n:"06", key:"kpi", title:"Standar Kinerja / KPI / SLA"},
  {n:"07", key:"ksao", title:"Pemetaan Kompetensi (KSAO)"},
  {n:"08", key:"requirements", title:"Persyaratan Jabatan"},
  {n:"09", key:"risks", title:"Risiko Jabatan"},
  {n:"10", key:"regulations", title:"Regulasi / Standar yang Berlaku"},
  {n:"11", key:"leadership", title:"Tanggung Jawab Kepemimpinan"},
  {n:"12", key:"assessments", title:"Bukti / Metode Asesmen"},
  {n:"13", key:"communication", title:"Hubungan Kerja / Komunikasi"},
  {n:"14", key:"candidateCompetencies", title:"Kandidat Kompetensi & Kategorisasi"}
];

function getCurrentDateTime() {
  const d = new Date();
  const months = ['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Agu','Sep','Okt','Nov','Des'];
  const pad = n => n.toString().padStart(2, '0');
  return `${pad(d.getDate())} ${months[d.getMonth()]} ${d.getFullYear()}, ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

const STANDARD_MONITORS = [
  "Opsi Lokasi POP ODC", "Permit", "Plan Area", "Opsi Lokasi Kantor Branch",
  "Route Area", "Pembangunan POP ODC", "Pemasangan Tiang", "Fasum (Free WiFi)"
];

const dummyFasumData = [
  {
    id: 'fsm-1', no: 1, namaArea: 'Area Karangjati Utara', kelurahan: 'Karangjati', rw: '01', rt: '02',
    lokasiFasum: 'Depan Balai RW 01, Jl. Melati No.5',
    pemohon: 'Pak Ahmad (Ketua RW 01)', status: 'Approved',
    titikKoordinat: '-7.6342, 112.7821', linkDokumentasi: 'https://drive.google.com/dummy-fsm1'
  },
  {
    id: 'fsm-2', no: 2, namaArea: 'Area Pandaan Pusat', kelurahan: 'Pandaan', rw: '03', rt: '05',
    lokasiFasum: 'Taman Kota Pandaan, Jl. Raya Pandaan',
    pemohon: 'Kelurahan Pandaan', status: 'On Progress',
    titikKoordinat: '-7.6218, 112.7943', linkDokumentasi: 'https://drive.google.com/dummy-fsm2'
  },
  {
    id: 'fsm-3', no: 3, namaArea: 'Area Gempol Selatan', kelurahan: 'Gempol', rw: '02', rt: '01',
    lokasiFasum: 'Pos Ronda RW 02, Jl. Gempol Indah',
    pemohon: 'Pak Slamet (Ketua RW 02)', status: 'Pending',
    titikKoordinat: '-7.6501, 112.7695', linkDokumentasi: ''
  },
  {
    id: 'fsm-4', no: 4, namaArea: 'Area Karangjati Selatan', kelurahan: 'Karangjati', rw: '04', rt: '03',
    lokasiFasum: 'Masjid Al-Ikhlas, Jl. Mawar No.12',
    pemohon: 'Pengurus Masjid Al-Ikhlas', status: 'Rejected',
    titikKoordinat: '-7.6398, 112.7756', linkDokumentasi: ''
  }
];

const dummyPemasanganTiangData = [
  {
    id: 'ptg-1', no: 1, idTiang: 'TG-PDN-001', lokasi: 'Jl. Raya Pandaan Segmen A - RW 01',
    linkGmaps: 'https://maps.app.goo.gl/dummy-tg1', jenisTiang: 'Tiang Beton 9m',
    statusPekerjaan: 'Selesai', statusQC: 'Lolos QC',
    linkDokumentasi: 'https://drive.google.com/dummy-tg1', catatan: '-',
    lampiranFormQC: 'https://drive.google.com/dummy-tg1-qc',
    lampiranFormTanam: 'https://drive.google.com/dummy-tg1-tanam'
  },
  {
    id: 'ptg-2', no: 2, idTiang: 'TG-PDN-002', lokasi: 'Jl. Raya Pandaan Segmen A - RW 02',
    linkGmaps: 'https://maps.app.goo.gl/dummy-tg2', jenisTiang: 'Tiang Beton 9m',
    statusPekerjaan: 'On Progress', statusQC: 'Belum QC',
    linkDokumentasi: '', catatan: 'Proses penggalian',
    lampiranFormQC: '', lampiranFormTanam: ''
  },
  {
    id: 'ptg-3', no: 3, idTiang: 'TG-PDN-003', lokasi: 'Jl. Karangjati Segmen B - RW 03',
    linkGmaps: 'https://maps.app.goo.gl/dummy-tg3', jenisTiang: 'Tiang Besi 7m',
    statusPekerjaan: 'Belum Mulai', statusQC: 'Belum QC',
    linkDokumentasi: '', catatan: '-',
    lampiranFormQC: '', lampiranFormTanam: ''
  },
  {
    id: 'ptg-4', no: 4, idTiang: 'TG-PDN-004', lokasi: 'Jl. Karangjati Segmen B - RW 04',
    linkGmaps: 'https://maps.app.goo.gl/dummy-tg4', jenisTiang: 'Tiang Beton 9m',
    statusPekerjaan: 'Selesai', statusQC: 'Revisi',
    linkDokumentasi: 'https://drive.google.com/dummy-tg4', catatan: 'Posisi tiang perlu dikoreksi 50cm',
    lampiranFormQC: 'https://drive.google.com/dummy-tg4-qc', lampiranFormTanam: ''
  }
];

const dummyPembangunanPopData = [
  {
    id: 'ppop-1', no: 1, surveyor: 'Dimas Rantung', date: '01/09/2026',
    status: 'On Progress', recommendation: 'Lanjutkan',
    infoLokasi: {
      fotoLokasi: 'https://drive.google.com/dummy-ppop1-foto',
      alamatLokasi: 'Perumahan Graha Pandaan, Jl. Graha Pandaan Blok A No.5',
      linkGmaps: 'https://maps.app.goo.gl/dummy-ppop1'
    },
    pembangunanODC: {
      statusRAB: 'Approved',
      statusPengadaan: 'On Progress',
      statusPembangunan: 'Belum Mulai',
      statusInstalasi: 'Belum Mulai',
      statusUjiKelayakan: 'Belum Mulai'
    },
    kelistrikanODC: {
      statusPengajuanPLN: 'Submitted',
      statusInstalasiListrik: 'Belum Mulai',
      statusListrikODC: 'Belum Mulai'
    },
    aktivasiPerangkat: {
      statusPersiapan: 'Belum Mulai',
      statusKonfigurasi: 'Belum Mulai',
      statusAktivasiODC: 'Belum Mulai'
    },
    dokumentasi: {
      targetODCReady: '30/09/2026',
      aktualODCReady: '-',
      catatanKendala: 'Material ODC masih dalam proses pengiriman dari gudang pusat',
      linkDokumentasi: 'https://drive.google.com/dummy-ppop1'
    }
  },
  {
    id: 'ppop-2', no: 2, surveyor: 'Dimas Rantung', date: '02/09/2026',
    status: 'Survey Selesai', recommendation: 'Direkomendasikan',
    infoLokasi: {
      fotoLokasi: '',
      alamatLokasi: 'Kantor Desa Karangjati, Jl. Raya Karangjati No.1',
      linkGmaps: 'https://maps.app.goo.gl/dummy-ppop2'
    },
    pembangunanODC: {
      statusRAB: 'Draft',
      statusPengadaan: 'Belum Mulai',
      statusPembangunan: 'Belum Mulai',
      statusInstalasi: 'Belum Mulai',
      statusUjiKelayakan: 'Belum Mulai'
    },
    kelistrikanODC: {
      statusPengajuanPLN: 'Belum Mulai',
      statusInstalasiListrik: 'Belum Mulai',
      statusListrikODC: 'Belum Mulai'
    },
    aktivasiPerangkat: {
      statusPersiapan: 'Belum Mulai',
      statusKonfigurasi: 'Belum Mulai',
      statusAktivasiODC: 'Belum Mulai'
    },
    dokumentasi: {
      targetODCReady: '15/10/2026',
      aktualODCReady: '-',
      catatanKendala: '-',
      linkDokumentasi: ''
    }
  }
];

const dummyRouteAreaData = [
  {
    id: 'rta-1', no: 1, batch: 'Batch 1', warnaArea: 'Merah', namaArea: 'Area Karangjati Utara', otb: 'OTB-001',
    jalur1: { kabel: 'SC-6', tube: '1', core: '1-6', panjang: '350' }, cj1: 'CJ-A',
    jalur2: { kabel: 'SC-6', tube: '2', core: '1-6', panjang: '280' }, cj2: 'CJ-B',
    jalur3: { kabel: '-', tube: '-', core: '-', panjang: '' }, cj3: '',
    jalur4: { kabel: '-', tube: '-', core: '-', panjang: '' }, cj4: '',
    totalPanjang: '630', statusRoute: 'Aktif', linkDokumentasi: 'https://drive.google.com/dummy-rta1', catatan: 'Sudah divalidasi'
  },
  {
    id: 'rta-2', no: 2, batch: 'Batch 1', warnaArea: 'Biru', namaArea: 'Area Pandaan Pusat', otb: 'OTB-002',
    jalur1: { kabel: 'SC-12', tube: '1', core: '1-12', panjang: '500' }, cj1: 'CJ-A',
    jalur2: { kabel: 'SC-12', tube: '2', core: '1-12', panjang: '420' }, cj2: 'CJ-B',
    jalur3: { kabel: 'SC-12', tube: '3', core: '1-12', panjang: '310' }, cj3: 'CJ-C',
    jalur4: { kabel: '-', tube: '-', core: '-', panjang: '' }, cj4: '',
    totalPanjang: '1230', statusRoute: 'Aktif', linkDokumentasi: 'https://drive.google.com/dummy-rta2', catatan: '-'
  },
  {
    id: 'rta-3', no: 3, batch: 'Batch 2', warnaArea: 'Hijau', namaArea: 'Area Gempol Selatan', otb: 'OTB-003',
    jalur1: { kabel: 'SC-6', tube: '1', core: '1-6', panjang: '200' }, cj1: 'CJ-A',
    jalur2: { kabel: '-', tube: '-', core: '-', panjang: '' }, cj2: '',
    jalur3: { kabel: '-', tube: '-', core: '-', panjang: '' }, cj3: '',
    jalur4: { kabel: '-', tube: '-', core: '-', panjang: '' }, cj4: '',
    totalPanjang: '200', statusRoute: 'Pending', linkDokumentasi: '', catatan: 'Menunggu validasi lapangan'
  }
];

const dummyBranchOfficeOptions = [
  {
    id: 'bof-1', no: 1, surveyor: 'Rizky Pratama', date: '02/09/2026',
    status: 'Survey Selesai', recommendation: 'Direkomendasikan',
    identitas: {
      fotoTampakDepan: '',
      alamat: 'Jl. Raya Sulfat No. 48, Blimbing, Malang',
      gmaps: 'https://maps.app.goo.gl/dummy-bof1',
      namaPemilik: 'Pak Hendra Wijaya',
      kontakPemilik: '0812-3456-7890',
      jenisBangunan: 'Ruko',
      jumlahLantai: '2',
      jumlahRuangan: '8'
    },
    operasional: {
      jarakAreaPenjualan: '5 km',
      aksesKendaraan: 'Bisa dilewati truk kecil',
      areaParkir: 'Ada (10 mobil)',
      kondisiLingkungan: 'Baik, area komersial',
      keamananLingkungan: 'Tinggi (ada pos satpam)'
    },
    standarBranch: {
      areaBrainstorming: 'Ada',
      areaMaterialFTTH: 'Ada',
      areaTiang: 'Ada',
      areaIstirahat: 'Ada',
      pantry: 'Ada',
      kamarMandi: 'Ada (2 unit)'
    },
    infoBangunan: {
      luasTanah: '200',
      luasBangunan: '120',
      jumlahLantai: '2',
      jumlahRuangan: '8',
      hargaSewa: 'Rp 45.000.000 / tahun'
    },
    kondisiBangunan: {
      kondisiBangunan: 'Baik',
      kondisiKelistrikan: 'Baik',
      dayaListrik: '3500',
      kondisiAir: 'Baik',
      sumberAir: 'PDAM',
      estimasiRenovasi: ''
    },
    dokumentasi: {
      linkDokumentasi: 'https://drive.google.com/dummy-bof1'
    }
  },
  {
    id: 'bof-2', no: 2, surveyor: 'Rizky Pratama', date: '03/09/2026',
    status: 'Survey Selesai', recommendation: 'Pertimbangkan',
    identitas: {
      fotoTampakDepan: '',
      alamat: 'Jl. Soekarno Hatta No. 12, Lowokwaru, Malang',
      gmaps: 'https://maps.app.goo.gl/dummy-bof2',
      namaPemilik: 'Bu Sari Dewi',
      kontakPemilik: '0856-9876-5432',
      jenisBangunan: 'Rumah',
      jumlahLantai: '1',
      jumlahRuangan: '5'
    },
    operasional: {
      jarakAreaPenjualan: '8 km',
      aksesKendaraan: 'Gang dalam, bisa dilewati 1 mobil',
      areaParkir: 'Ada (6 mobil)',
      kondisiLingkungan: 'Cukup, area perumahan',
      keamananLingkungan: 'Cukup'
    },
    standarBranch: {
      areaBrainstorming: 'Tidak Ada',
      areaMaterialFTTH: 'Ada',
      areaTiang: 'Tidak Ada',
      areaIstirahat: 'Ada',
      pantry: 'Ada',
      kamarMandi: 'Ada (1 unit)'
    },
    infoBangunan: {
      luasTanah: '150',
      luasBangunan: '90',
      jumlahLantai: '1',
      jumlahRuangan: '5',
      hargaSewa: 'Rp 30.000.000 / tahun'
    },
    kondisiBangunan: {
      kondisiBangunan: 'Cukup Baik',
      kondisiKelistrikan: 'Cukup',
      dayaListrik: '2200',
      kondisiAir: 'Cukup',
      sumberAir: 'Sumur',
      estimasiRenovasi: 'Rp 35.000.000'
    },
    dokumentasi: {
      linkDokumentasi: 'https://drive.google.com/dummy-bof2'
    }
  }
];

const dummyPopOdcOptions = [
  {
    id: 'opt-1', no: 1, surveyor: 'Dimas Rantung', date: '28/07/2026', branchOption: 'Pandaan',
    status: 'Survey Selesai', recommendation: 'Direkomendasikan',
    location: { address: 'Perumahan Graha Pandaan (JL Graha Pandaan)', gmaps: 'https://maps.app.goo.gl/dummy1', pic: 'Pak Aziz', landStatus: 'Perumahan' },
    environment: { pengawasan: 'Ada (Security 24 Jam)', akses: 'Bisa dilewati mobil', terbuka: 'Ya', matahari: 'Ada atap/kanopi', banjir: 'Aman' },
    documentation: { fileLink: 'Opsi ODC Pandaan.jpeg', notes: 'Masih dikomunikasikan dengan jajaran developer' }
  },
  {
    id: 'opt-2', no: 2, surveyor: 'Dimas Rantung', date: '28/07/2026', branchOption: 'Pandaan',
    status: 'Survey Selesai', recommendation: 'Direkomendasikan',
    location: { address: 'Kantor Desa Karangjati', gmaps: 'https://maps.app.goo.gl/dummy2', pic: 'Pak Ismail', landStatus: 'Pemerintah' },
    environment: { pengawasan: 'Ada (Staff Desa)', akses: 'Jalan raya utama', terbuka: 'Cukup terlindung', matahari: 'Di dalam area parkir', banjir: 'Aman' },
    documentation: { fileLink: 'Foto Kantor Desa.pdf', notes: 'Perlu surat pengantar resmi dari pusat' }
  }
];

const dummyPermitData = [
  {
    id: 'pmt-1', no: 1, kecamatan: 'Pandaan', kelurahan: 'Karangjati', kodeArea: 'KDA-001', rw: '01', rt: '02',
    jenisPermit: 'Izin ODC', statusPlanner: 'Proposal No', picPlanner: 'Budi Santoso', statusPermit: 'Submitted', picPermit: 'Andi M',
    tglProposal: '01/08/2026', tglBak: '05/08/2026', targetSelesai: '15/08/2026', tglSelesai: '-', jenisKompensasi: 'Uang Tunai', nilaiKompensasi: 'Rp 500.000',
    overallStatus: 'On Progress', linkProposal: 'https://docs.google.com/document/dummy1', linkBak: 'https://docs.google.com/document/dummy2', keterangan: 'Menunggu proses tanda tangan RT/RW'
  }
];

const dummyPlanAreaData = [
  {
    id: 'pln-1', no: 1, namaArea: 'Area Pandaan Utara', kodeArea: 'PDU-001', kecamatan: 'Pandaan', kelurahan: 'Pandaan', rw: '01, 02',
    totalLuasArea: '120 M', stdLuasArea: '100 M - 150 M', statusArea: 'Approved', planRk: 'RK-1001', planOdp: 'ODP-101', 
    jmlTiang: '4', sumberCj: 'Internal', keterangan: 'Area padat penduduk'
  },
  {
    id: 'pln-2', no: 2, namaArea: 'Area Karangjati Selatan', kodeArea: 'KJS-002', kecamatan: 'Pandaan', kelurahan: 'Karangjati', rw: '03, 04',
    totalLuasArea: '80 M', stdLuasArea: '< 100 M', statusArea: 'Pending', planRk: 'RK-1002', planOdp: 'ODP-102', 
    jmlTiang: '2', sumberCj: 'Mitra', keterangan: 'Perlu validasi ulang luasan'
  }
];

function createStandardMonitors() {
  return STANDARD_MONITORS.map((name, i) => {
    let m = {
      id: 'mon-' + uid(),
      name: name,
      status: 'Aktif',
      progress: 0,
      lastUpdated: '-'
    };
    if(name === 'Opsi Lokasi POP ODC') m.popOdcOptions = [];
    if(name === 'Permit') m.permitData = [];
    if(name === 'Plan Area') m.planAreaData = [];
    if(name === 'Opsi Lokasi Kantor Branch') m.branchOfficeOptions = [];
    if(name === 'Route Area') m.routeAreaData = [];
    if(name === 'Pembangunan POP ODC') m.pembangunanPopData = [];
    if(name === 'Pemasangan Tiang') m.pemasanganTiangData = [];
    if(name === 'Fasum (Free WiFi)') m.fasumData = [];
    return m;
  });
}

/* ======================= STATE ======================= */

const S = {
  loggedIn:false,
  theme: (localStorage.getItem?'light':'light'),
  sidebarCollapsed:false,
  mobileNavOpen:false,
  page:"job-description", 
  placeholderLabel:"",
  directorates: seedData(),
  activeDirectorateId:"dir-pcc",
  expandedDivisions:new Set(["div-hc"]),
  expandedDepartments:new Set(),
  openKebab:null, 
  userMenuOpen:false,
  modal:null, 
  detailRoleId:null,
  detailEditMode:false,
  editDraft:null,
  activeSectionKey:"identity",
  loginForm:{email:"", password:"", showPw:false, error:""},
  jdSearchQuery: "",
  obSearchQuery: "",
  
  // Open Branch State
  branches: [
    {
       id: 'br-1', name: 'Branch Malang', location: 'Malang, Jawa Timur',
       status: 'Aktif', progress: 72, lastUpdated: '04 Sep 2026, 09:30',
       monitors: STANDARD_MONITORS.map((name, i) => {
           let m = { id: 'm1-'+i, name, status: 'Aktif', progress: [80, 65, 72, 50, 60, 45, 38, 25][i], lastUpdated: '04 Sep 2026, 09:30' };
           if(name === 'Opsi Lokasi POP ODC') m.popOdcOptions = JSON.parse(JSON.stringify(dummyPopOdcOptions));
           if(name === 'Permit') m.permitData = JSON.parse(JSON.stringify(dummyPermitData));
           if(name === 'Plan Area') m.planAreaData = JSON.parse(JSON.stringify(dummyPlanAreaData));
           if(name === 'Opsi Lokasi Kantor Branch') m.branchOfficeOptions = JSON.parse(JSON.stringify(dummyBranchOfficeOptions));
           if(name === 'Route Area') m.routeAreaData = JSON.parse(JSON.stringify(dummyRouteAreaData));
           if(name === 'Pembangunan POP ODC') m.pembangunanPopData = JSON.parse(JSON.stringify(dummyPembangunanPopData));
           if(name === 'Pemasangan Tiang') m.pemasanganTiangData = JSON.parse(JSON.stringify(dummyPemasanganTiangData));
           if(name === 'Fasum (Free WiFi)') m.fasumData = JSON.parse(JSON.stringify(dummyFasumData));
           return m;
       })
    },
    {
       id: 'br-2', name: 'Branch Surabaya', location: 'Surabaya, Jawa Timur',
       status: 'Aktif', progress: 58, lastUpdated: '03 Sep 2026, 16:20',
       monitors: createStandardMonitors()
    },
    {
       id: 'br-3', name: 'Branch Kediri', location: 'Kediri, Jawa Timur',
       status: 'Non-aktif', progress: 35, lastUpdated: '01 Sep 2026, 14:10',
       monitors: createStandardMonitors()
    }
  ],
  activeBranchId: null,
  activeMonitorId: null,
  bofSelection: {}
};

// use in-memory theme only (no localStorage per artifact rules)
S.theme = "light";

function findDirectorate(id){ return S.directorates.find(d=>d.id===id); }
function findDivision(id){ for(const d of S.directorates){ const v=d.divisions.find(x=>x.id===id); if(v) return v; } return null; }
function findDepartment(id){ for(const d of S.directorates) for(const v of d.divisions){ const dep=v.departments.find(x=>x.id===id); if(dep) return dep; } return null; }
function findJobRole(id){
  for(const d of S.directorates) for(const v of d.divisions){
    if(v.headOfDivisionJobRoleId===id) return headOfDivisionRole(v);
    for(const dep of v.departments){ const r=dep.jobRoles.find(x=>x.id===id); if(r) return r; }
  }
  return null;
}
function jobRoleContext(roleId){
  for(const d of S.directorates) for(const v of d.divisions){
    if(v.headOfDivisionJobRoleId===roleId) return {directorate:d, division:v, department:null};
    for(const dep of v.departments){ if(dep.jobRoles.some(x=>x.id===roleId)) return {directorate:d, division:v, department:dep}; }
  }
  return {};
}

// Function to filter hierarchy based on search query
function getFilteredDir(dir, query) {
  if (!query) return dir;
  const q = query.toLowerCase();
  
  if (dir.name.toLowerCase().includes(q)) return dir; 
  
  const filteredDivs = [];
  for (const div of dir.divisions) {
      if (div.name.toLowerCase().includes(q)) {
          filteredDivs.push(div);
          continue;
      }
      const filteredDepts = [];
      let divMatch = false;
      
      const hod = headOfDivisionRole(div);
      if (hod && hod.name.toLowerCase().includes(q)) divMatch = true;

      for (const dept of div.departments) {
          if (dept.name.toLowerCase().includes(q)) {
              filteredDepts.push(dept);
              continue;
          }
          const filteredRoles = dept.jobRoles.filter(r => r.name.toLowerCase().includes(q));
          if (filteredRoles.length > 0) {
              filteredDepts.push({ ...dept, jobRoles: filteredRoles });
          }
      }
      
      if (divMatch || filteredDepts.length > 0) {
          filteredDivs.push({ ...div, departments: filteredDepts });
      }
  }
  return { ...dir, divisions: filteredDivs };
}
