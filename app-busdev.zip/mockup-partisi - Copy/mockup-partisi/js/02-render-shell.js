function render(){ 
  let focusId = document.activeElement ? document.activeElement.id : null;
  let selStart = focusId && document.activeElement.selectionStart ? document.activeElement.selectionStart : null;
  
  document.getElementById('root').innerHTML = S.loggedIn ? renderApp() : renderLogin(); 
  attachHandlers(); 
  
  if(focusId && document.getElementById(focusId)) {
      const el = document.getElementById(focusId);
      el.focus();
      if(selStart !== null && el.setSelectionRange) el.setSelectionRange(selStart, selStart);
  }
}

/* ======================= LOGIN ======================= */

function renderLogin(){
  const f = S.loginForm;
  return `
  <div class="login-screen" data-theme="${S.theme}">
    <div class="login-aside">
      <div class="brand"><b>Job Architecture</b> · Business Development</div>
      <div>
        <h1>Satu peta yang jelas untuk struktur organisasi dan uraian jabatan.</h1>
      </div>
      <div class="tiers">
        <span>Directorate → Division → Department → Job Role</span>
        <span>14 bagian uraian jabatan terstruktur, bukan dokumen datar</span>
        <span>Dirancang untuk 7 direktorat dan puluhan jabatan</span>
      </div>
    </div>
    <div class="login-main">
      <div class="login-card">
        <h2>Masuk ke akun Anda</h2>
        <p class="sub">Gunakan kredensial internal Business Development.</p>
        <div class="field">
          <label>Email</label>
          <input id="login-email" type="text" placeholder="nama@perusahaan.co.id" value="${escAttr(f.email)}">
        </div>
        <div class="field">
          <label>Kata sandi</label>
          <div class="pw-wrap">
            <input id="login-password" type="${f.showPw?'text':'password'}" placeholder="••••••••" value="${escAttr(f.password)}">
            <button id="login-toggle-pw" type="button">${f.showPw?'Sembunyikan':'Tampilkan'}</button>
          </div>
        </div>
        ${f.error?`<div class="delete-warning">${f.error}</div>`:''}
        <button class="btn btn-primary" id="login-submit">Masuk</button>
        <div class="login-hint">Prototipe — gunakan email &amp; kata sandi apa pun untuk masuk.</div>
      </div>
    </div>
  </div>`;
}

/* ======================= SHELL ======================= */

function renderApp(){
  return `
  <div data-theme="${S.theme}" style="height: 100%;">
  <div class="app">
    ${renderSidebar()}
    <div class="main">
      ${renderHeader()}
      <div class="content" id="main-scroll-content">
        ${S.page==='job-description' ? renderJobDescriptionPage() : ''}
        ${S.page==='job-description-detail' ? renderDetailPage() : ''}
        ${S.page==='open-branch' ? renderOpenBranchPage() : ''}
        ${S.page==='open-branch-detail' ? renderBranchDetailPage() : ''}
        ${S.page==='open-branch-monitor' ? renderMonitorDetailPage() : ''}
        ${S.page==='placeholder' ? renderPlaceholderPage() : ''}
      </div>
    </div>
  </div>
  ${S.modal ? renderModal() : ''}
  </div>`;
}

function renderSidebar(){
  const groups = [
    {label:"Business Quality & Governance", items:[
      {key:"job-description", label:"Job Description", icon:ICONS.building, real:true},
      {key:"dwp-sop", label:"DWP/SOP", icon:ICONS.inbox, real:false},
      {key:"project-management-bqg", label:"Project Management", icon:ICONS.inbox, real:false}
    ]},
    {label:"Strategic Growth & Product", items:[
      {key:"open-branch", label:"Open Branch", icon:ICONS.location, real:true},
      {key:"kuartal", label:"Kuartal", icon:ICONS.inbox, real:false},
      {key:"project-management-sgp", label:"Project Management", icon:ICONS.inbox, real:false}
    ]}
  ];
  
  const isActive = k => {
    if(S.page.startsWith('job-description')) return k === 'job-description';
    if(S.page.startsWith('open-branch')) return k === 'open-branch';
    return S.page === 'placeholder' && S.placeholderLabel === k;
  };

  return `
  <div class="sidebar ${S.sidebarCollapsed?'collapsed':''} ${S.mobileNavOpen?'mobile-open':''}">
    <div class="sidebar-brand"><div class="mark">JA</div><span>Job Architecture</span></div>
    <div class="sidebar-scroll">
      ${groups.map(g=>`
        <div class="sidebar-group">
          <div class="sidebar-group-label">${g.label}</div>
          ${g.items.map(it=>`
            <div class="nav-item ${isActive(it.key)?'active':''}" data-nav="${it.key}" data-real="${it.real}">
              ${it.icon}<span>${it.label}</span>
            </div>`).join('')}
        </div>`).join('')}
    </div>
    <div class="sidebar-foot">
      <button class="btn btn-ghost btn-sm collapse-btn" id="sidebar-collapse-toggle">${S.sidebarCollapsed?'»':'« Ciutkan'}</button>
    </div>
  </div>`;
}

function renderHeader(){
  const titleMap = {
    "job-description":"Job Description",
    "job-description-detail":"Job Description",
    "open-branch":"Open Branch",
    "open-branch-detail":"Open Branch",
    "open-branch-monitor":"Open Branch",
    "placeholder":S.placeholderLabel==='dwp-sop'?'DWP/SOP':S.placeholderLabel==='open-branch'?'Open Branch':S.placeholderLabel==='kuartal'?'Kuartal':'Project Management'
  };
  return `
  <div class="header">
    <div style="display:flex;align-items:center;gap:10px;">
      <button class="btn-ghost btn" id="mobile-nav-toggle" style="display:none;padding:6px;">☰</button>
      <div class="header-title">${titleMap[S.page]||''}</div>
    </div>
    <div class="header-right">
      <div class="theme-toggle">
        <button class="${S.theme==='light'?'active':''}" id="theme-light" aria-label="Light mode">${ICONS.sun}</button>
        <button class="${S.theme==='dark'?'active':''}" id="theme-dark" aria-label="Dark mode">${ICONS.moon}</button>
      </div>
      <div class="user-menu">
        <button class="user-chip" id="user-menu-btn">
          <div class="avatar">BD</div>
          <span class="name">Budi Santoso</span>
        </button>
        ${S.userMenuOpen?`
        <div class="dropdown">
          <button disabled style="color:var(--ink-faint);">budi.santoso@perusahaan.co.id</button>
          <hr style="border:none;border-top:1px solid var(--border);margin:4px 2px;">
          <button class="danger" id="logout-btn">Keluar</button>
        </div>`:''}
      </div>
    </div>
  </div>`;
}

